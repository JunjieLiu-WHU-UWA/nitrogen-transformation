
%  clearvars -except anvil
%  close all
%  clc
% load('E:\Simulation_UWA_WD\2 For model variables\Supporting information\anvil.mat');
 addpath('E:\Simulation_UWA_WD\2 For model variables\Function');
 addpath('E:\Simulation_UWA_WD\2 For model variables\Supporting information');
 BasicRead
 currentOutput = '3 nitrogen\6 TN\'; 
fileOutput =  [dicmodel currentFolder '\Output\' currentOutput ];
if ~exist(fileOutput,'dir')      % check  whether the outdir  exists in the file of 'dir';
    mkdir(fileOutput);           % if not exists, create the file of 'outdir'
end
yysTime_12_17  = datenum('2012/01/01 00:00:00');
 yyeTime_12_17  = datenum('2017/12/31 23:55:00');
 yyTick_12_17 = {   '2012/01/01 '...
                      '2013/01/01 '...
                      '2014/01/01 '...
                      '2015/01/01 '...
                      '2016/01/01 '...
                      '2017/01/01 ' }';
yyLable_12_17 = { '12' '13' '14' '15' '16' '17'    }';  


TN_DoW_outlet =  anvil.SWQ.MSANVCBOUT.LRD.DoW.WQ_DIAG_TOT_TN;
TN_DoW_outlet.Data =  TN_DoW_outlet.Data / 1000 *14;
UTN_UWA_outlet_storm3 = anvil.SWQ.MSANVCBOUT.HRD.daily.dailyStorm_03.UTN;
UTN_UWA_outlet_storm4 = anvil.SWQ.MSANVCBOUT.HRD.daily.dailyStorm_04.UTN;
UTN_UWA_outlet_storm5 = anvil.SWQ.MSANVCBOUT.HRD.daily.dailyStorm_05.UTN;
UTN_UWA_outlet_Opportunistic = anvil.SWQ.MSANVCBOUT.HRD.Opportunistic.UTN;

 finalVar =   addStructVar(TN_DoW_outlet  ,UTN_UWA_outlet_storm3 );
 finalVar =   addStructVar( finalVar   ,UTN_UWA_outlet_storm4 );
  finalVar =   addStructVar( finalVar   ,UTN_UWA_outlet_storm5 );
   finalVar =   addStructVar( finalVar   ,UTN_UWA_outlet_Opportunistic  );
   
   
fileInletFlow = 'E:\Simulation_UWA_WD\1 For model\0 boundaryPlot\longTermtrendNutrient\Inlet_LongDischarge2012_2017 daily.csv';
fid = fopen(fileInletFlow,'rt');
dataFlow = textscan(fid,'%s %f','Headerlines',1,'Delimiter',',');
LongDis.Date = datenum(dataFlow{1,1},'yyyy/mm/dd');
LongDis.Data = dataFlow{1,2};

 [ Base , Quick ]  =     BaseflowQuick(LongDis );
 max(Base.Data)
 figure
 plot(Base.Date, Base.Data)
 hold on 
 figure
 plot(Quick.Date, Quick.Data, '*')


%-----------------
fileAirTemp = 'E:\Simulation_UWA_WD\1 For model\0 boundaryPlot\longTermtrendNutrient\dailyAverageAirTemp2005to201806.csv';
fid = fopen(fileAirTemp,'rt');
dataAirTemp = textscan(fid,'%s %f','Headerlines',1,'Delimiter',',');
LongAirTemp.Date = datenum(dataAirTemp{1,1},'dd/mm/yyyy');
LongAirTemp.Data = dataAirTemp{1,2};





zero_Var = zeros( length(finalVar.Date)  , 1) ;
 ss_1 = find(   datenum(2012, 7, 19)  <=  finalVar.Date   & finalVar.Date <= datenum(2017, 2, 1)    ) ;
 ss_2 = find(  datenum(2017, 4, 13)  <=  finalVar.Date   & finalVar.Date <= datenum(2017, 7, 18) )
 zero_Var(ss_1) = 1;
 zero_Var(ss_2) = 1;
  
 finalVarPeriod.Date = finalVar.Date(logical(zero_Var));
  finalVarPeriod.Data = finalVar.Data(logical(zero_Var));
  flow_target    =  findFlowDateNutrients(  finalVarPeriod.Date, LongDis );
  AirTemp_target    =  findFlowDateNutrients(  finalVarPeriod.Date, LongAirTemp );
% finalVarPeriod.Data(49) = mean(finalVarPeriod.Data);




figure
subplot(2,1, 1)
plot(AirTemp_target.Date   , AirTemp_target.Data, '*' )
 hold on
  set(gca,'XTick',[datenum(yyTick_12_17 )],'XTickLabel',yyLable_12_17,'TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
title('The value of air temperature and flow corresponding to sample date of TN')
box(gca,'on');
xlabel('Year')
xlim([yysTime_12_17  yyeTime_12_17]);
ylabel({'Air temperature', '(^{o}C)'});
grid on 
 subplot(2, 1, 2)
 plot( flow_target.Date  ,flow_target.Data, '*' )
 set(gca,'XTick',[datenum(yyTick_12_17 )],'XTickLabel',yyLable_12_17,'TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
% title('The model temp and flow')
box(gca,'on');
xlabel('Year')
xlim([yysTime_12_17  yyeTime_12_17]);
ylabel({'flow', '(m^{3}/s)'});
grid on 


ss = find(flow_target.Data < 0.1 );
 finalVarPeriod_nonstorm.Date =  finalVarPeriod.Date(ss);
finalVarPeriod_nonstorm.Data  =   finalVarPeriod.Data(ss);

 filename = [  'TN_outlet_historical_nonStorm.csv'];
fid = fopen(filename,'wt');
fprintf(fid,'ISOTime, TN_weir (mg/L)\n');
for i = 1:length( finalVarPeriod_nonstorm.Date)
    fprintf(fid,'%s,',datestr( finalVarPeriod_nonstorm.Date(i),'dd/mm/yyyy HH:MM:SS'));
    fprintf(fid,'%4.4f\n',     finalVarPeriod_nonstorm.Data(i) );
end
fclose(fid);

% read modelled NO3

fileTNWeir =  [ fileOutput 'TN_weir.csv'];
fid = fopen(fileTNWeir,'rt');
dataTNWeir = textscan(fid,'%s %f','Headerlines',1,'Delimiter',',');
TNWeir.Date = datenum(dataTNWeir{1,1},'dd/mm/yyyy HH:MM:SS');
TNWeir.Data = dataTNWeir{1,2};% mg/L
   [TNWeir_nonStorm, TNWeir_Storm] =  seperate10minperiod(TNWeir, period_10min     );

group_all = [ ones( length(finalVarPeriod_nonstorm.Data), 1) *1 ;  ...
ones(length(TNWeir_nonStorm.Data), 1)*2 ];
figure
boxplot([finalVarPeriod_nonstorm.Data ;  TNWeir_nonStorm.Data], group_all);
ylabel('TN (mg/L)');
set(gca,'XTick',[ 1.0  2.0  ], 'XTickLabel',{'Measured', ...
                                                          'Modelled'   });
                                                      set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 5; ySize = 10;
xLeft = 0; yTop = 0;
set(gcf, 'paperposition',[xLeft yTop xSize ySize])
saveas(gcf, [fileOutput   'CalibriationTNLongTerm'],'png');
saveas(gcf, [fileOutput   'CalibriationTNLongTerm'],'fig');
                                                      
                                                      

