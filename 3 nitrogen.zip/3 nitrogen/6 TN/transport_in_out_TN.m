%this script is to analyze the budget of oxygen
clc
% clearvars -except anvil 

% addpath('E:\Simulation_UWA_WD\2 For model variables\Function');
% addpath('E:\Simulation_UWA_WD\2 For model variables\Supporting information');
% BasicRead
file =  [dicmodel currentFolder '\Output\3 nitrogen\' ];

budget_TN = zeros( 4 ,1   );
figure

% Transport in
fileTran = [file '2 NH4\NH4 transport_in.csv' ];
fid = fopen(fileTran,'rt');
data = textscan(fid,'%s %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
transIN.Date = dateTime;
transIN.Data = data{1,2}; % the unit is g/d
budget_TN(1,1) = trapz(transIN.Date, transIN.Data  );

% transport out
fileTran = [ file '2 NH4\NH4 transport_out.csv'];
fid = fopen(fileTran,'rt');
data = textscan(fid,'%s %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
transOut.Date = dateTime;
transOut.Data = data{1,2}; % the unit is g/d
budget_TN(2,1) = trapz(transOut.Date, transOut.Data  );

% sedment flux of NH4
 fileAtm = [ file '2 NH4\Sediment flux of NH4 _wholeWetland.csv'];
 fid = fopen(fileAtm,'rt');
data = textscan(fid,'%s %f %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
SedNH4.Date = dateTime ;
SedNH4.Data = data{1,2};% the unit is g/d
budget_TN(3,1) = trapz(SedNH4.Date, SedNH4.Data  );

%
% Transport in
fileTran = [file '3 NO3\NO3 transport_in.csv' ];
fid = fopen(fileTran,'rt');
data = textscan(fid,'%s %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
transIN.Date = dateTime;
transIN.Data = data{1,2}; % the unit is g/d
budget_TN(4,1) = trapz(transIN.Date, transIN.Data  );

% transport out
fileTran = [ file '3 NO3\NO3 transport_out.csv'];
fid = fopen(fileTran,'rt');
data = textscan(fid,'%s %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
transOut.Date = dateTime;
transOut.Data = data{1,2}; % the unit is g/d
budget_TN(5,1) = trapz(transOut.Date, transOut.Data  );



% sedment flux of NO3
 fileAtm = [ file '3 NO3\Sediment flux of NO3 _wholeWetland.csv'];
 fid = fopen(fileAtm,'rt');
data = textscan(fid,'%s %f %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
SedNO3.Date = dateTime ;
SedNO3.Data = data{1,2} * (-1);% the unit is g/d
budget_TN(6,1) = trapz(SedNO3.Date, SedNO3.Data  );

 
 % denitrification of NO3
 fileAtm = [ file '3 NO3\Denitrification of NO3 _wholeWetland.csv'];
 fid = fopen(fileAtm,'rt');
data = textscan(fid,'%s %f %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
DEnitriNO3.Date = dateTime ;
DEnitriNO3.Data = data{1,2} ;% the unit is g/d
budget_TN(7,1) = trapz(DEnitriNO3.Date, DEnitriNO3.Data  );
 


% Transport in
fileTran = [file '4 DON\DON transport_in.csv' ];
fid = fopen(fileTran,'rt');
data = textscan(fid,'%s %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
transIN.Date = dateTime;
transIN.Data = data{1,2}; % the unit is g/d
budget_TN(8,1) = trapz(transIN.Date, transIN.Data  );

% transport out
fileTran = [ file '4 DON\DON transport_out.csv'];
fid = fopen(fileTran,'rt');
data = textscan(fid,'%s %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
transOut.Date = dateTime;
transOut.Data = data{1,2}; % the unit is g/d
budget_TN(9,1) = trapz(transOut.Date, transOut.Data  );

% sedment flux of DON
 fileAtm = [ file '4 DON\Sediment flux of DON _wholeWetland.csv'];
 fid = fopen(fileAtm,'rt');
data = textscan(fid,'%s %f %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
SedDON.Date = dateTime ;
SedDON.Data = data{1,2} ;% the unit is g/d
budget_TN(10,1) = trapz(SedDON.Date, SedDON.Data  );

% Transport in of NH4
fileTran = [file '5 PON\PON transport_in.csv' ];
fid = fopen(fileTran,'rt');
data = textscan(fid,'%s %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
transIN.Date = dateTime;
transIN.Data = data{1,2}; % the unit is g/d
budget_TN(11,1) = trapz(transIN.Date, transIN.Data  );


% transport out
fileTran = [ file '5 PON\PON transport_out.csv'];
fid = fopen(fileTran,'rt');
data = textscan(fid,'%s %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
transOut.Date = dateTime;
transOut.Data = data{1,2}; % the unit is g/d
budget_TN(12,1) = trapz(transOut.Date, transOut.Data  );

% sedimentation of PON
 fileAtm = [ file '5 PON\PON sedimentation _wholeWetland.csv'];
 fid = fopen(fileAtm,'rt');
data = textscan(fid,'%s %f %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
SedPON.Date = dateTime ;
SedPON.Data = data{1,2} * (-1) ;% the unit is g/d
budget_TN(13,1) = trapz(SedPON.Date, SedPON.Data  );

% decomposition of PON
 fileAtm = [ file '5 PON\PON decomposition _wholeWetland.csv'];
 fid = fopen(fileAtm,'rt');
data = textscan(fid,'%s %f %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
DecomPON.Date = dateTime ;
DecomPON.Data = data{1,2};% the unit is g/d
budget_TN(14,1) = trapz(DecomPON.Date, DecomPON.Data  );
  
figure
p = pie(budget_TN);
pText = findobj(p,'Type','text');

leg1 = legend('Influent of NH_{4}','Outfluent of NH_{4}','Sediment flux of NH_{4}', ....
                         'Influent of NO_{3}','Outfluent of NO_{3}','Sediment flux of NO_{3}', 'Denitrification of NO_{3}' , ...
                         'Influent of DON','Outfluent of DON','Sediment flux of DON', ...
                          'Influent of PON','Outfluent of  PON','Sedimentation of PON', 'Decomposition of PON');
                          
 set(leg1,    'Location','eastoutside');

set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 20;
xLeft = 0;   yTop = 0;
set(gcf,'paperposition',[xLeft yTop xSize ySize])
saveas(gcf, [file '\6 TN\Pie TN budget percent'],'png');


% 
% percentValues = get(pText,'String'); 
% txt = {'Influent : ','Outfluent :','Atmospheric flux :', ...
%                 'SOD :', 'PGPP :', 'NEP :' }'; 
% combinedtxt = strcat(txt,percentValues);
% 
% pText(1).String = combinedtxt(1);
% pText(2).String = combinedtxt(2);
% pText(3).String = combinedtxt(3);
% pText(4).String = combinedtxt(4);
% pText(5).String = combinedtxt(5);
% pText(6).String = combinedtxt(6);