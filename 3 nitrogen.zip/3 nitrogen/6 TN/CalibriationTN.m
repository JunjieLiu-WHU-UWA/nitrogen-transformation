

% load('D:\Research in UWA\overview of data available in anvil\all_togehter_plotting\anvil.mat');
% addpath('E:\Simulation_UWA_WD\2 For model variables\Function');
% addpath('E:\Simulation_UWA_WD\2 For model variables\Supporting information');
% BasicRead
currentOutput = '3 nitrogen\6 TN\'; 
fileOutput =  [dicmodel currentFolder '\Output\' currentOutput ];
if ~exist(fileOutput,'dir')      % check  whether the outdir  exists in the file of 'dir';
    mkdir(fileOutput);           % if not exists, create the file of 'outdir'
end
varid = netcdf.inqVarID(ncid,'WQ_DIAG_TOT_TN');
TOT_TN = netcdf.getVar(ncid,varid) /1000*14  ;  %mmol/m3/d to g/m3/d; 

weirTOT_TN = mean(TOT_TN(idx2weirCell,: ));
inletTOT_TN = mean(TOT_TN(idx2InletCell,: ));

figure

plot(ResTime,weirTOT_TN(1,:)  );
hold on

TN_DoW =  anvil.SWQ.MSANVCBOUT.LRD.DoW.WQ_DIAG_TOT_TN;
ss = find(sTime <= TN_DoW.Date & TN_DoW.Date <= eTime);
plot(TN_DoW.Date(ss,1),TN_DoW.Data(ss,1)./1000*14,'o'); clear ss
hold on 


TN_UWA_04 =  anvil.SWQ.MSANVCBOUT.HRD.Storm_04.UTN;
ss = find(sTime <= TN_UWA_04.Date & TN_UWA_04.Date <= eTime);
plot(TN_UWA_04.Date(ss,1),TN_UWA_04.Data(ss,1),'bs'); clear ss
hold on 

TN_UWA_05 =  anvil.SWQ.MSANVCBOUT.HRD.Storm_05.UTN;
ss = find(sTime <= TN_UWA_05.Date & TN_UWA_05.Date <= eTime);
plot(TN_UWA_05.Date(ss,1),TN_UWA_05.Data(ss,1),'rs'); clear ss
hold on 


leg1 = legend( 'modelled TN', 'DoW', 'Storm 04', 'Storm 05');
set(leg1,'Location','best');
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([  currentFolder ' TN at outlet  ']);
xlim([sTime  eTime]);
ylabel('mg/L'); 
xlabel('Date (2015)');
grid on 

saveas(gcf,[fileOutput  'TN at outlet'],'png');
saveas(gcf,[fileOutput  'TN at outlet'],'fig');




filecsv =  [ fileOutput 'TN_weir.csv' ];
fid = fopen(filecsv,'wt');
fprintf(fid,'ISOTime, TN concentration (mg/L) \n');
for i = 1:length(ResTime)
    fprintf(fid,'%s,',datestr(ResTime(i),'dd/mm/yyyy HH:MM:SS'));
    fprintf(fid,'%4.4f \n', weirTOT_TN(i));
end
fclose(fid);


%-------------------------comparison TN at inlet and outlet


figure
h(1) = plot(ResTime,inletTOT_TN );
hold on

TN_UWA_04 =  anvil.SWQ.MSANVCBIN.HRD.Storm_04.UTN;
ss = find(sTime <= TN_UWA_04.Date & TN_UWA_04.Date <= eTime);
h(2) =  plot(TN_UWA_04.Date(ss,1),TN_UWA_04.Data(ss,1),'b*'); clear ss
hold on 

TN_UWA_05 =  anvil.SWQ.MSANVCBIN.HRD.Storm_05.UTN;
ss = find(sTime <= TN_UWA_05.Date & TN_UWA_05.Date <= eTime);
h(3) = plot(TN_UWA_05.Date(ss,1),TN_UWA_05.Data(ss,1),'b*'); clear ss
hold on 

% weir
h(4) = plot(ResTime,weirTOT_TN );
hold on

TN_DoW =  anvil.SWQ.MSANVCBOUT.LRD.DoW.WQ_DIAG_TOT_TN;
ss = find(sTime <= TN_DoW.Date & TN_DoW.Date <= eTime);
h(5) = plot(TN_DoW.Date(ss,1),TN_DoW.Data(ss,1)./1000*14,'rs'); clear ss
hold on 


TN_UWA_04 =  anvil.SWQ.MSANVCBOUT.HRD.Storm_04.UTN;
ss = find(sTime <= TN_UWA_04.Date & TN_UWA_04.Date <= eTime);
h(6) = plot(TN_UWA_04.Date(ss,1),TN_UWA_04.Data(ss,1),'rs'); clear ss
hold on 

TN_UWA_05 =  anvil.SWQ.MSANVCBOUT.HRD.Storm_05.UTN;
ss = find(sTime <= TN_UWA_05.Date & TN_UWA_05.Date <= eTime);
h(7) = plot(TN_UWA_05.Date(ss,1),TN_UWA_05.Data(ss,1),'rs'); clear ss
hold on 

AddShade([0  0] , [2.5  2.5] , period );
leg1 = legend(h([1 2 4 5]),  'Inlet ', '', 'Outlet', '');
set(leg1,'Location','best');

% 
% leg1 = legend( 'modelled inlet TN', 'modelled outlet TN');
set(leg1,'Location','best');
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([  currentFolder ' TN at inlet and outlet  ']);
xlim([sTime  eTime]);
ylabel('mg/L'); 
xlabel('Date (2015)');
grid on 
set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 10;
xLeft = 0; yTop = 0;
set(gcf,'paperposition',[xLeft yTop xSize ySize])

saveas(gcf,[fileOutput  'TN at inlet and outlet'],'png');
% saveas(gcf,[fileOutput  'TN at inlet and outlet'],'fig');

