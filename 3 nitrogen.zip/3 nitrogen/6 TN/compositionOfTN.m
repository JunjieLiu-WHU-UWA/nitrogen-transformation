
clc
close all
addpath('E:\Simulation_UWA_WD\2 For model variables\Function');
addpath('E:\Simulation_UWA_WD\2 For model variables\Supporting information');
BasicRead
currentOutput = '3 nitrogen\6 TN\'; 
fileOutput =  [dicmodel currentFolder '\Output\' currentOutput ];
if ~exist(fileOutput,'dir')      % check  whether the outdir  exists in the file of 'dir';
    mkdir(fileOutput);           % if not exists, create the file of 'outdir'
end
figure
subplot(5, 1,1)
fileNH4 =  [dicmodel currentFolder '\Output\3 nitrogen\2 NH4\NH4_weir_10min.csv'];
fid = fopen(fileNH4 ,'rt');
data = textscan(fid,'%s %f','Headerlines',1,'Delimiter',',');
NH4_weir.Date = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
NH4_weir.Data = data{1,2};
plot(NH4_weir.Date , NH4_weir.Data)
% leg1 = legend( 'modelled NH_{4} ');
% set(leg1,'Location','best');
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([  currentFolder ' Modelled nitrogen at outlet  ']);
xlim([sTime  eTime]);
ylim([0  6]);
ylabel(' NH_{4} (mg/L)'); 
xlabel('Date (2015)');
grid on 

subplot(5, 1,2)
fileNO3 =  [dicmodel currentFolder '\Output\3 nitrogen\3 NO3\Nit_weir_10min.csv'];
fid = fopen(fileNO3 ,'rt');
data = textscan(fid,'%s %f','Headerlines',1,'Delimiter',',');
NO3_weir.Date = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
NO3_weir.Data = data{1,2};
plot(NO3_weir.Date , NO3_weir.Data)
% leg1 = legend( 'modelled NO_{3} ');
% set(leg1,'Location','best');
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
% title([  currentFolder ' NH_{4} at outlet  ']);
xlim([sTime  eTime]);
ylim([0  6]);
ylabel('  NO_{3} (mg/L)'); 
xlabel('Date (2015)');
grid on 

subplot(5, 1,3)
fileDON =  [dicmodel currentFolder '\Output\3 nitrogen\4 DON\DON_weir.csv'];
fid = fopen(fileDON ,'rt');
data = textscan(fid,'%s %f','Headerlines',1,'Delimiter',',');
DON_weir.Date = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
DON_weir.Data = data{1,2};
plot(DON_weir.Date , DON_weir.Data)
% leg1 = legend( 'modelled DON');
% set(leg1,'Location','best');
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
% title([  currentFolder ' NH_{4} at outlet  ']);
xlim([sTime  eTime]);
ylim([0  6]);
ylabel(' DON (mg/L)'); 
xlabel('Date (2015)');
grid on 

subplot(5, 1,4)
filePON =  [dicmodel currentFolder '\Output\3 nitrogen\5 PON\PON_weir.csv'];
fid = fopen(filePON ,'rt');
data = textscan(fid,'%s %f','Headerlines',1,'Delimiter',',');
PON_weir.Date = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
PON_weir.Data = data{1,2};
plot(PON_weir.Date , PON_weir.Data)
% leg1 = legend( 'modelled PON} ');
% set(leg1,'Location','best');
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
% title([  currentFolder ' NH_{4} at outlet  ']);
xlim([sTime  eTime]);
ylim([0  6]);
ylabel('PON (mg/L)'); 
xlabel('Date (2015)');
grid on 

subplot(5, 1,5)
fileTN =  [dicmodel currentFolder '\Output\3 nitrogen\6 TN\TN_weir.csv'];
fid = fopen(fileTN ,'rt');
data = textscan(fid,'%s %f','Headerlines',1,'Delimiter',',');
TN_weir.Date = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
TN_weir.Data = data{1,2};
plot(TN_weir.Date , TN_weir.Data)
% leg1 = legend( 'modelled TN ');
% set(leg1,'Location','best');
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
% title([  currentFolder ' NH_{4} at outlet  ']);
xlim([sTime  eTime]);
ylim([0  6]);
ylabel(' TN (mg/L)'); 
xlabel('Date (2015)');
grid on 

set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 29;
xLeft = 0; yTop = 0;
set(gcf,'paperposition',[xLeft yTop xSize ySize])
saveas(gcf,[fileOutput 'Composition of TN'],'png');