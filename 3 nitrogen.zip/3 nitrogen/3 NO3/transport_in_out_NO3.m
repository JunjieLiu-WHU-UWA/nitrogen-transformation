
% load('D:\Research in UWA\overview of data available in anvil\all_togehter_plotting\anvil.mat');
% addpath('E:\Simulation_UWA_WD\2 For model variables\Function');
% addpath('E:\Simulation_UWA_WD\2 For model variables\Supporting information');
% BasicRead
currentOutput = '3 nitrogen\3 NO3\'; 
fileOutput =  [dicmodel currentFolder '\Output\' currentOutput ];
if ~exist(fileOutput,'dir')      % check  whether the outdir  exists in the file of 'dir';
    mkdir(fileOutput);           % if not exists, create the file of 'outdir'
end

var = 'NO3';
% fileFluxmat = [ dicmodel currentFolder  '\Output\Flux.mat'];
% % save Flux.mat Flux
% load(fileFluxmat, 'Flux');

%----
file_inflow =  [ dicmodel currentFolder   '\BCs\'   BC_inflow ];
fid = fopen(file_inflow ,'rt');
str = repmat('%f ', [1 24] );
data_inlet = textscan(fid,['%s' str],'Headerlines',1,'Delimiter',',');
ISOTime_in = datenum(data_inlet{1,1},'dd/mm/yyyy HH:MM:SS');
Inflow.Date = ISOTime_in;
Inflow.Data = data_inlet{1,2};

InflowNit.Date  = ISOTime_in;
InflowNit.Data  = data_inlet{1,10} ;  %  the unit is  mmol /m3

transInflowNit = calculationFlux(Inflow.Date,   Inflow.Data, InflowNit.Data); % mmol/s

file_inflow =  [ dicmodel currentFolder   '\BCs\'    BC_Mars ];
fid = fopen(file_inflow ,'rt');
str = repmat('%f ', [1 24] );
data_inlet = textscan(fid,['%s' str],'Headerlines',1,'Delimiter',',');
ISOTime_in = datenum(data_inlet{1,1},'dd/mm/yyyy HH:MM:SS');
Mars.Date = ISOTime_in;
Mars.Data = data_inlet{1,2};

MarsNit.Date  = ISOTime_in;
MarsNit.Data  = data_inlet{1,10} ;  %  the unit is  mmol /m3
transMarNit = calculationFlux(Mars.Date,   Mars.Data, MarsNit.Data) ;  % mmol/s
NIT_IN.Date = MarsNit.Date;
NIT_IN.Data   = transInflowNit.Data + transMarNit.Data;    % mmol/s
NIT_IN.Data = NIT_IN.Data  *N_mmol_g   * day_second  ; % the unit is g/d

fileweir = [  dicmodel currentFolder  '\Output\3 nitrogen\3 NO3\'  'Nit_weir_10min.csv'];
 fid = fopen(fileweir,'rt');
data = textscan(fid,'%s %f','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
Weir_NIT_10min.Date = dateTime ;
Weir_NIT_10min.Data = data{1,2} / N_mmol_g; %convert mg/L to mmol/m3

file_outflow =  [ dicmodel currentFolder   '\Output\'  '2. Flow\Outflow_weir_10min.csv'];
fid = fopen(file_outflow ,'rt');
data_outlet = textscan(fid,'%s %f %f ', 'Headerlines',1,'Delimiter',',');
ISOTime_out = datenum(data_outlet{1,1},'dd/mm/yyyy HH:MM:SS');
Outflow.Date = ISOTime_out;
Outflow.Data = data_outlet{1,2};%  m3/s

NIT_OUT   = calculationFlux(Outflow.Date, Outflow.Data, Weir_NIT_10min.Data ); % mmol/s
NIT_OUT.Data = NIT_OUT.Data  *N_mmol_g   * day_second  ; % the unit is g/d

gcf_nit = figure;

plot( NIT_IN.Date, NIT_IN.Data ./1000  ) % kg/d  
hold on
plot( NIT_OUT.Date, NIT_OUT.Data./1000 )% kg/d  
hold on

leg1 = legend('Tansport in NO_{3}',  'Tansport out NO_{3}');
set(leg1,'Location','best');

set(gca,'XTick', [ datenum(timeTick )],'XTickLabel','','TickLength',[0.005 0.015]);
% set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);
ylabel({'kg/d'});
%  text( sTime + 8,800,'(a)');
%  text(0.08,1.1,'(a)','units','normalized');
 title([  currentFolder '       NO_{3} input and output'])
 grid on 
 
 %---------------------------------------
 set(gcf_nit, 'PaperPositionMode', 'manual');
set(gcf_nit, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 10;
xLeft = 0; yTop = 0;

set(gcf_nit,'paperposition',[xLeft yTop xSize ySize])
saveas(gcf_nit, [fileOutput   ' transport in out ' var 'flux'],'png');
%---------------------

filecsv = [fileOutput   var  ' transport_in.csv'];
VarTitle = [ var '_in (g/d) '];
ModelWriteVariable(NIT_IN.Date  , NIT_IN.Data, filecsv, VarTitle )

filecsv = [fileOutput     var ' transport_out.csv'];
VarTitle = [ var '_out (g/d) '];
ModelWriteVariable(NIT_OUT.Date  , NIT_OUT.Data, filecsv, VarTitle )

% --------calculate flux as g//m2/d

NIT_IN_area.Date = NIT_IN.Date(inlet_odd);
NIT_IN_area.Data =  NIT_IN.Data(inlet_odd) ./ wetArea.Data; 

NIT_OUT_area.Date = NIT_OUT.Date;
NIT_OUT_area.Data =  NIT_OUT.Data ./ wetArea.Data; 

filecsv = [fileOutput   var  ' transport_in_perArea.csv'];
VarTitle = [ var '_in (g/m2/d) '];
ModelWriteVariable(NIT_IN_area.Date  , NIT_IN_area.Data, filecsv, VarTitle );

filecsv = [fileOutput   var  ' transport_out_perArea.csv'];
VarTitle = [ var '_out (g/m2/d) '];
ModelWriteVariable(NIT_OUT_area.Date  , NIT_OUT_area.Data, filecsv, VarTitle );
