


% load('D:\Research in UWA\overview of data available in anvil\all_togehter_plotting\anvil.mat');
addpath('E:\Simulation_UWA_WD\2 For model variables\Function');
addpath('E:\Simulation_UWA_WD\2 For model variables\Supporting information');
BasicRead
currentOutput = '3 nitrogen\3 NO3\'; 
fileOutput =  [dicmodel currentFolder '\Output\' currentOutput ];
if ~exist(fileOutput,'dir')      % check  whether the outdir  exists in the file of 'dir';
    mkdir(fileOutput);           % if not exists, create the file of 'outdir'
end

varid = netcdf.inqVarID(ncid,'WQ_NIT_NIT');
NIT_NIT = netcdf.getVar(ncid,varid) /1000*14  ;  %mmol/m3/d to g/m3/d;  %mmol/m3/d to g/m3/d; 

weirNIT_NIT.Date = ResTime;
weirNIT_NIT.Data = mean(NIT_NIT(idx2weirCell,: ))';
 [weirNIT_nonStorm, weirNIT_Storm] =  seperate10minperiod(weirNIT_NIT, period_10min     );

figure
plot(weirNIT_nonStorm.Date, weirNIT_nonStorm.Data, '*');
hold on
plot(weirNIT_Storm.Date, weirNIT_Storm.Data, 'o');
hold on

set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([  currentFolder ' NO_{3} at outlet  ']);
xlim([sTime  eTime]);
ylabel('mg/L'); 
grid on
figure
boxplot(weirNIT_nonStorm.Data)
    
    
file_inflow =  [ dicmodel currentFolder   '\BCs\'   BC_inflow ];
fid = fopen(file_inflow ,'rt');
str = repmat('%f ', [1 24] );
data_inlet = textscan(fid,['%s' str],'Headerlines',1,'Delimiter',',');
ISOTime_in = datenum(data_inlet{1,1},'dd/mm/yyyy HH:MM:SS');
InflowNit.Date  = ISOTime_in;
InflowNit.Data  = data_inlet{1,10}  *N_mmol_g   ;  %  the unit is  mmol /m3  to mg/L

% inletNIT_NIT = InflowNit.Data ;
figure

h(1) = plot(weirNIT_NIT.Date, weirNIT_NIT.Data  );
AddShade([0  0] , [0.6 0.6] , period );
hold on
NIT_UWA_04 =  anvil.SWQ.MSANVCBOUT.HRD.Storm_04.FNOx;
ss = find(sTime <= NIT_UWA_04.Date & NIT_UWA_04.Date <= eTime);
h(2) = plot(NIT_UWA_04.Date(ss,1),NIT_UWA_04.Data(ss,1),'b<'); clear ss
hold on 

NIT_UWA_05 =  anvil.SWQ.MSANVCBOUT.HRD.Storm_05.FNOx;
ss = find(sTime <= NIT_UWA_05.Date & NIT_UWA_05.Date <= eTime);
h(3) = plot(NIT_UWA_05.Date(ss,1),NIT_UWA_05.Data(ss,1),'r<'); clear ss
hold on 
leg1 = legend(h(1:3) , 'modelled NO_{3}', 'Storm 04' , 'Storm 05');
set(leg1,'Location','best');

set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([  currentFolder ' NO_{3} at outlet  ']);
xlim([sTime  eTime]);
ylabel('mg/L'); 
xlabel('Date (2015)');
grid on 

 set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 10;
xLeft = 0; yTop = 0;
set(gcf,'paperposition',[xLeft yTop xSize ySize])

saveas(gcf,[fileOutput  'NO3 modeled and observed at outlet'],'png');
saveas(gcf,[fileOutput  'NO3 modeled and observed at outlet'],'fig');



% filecsv =  [ fileOutput 'NO3_weir.csv' ];
% fid = fopen(filecsv,'wt');
% fprintf(fid,'ISOTime, NO3 concentration (mg/L) \n');
% for i = 1:length(ResTime)
%     fprintf(fid,'%s,',datestr(ResTime(i),'dd/mm/yyyy HH:MM:SS'));
%     fprintf(fid,'%4.4f \n',  weirNIT_NIT(i)  );
% end
% fclose(fid);

% ---------comparsion NO3 at inlet and outlet ------------------------------------
figure
h(1) = plot(InflowNit.Date,  InflowNit.Data  );
hold on

NIT_UWA_04 =  anvil.SWQ.MSANVCBIN.HRD.Storm_04.FNOx;
ss = find(sTime <= NIT_UWA_04.Date & NIT_UWA_04.Date <= eTime);
h(2) = plot(NIT_UWA_04.Date(ss,1),NIT_UWA_04.Data(ss,1),'b*'); clear ss
hold on 

NIT_UWA_05 =  anvil.SWQ.MSANVCBIN.HRD.Storm_05.FNOx;
ss = find(sTime <= NIT_UWA_05.Date & NIT_UWA_05.Date <= eTime);
h(3) = plot(NIT_UWA_05.Date(ss,1),NIT_UWA_05.Data(ss,1),'b*'); clear ss
hold on 
%%%outlet


h(4) = plot(weirNIT_NIT.Date, weirNIT_NIT.Data  );
hold on

hold on
NIT_UWA_04 =  anvil.SWQ.MSANVCBOUT.HRD.Storm_04.FNOx;
ss = find(sTime <= NIT_UWA_04.Date & NIT_UWA_04.Date <= eTime);
h(5) = plot(NIT_UWA_04.Date(ss,1),NIT_UWA_04.Data(ss,1),'rs'); clear ss
hold on 

NIT_UWA_05 =  anvil.SWQ.MSANVCBOUT.HRD.Storm_05.FNOx;
ss = find(sTime <= NIT_UWA_05.Date & NIT_UWA_05.Date <= eTime);
h(6) = plot(NIT_UWA_05.Date(ss,1),NIT_UWA_05.Data(ss,1),'rs'); clear ss
hold on 
AddShade([0  0] , [1.2 1.2] , period );
leg1 = legend(h([1 2 4 5]),  'Inlet ', '', 'Outlet', '');
set(leg1,'Location','best');


set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([  currentFolder ' NO_{3} at inlet and  outlet  ']);
xlim([sTime  eTime]);
ylabel('mg/L'); 
xlabel('Date (2015)');
grid on 
 set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 10;
xLeft = 0; yTop = 0;
set(gcf,'paperposition',[xLeft yTop xSize ySize])
saveas(gcf,[fileOutput  'NO3 modeled at inlet and outlet '],'png');
% saveas(gcf,[fileOutput  'NO3 modeled at inlet and outlet'],'fig');

% % write the NOx concentration at weir
% mean_weir_Nit.Date = ResTime;
% mean_weir_Nit.Data = mean(weirNIT_NIT) ; 

 filename = [ fileOutput 'Nit_weir_10min.csv'];
fid = fopen(filename,'wt');
fprintf(fid,'ISOTime, Nit_weir (mg/L)\n');
for i = 1:length(weirNIT_NIT.Date)
    fprintf(fid,'%s,',datestr(weirNIT_NIT.Date(i),'dd/mm/yyyy HH:MM:SS'));
    fprintf(fid,'%4.4f\n',    weirNIT_NIT.Data(i) );
end
fclose(fid);