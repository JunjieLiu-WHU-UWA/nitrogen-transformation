% load('D:\Research in UWA\overview of data available in anvil\all_togehter_plotting\anvil.mat');
% addpath('E:\Simulation_UWA_WD\2 For model variables\Function');
% addpath('E:\Simulation_UWA_WD\2 For model variables\Supporting information');
% BasicRead

currentOutput = '3 nitrogen\3 NO3\'; 
fileOutput =  [dicmodel currentFolder '\Output\' currentOutput ];
if ~exist(fileOutput,'dir')      % check  whether the outdir  exists in the file of 'dir';
    mkdir(fileOutput);           % if not exists, create the file of 'outdir'
end

varid = netcdf.inqVarID(ncid,'WQ_DIAG_PHY_BCP'); %benthic net production
BCP_uptake_nitrogen = netcdf.getVar(ncid,varid) / 106 *16 * 14 /1000; % convert mmol/m2/day to g/m2/d.
% the conversion of unit , mmol C /m2/day , mmol N /m2/day ,  g N /m2/day 
 [ BCP_uptake_nitrogenSumSpace ,   BCP_uptake_nitrogenCVMean ]  =  bottomLayer( BCP_uptake_nitrogen , Basic,Cell_whole_channel);


figure
subplot(2,1,1)
plot(ResTime, BCP_uptake_nitrogenSumSpace./ 1000) % the unit is kg/d
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([  currentFolder   '   ' 'Mass flux of  benthic nitrogen across  the whole wetland ']);
xlim([sTime  eTime]);
ylabel({'Benthic net productivity'  '(kg N /d)'})      
xlabel('Date (2015)');
grid on 


subplot(2,1,2)
plot(ResTime, BCP_uptake_nitrogenCVMean)  %g/m2/d.
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([  currentFolder   '    ' 'Mean rate flux of  benthic net productivity (BCP) across  the whole  wetland ']);
xlim([sTime  eTime]);
ylabel({'Benthic net productivity'  '(g N /m^{2}/d)'}) ;     
xlabel('Date (2015)');
grid on 

set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 15;
xLeft = 0;  yTop = 0;

set(gcf,'paperposition',[xLeft yTop xSize ySize])

saveas(gcf,[fileOutput  'Benthic  nitrogen uptake across  the whole wetland'],'png');
saveas(gcf,[fileOutput  'Benthic  nitrogen uptake across  the whole wetland'],'fig');


   filecsv =  [ fileOutput 'Benthic  nitrogen uptake_wholeWetland.csv' ];
    
    fid = fopen(filecsv,'wt');

fprintf(fid,'ISOTime, BCP_uptake_nitrogenSumSpace (gN/d), BCP_uptake_nitrogenCVMean(g N/m2/d)  \n');
for i = 1:length(ResTime)
    fprintf(fid,'%s,',datestr(ResTime(i),'dd/mm/yyyy HH:MM:SS'));
    fprintf(fid,'%4.4f,%4.4f\n',  BCP_uptake_nitrogenSumSpace(1,i), BCP_uptake_nitrogenCVMean(1,i));
end
fclose(fid);

%--------------------------------

% 
% file =  [dicmodel currentFolder '\Output\' ];
% fileBenProd = [ file '8. Benthic productivity\BenthicProductivity_wholeWetland.csv'];
% fid = fopen(fileBenProd,'rt');
% data = textscan(fid,'%s %f %f','Headerlines',1,'Delimiter',',');
% dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
% BenthicUptakeNitrogen.Date = dateTime;
% BenthicUptakeNitrogen.Data = data{1,2}; % the original unit is  g O2/d
% BenthicUptakeNitrogen.Data = BenthicUptakeNitrogen.Data / 32  /106 * 16 * 14;
% % the conversion is g O2 ,  mol O2, mol C.  mol N, g N 
% figure
% 
% plot(BenthicUptakeNitrogen.Date , BenthicUptakeNitrogen.Data)
% set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
% title([  currentFolder   '    ' 'NO3 uptake by benthic biomass  across the wetland ']);
% xlim([sTime  eTime]);
% ylabel({ ' (g N /d)'}) 
% xlabel('Date (2015)');
% grid on 
% 
% set(gcf, 'PaperPositionMode', 'manual');
% set(gcf, 'PaperUnits', 'centimeters');
% xSize = 20; ySize = 15;
% xLeft = 0;  yTop = 0;
% set(gcf,'paperposition',[xLeft yTop xSize ySize])
% saveas(gcf,[fileOutput  'NO3 uptake by benthic biomass across wetland'],'png');
% saveas(gcf,[fileOutput  'NO3 uptake by benthic biomass across wetland'],'fig');
% 
% 
%  filecsv=  [ fileOutput  'NO3 uptake by benthic biomass _wholeWetland.csv' ];
%  fid = fopen(filecsv,'wt');
% fprintf(fid,'ISOTime, PHY_NUPSumSpace (g N/d),PHY_NUPCVMean (g N/m2/d) \n');
% for i = 1:length(ResTime)
%     fprintf(fid,'%s,',datestr(ResTime(i),'dd/mm/yyyy HH:MM:SS'));
%     fprintf(fid,'%4.8f,%4.8f \n', PHY_NUP_NO3SumSpace(1,i) ,PHY_NUP_NO3CVMean(1,i));
%                        
% end
% fclose(fid);