
% for lengend

figure
fig_p = subplot(2,1,1)
p = pie2(NOx_in_Storm);
pText = findobj(p,'Type','text');
colormap(fig_p, [ 0.5 0.5 0.5;      %grey
         1 0 0  ; % red   
          0 1 1 ])  ;%cyan
pText = findobj(p,'Type','text');

p(2).Position = [ 0.15  0.5 0 ] .*p(2).Position;
p(4).Position =  [0.9 0.5 0  ].*p(4).Position;
p(6).Position =  [0.4 0.5 0  ].*p(6).Position;
leg1 = legend('Inflow' , 'Sediment flux', ...
              'Nitrification' );
 set(leg1,...
    'Location','eastoutside', 'box', 'off', 'FontSize', 6);
% title([currentFolder '  ' ' NOx budget Storm event' ] );
fig_p = subplot(2,1,2)
p = pie2(NOx_out_Storm);
pText = findobj(p,'Type','text');
colormap(fig_p , [ 0.5  0.5  0.5;      %grey
       0, 0.4470, 0.7410 ; % blue      
          0 1 0;  % green     
          1 1 0]) ;% yellow
      p(2).Position = [ 0.3  0.5 0 ] .*p(2).Position;
      p(4).Position = [ 0.3  0.5 0 ] .*p(4).Position;
            p(8).Position = [ 0.2  1.2 0 ] .*p(8 ).Position;
leg1 = legend('Outflow',  'Denitrification', 'Pelagic net uptake', 'Benthic net uptake');
 set(leg1,...
    'Location','eastoutside', 'box', 'off', 'FontSize', 6);

% title([currentFolder ] );
set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 8; ySize = 8;
xLeft = 0;   yTop = 0;
set(gcf,'paperposition',[xLeft yTop xSize ySize])
% saveas(gcf, [file '3 NO3\Pie NOx Storm in out budget percent'],'png');

print(gcf,[file '3 NO3\Pie NOx Storm in out budget percent_legend.png'],'-dpng','-r300');

