%this script is to analyze the budget of oxygen
clc
% clearvars -except anvil 

addpath('E:\Simulation_UWA_WD\2 For model variables\Function');
addpath('E:\Simulation_UWA_WD\2 For model variables\Supporting information');
BasicRead
file =  [dicmodel currentFolder '\Output\3 nitrogen\' ];


labels = {'Influent','Outfluent','sediment flux', ...
                 'nitrification', 'denitrification'}';
             num_fig = 7;
figure
% the layout of all the fiugre accoring to sourcre and sink of NO3.
% first source, then sink.
% source
% Transport in
fileTran = [file '3 NO3\NO3 transport_in.csv' ];
fid = fopen(fileTran,'rt');
data = textscan(fid,'%s %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
transIN.Date = dateTime;
transIN.Data = data{1,2}; % the unit is g/d
source_NO3(1,1) = trapz(transIN.Date, transIN.Data  );
% g
[ transINnonStorm,  transINStorm, sumtransINperiod ]    = sum_10min_six_period( transIN,  period_10min ); 

subplot(num_fig,1,1)
pp = plot(transIN.Date, transIN.Data);
AddShade([0  0] , [40000 40000] , period );
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel','','TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);
% ylim([0 1000 ]);
ylabel({'NO_{3}',' Input', '(g/d)'});
%  text( sTime + 8,800,'(a)');
 text(0.08,1.1,'(a)','units','normalized');
 title(['Scenario   '  currentFolder])
 grid on 


% sedment flux of NO3
 fileAtm = [ file '3 NO3\Sediment flux of NO3 _wholeWetland.csv'];
 fid = fopen(fileAtm,'rt');
data = textscan(fid,'%s %f %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
SedNO3.Date = dateTime ;
SedNO3.Data = data{1,2} ;% the unit is g/d
source_NO3(2,1) = trapz(SedNO3.Date, SedNO3.Data  );


[ SedNO3nonStorm,  SedNO3Storm, sumSedNO3period ]    = sum_10min_six_period( SedNO3,  period_10min );


subplot(num_fig,1,2)
pp = plot( SedNO3.Date , SedNO3.Data);
AddShade([0  0] , [400 400] , period );
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel','','TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);
% ylim([0 1000 ]);
ylabel({'Sediment flux','NO_{3}', '(g/d)'});
%  text( sTime + 8,800,'(a)');
 text(0.08,1.1,'(b)','units','normalized');
%  title(['Scenario   '  currentFolder])
 grid on 
 
   fileAtm = [ file '2 NH4\Nitrification of NH4 _wholeWetland.csv'];
 fid = fopen(fileAtm,'rt');
data = textscan(fid,'%s %f %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
NitriNH4.Date = dateTime ;
NitriNH4.Data = data{1,2};% the unit is g/d



[ NitriNH4nonStorm,  NitriNH4Storm, sumNitriNH4period ]    = sum_10min_six_period(NitriNH4,  period_10min );



source_NO3(3,1) = trapz(NitriNH4.Date, NitriNH4.Data  );
 subplot(num_fig,1,3)
pp = plot( NitriNH4.Date , NitriNH4.Data);
AddShade([0  0] , [200 200] , period );
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel','','TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);
% ylim([0 1000 ]);
ylabel({'Nitrification','NH_{4}', '(g/d)'});
%  text( sTime + 8,800,'(a)');
 text(0.08,1.1,'(c)','units','normalized');
%  title(['Scenario   '  currentFolder])
 grid on 





 %  sink 
% transport out
fileTran = [ file '3 NO3\NO3 transport_out.csv'];
fid = fopen(fileTran,'rt');
data = textscan(fid,'%s %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
transOut.Date = dateTime;
transOut.Data = data{1,2}; % the unit is g/d
sink_NO3(1,1) = trapz(transOut.Date, transOut.Data  );

[ transOutnonStorm,  transOutStorm, sumtransOutperiod ]    = sum_10min_six_period(transOut,  period_10min );



subplot(num_fig,1,4)
pp = plot(transOut.Date, transOut.Data   );
AddShade([0  0] , [20000 20000] , period );
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel','','TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);
% ylim([0 1000 ]);
ylabel({'NO_{3}',' Output', '(g/d)'});
%  text( sTime + 8,800,'(a)');
 text(0.08,1.1,'(d)','units','normalized');
%  title(['Scenario   '  currentFolder])
 grid on 

 % denitrification of NO3
 fileAtm = [ file '3 NO3\Denitrification of NO3 _wholeWetland.csv'];
 fid = fopen(fileAtm,'rt');
data = textscan(fid,'%s %f %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
DEnitriNO3.Date = dateTime ;
DEnitriNO3.Data = data{1,2} ;% the unit is g/d
sink_NO3(2,1) = trapz(DEnitriNO3.Date, DEnitriNO3.Data  );
 [ DEnitriNO3nonStorm,  DEnitriNO3Storm, sumDEnitriNO3period ]    = sum_10min_six_period(DEnitriNO3,  period_10min );


 
subplot(num_fig,1,5)
pp = plot( DEnitriNO3.Date , DEnitriNO3.Data);
AddShade([0  0] , [1000 1000] , period );
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel','','TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);
% ylim([0 1000 ]);
ylabel({'NO_{3}',' Denitrification', '(g/d)'});
%  text( sTime + 8,800,'(a)');
 text(0.08,1.1,'(e)','units','normalized');
%  title(['Scenario   '  currentFolder])
 grid on 

 
 % NO3 uptake by phytoplankton
 
 fileNO3 = [ file '3 NO3\NO3 uptake by phytoplankton _wholeWetland.csv'];
 fid = fopen(fileNO3,'rt');
data = textscan(fid,'%s %f %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
uptake_NO3.Date = dateTime ;
uptake_NO3.Data = data{1,2} ;% the unit is g/d
sink_NO3(3,1) = trapz(uptake_NO3.Date, uptake_NO3.Data  );
  [ uptake_NO3nonStorm,  uptake_NO3Storm, sumuptake_NO3period ]    = sum_10min_six_period(uptake_NO3,  period_10min );

 
subplot(num_fig,1,6)
pp = plot( uptake_NO3.Date , uptake_NO3.Data);
AddShade([0  0] , [40 40] , period );
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel',timeLable,'TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);
% ylim([0 1000 ]);
ylabel({'NO_{3}',' uptake', '(g/d)'});
%  text( sTime + 8,800,'(a)');
 text(0.08,1.1,'(f)','units','normalized');
%  title(['Scenario   '  currentFolder])
 grid on 

 %  % NO3 uptake by benthic biomass
  fileNO3 = [ file '3 NO3\Benthic  nitrogen uptake_wholeWetland.csv'];
 fid = fopen(fileNO3,'rt');
data = textscan(fid,'%s %f %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
BCP_uptake_NO3.Date = dateTime ;
BCP_uptake_NO3.Data = data{1,2} * 0.5 ;% the unit is g/d. the ratio between NO3 and NH4 is 1:1
sink_NO3(4,1) = trapz(BCP_uptake_NO3.Date, BCP_uptake_NO3.Data  );
  [BCP_uptake_NO3nonStorm,  BCP_uptake_NO3Storm, sumBCP_uptake_NO3period ]    = sum_10min_six_period(BCP_uptake_NO3,  period_10min );

 
subplot(num_fig,1,7)
pp = plot( BCP_uptake_NO3.Date , BCP_uptake_NO3.Data);
AddShade([-5000  -5000] , [5000 5000] , period );
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel',timeLable,'TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);
% ylim([0 1000 ]);
ylabel({'Benthic uptake', 'NO_{3}', '(g/d)'});
%  text( sTime + 8,800,'(a)');
 text(0.08,1.1,'(g)','units','normalized');
%  title(['Scenario   '  currentFolder])
 grid on 
 
 
 
 
 set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 29;
xLeft = 0;   yTop = 0;
set(gcf,'paperposition',[xLeft yTop xSize ySize])
saveas(gcf, [file '\3 NO3\NO3 budget mass'],'png');


%----------------------------------------------
figure
fig_p = subplot(2,1,1);
p = pie(source_NO3);
pText = findobj(p,'Type','text');

colormap(fig_p, [ 0.5 0.5 0.5;      %grey
         1 0 0  ; % red   
          0 1 1 ])  ;%cyan
pText = findobj(p,'Type','text');
%  title(['DON'  currentFolder])
 p(2).Position = [ 0.3  0.5 0 ] .*p(2).Position;
% p(2).Position = [ 0.3  0.5 0 ] .*p(2).Position;
p(6).Position =  [0.4 0.5 0  ].*p(6).Position;


%  title(['Scenario  whole period '  currentFolder])
% leg1 = legend('Influent','Sediment flux', ...
%                  'nitrification' );
%  set(leg1,  'Location','eastoutside');

fig_p = subplot(2,1,2)
p = pie(sink_NO3);
pText = findobj(p,'Type','text');

colormap(fig_p , [ 0.5  0.5  0.5;      %grey
       0, 0.4470, 0.7410 ; % blue      
          0 1 0;  % green     
          1 1 0]) ;% yellow

p(2).Position = [ 0.4  0.5 0 ] .*p(2).Position;
p(4).Position =  [0.4 0.5 0  ].*p(4).Position;
%  p(6).Position =  [0.8 0.6 0  ].*p(6).Position;
p(8).Position =  [0.5 0.6 0  ].*p(8).Position;

%  title(['Scenario   '  currentFolder])
% leg1 = legend('effluent',   'Denitrification', 'uptake ' );
%  set(leg1, 'Location','eastoutside');

set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 4; ySize = 8;
xLeft = 0;   yTop = 0;
set(gcf,'paperposition',[xLeft yTop xSize ySize])
% saveas(gcf, [file '\3 NO3\Pie NO3 budget percent'],'png');
print(gcf,[file '\3 NO3\Pie NO3 budget percent_wholePeriod.png'],'-dpng','-r300');
% 
%------------------------------- non storm period----  in 
NOx_in_nonStorm(1,1)  =  transINnonStorm;
NOx_in_nonStorm(2,1)  = SedNO3nonStorm;
NOx_in_nonStorm(3,1)  = NitriNH4nonStorm;


% out
NOx_out_nonStorm(1,1)  =  transOutnonStorm;
NOx_out_nonStorm(2,1)  =  DEnitriNO3nonStorm;
NOx_out_nonStorm(3,1)  =  uptake_NO3nonStorm;
NOx_out_nonStorm(4,1)  =  BCP_uptake_NO3nonStorm ;
% ------------------storm period
% in
NOx_in_Storm(1,1)  =  transINStorm;
NOx_in_Storm(2,1)  = SedNO3Storm;
NOx_in_Storm(3,1)  = NitriNH4Storm;

% out
NOx_out_Storm(1,1)  =  transOutStorm;
NOx_out_Storm(2,1)  =   DEnitriNO3Storm;
NOx_out_Storm(3,1)  =  uptake_NO3Storm;
NOx_out_Storm(4,1)  =  BCP_uptake_NO3Storm ;
figure
fig_p = subplot(2,1,1)
p = pie(NOx_in_nonStorm);
pText = findobj(p,'Type','text');
colormap(fig_p, [ 0.5 0.5 0.5;      %grey
         1 0 0  ; % red   
          0 1 1 ])  ;%cyan
pText = findobj(p,'Type','text');
%  title(['DON'  currentFolder])
p(2).Position = [ 0.3  0.5 0 ] .*p(2).Position;
p(4).Position =  [0.7 1.0 0  ].*p(4).Position;
p(6).Position =  [0.4 0.8 0  ].*p(6).Position;


% leg1 = legend('Influent' , 'Sediment flux', ...
%               'Nitrification');
%  set(leg1,...
%     'Location','eastoutside');
% title([currentFolder '     ' 'NOx budget non storm period' ] );
fig_p = subplot(2,1,2)
p = pie(NOx_out_nonStorm);
pText = findobj(p,'Type','text');
colormap(fig_p , [ 0.5  0.5  0.5;      %grey
       0, 0.4470, 0.7410  ; % blue      
          0 1 0;  % green     
          1 1 0]) ;% yellow
      p(2).Position = [ 1.0  1.0 0 ] .*p(2).Position;
p(4).Position =  [0.6 0.5 0  ].*p(4).Position;

p(8).Position =  [0.5 1.0 0  ].*p(8).Position;
% leg1 = legend('effluent',  'Denitrification', 'Pelagic uptake', 'Benthic uptake');
%  set(leg1,...
%     'Location','eastoutside');
% title([currentFolder ] );
set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 4; ySize = 8;
xLeft = 0;   yTop = 0;
set(gcf,'paperposition',[xLeft yTop xSize ySize])
% saveas(gcf, [file '3 NO3\Pie NOx nonStorm in out budget percent'],'png');
print(gcf,[file '3 NO3\Pie NOx nonStorm in out budget percent.png'],'-dpng','-r300');

figure
fig_p = subplot(2,1,1)
p = pie2(NOx_in_Storm);
pText = findobj(p,'Type','text');
colormap(fig_p, [ 0.5 0.5 0.5;      %grey
         1 0 0  ; % red   
          0 1 1 ])  ;%cyan
pText = findobj(p,'Type','text');

p(2).Position = [ 0.15  0.5 0 ] .*p(2).Position;
p(4).Position =  [0.9 0.5 0  ].*p(4).Position;
p(6).Position =  [0.4 0.5 0  ].*p(6).Position;
% leg1 = legend('Inflow' , 'Sediment flux', ...
%               'Nitrification' );
%  set(leg1,...
%     'Location','eastoutside', 'box', 'off', 'FontSize', 6);
% title([currentFolder '  ' ' NOx budget Storm event' ] );
fig_p = subplot(2,1,2)
p = pie2(NOx_out_Storm);
pText = findobj(p,'Type','text');
colormap(fig_p , [ 0.5  0.5  0.5;      %grey
       0, 0.4470, 0.7410 ; % blue      
          0 1 0;  % green     
          1 1 0]) ;% yellow
      p(2).Position = [ 0.3  0.5 0 ] .*p(2).Position;
      p(4).Position = [ 0.3  0.5 0 ] .*p(4).Position;
            p(8).Position = [ 0.2  1.2 0 ] .*p(8 ).Position;
% leg1 = legend('Outflow',  'Denitrification', 'Pelagic net uptake', 'Benthic net uptake');
%  set(leg1,...
%     'Location','eastoutside', 'box', 'off', 'FontSize', 6);

% title([currentFolder ] );
set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 4; ySize = 8;
xLeft = 0;   yTop = 0;
set(gcf,'paperposition',[xLeft yTop xSize ySize])
% saveas(gcf, [file '3 NO3\Pie NOx Storm in out budget percent'],'png');

print(gcf,[file '3 NO3\Pie NOx Storm in out budget percent.png'],'-dpng','-r300');


% for lengend

figure
fig_p = subplot(2,1,1)
p = pie2(NOx_in_Storm);
pText = findobj(p,'Type','text');
colormap(fig_p, [ 0.5 0.5 0.5;      %grey
         1 0 0  ; % red   
          0 1 1 ])  ;%cyan
pText = findobj(p,'Type','text');

p(2).Position = [ 0.15  0.5 0 ] .*p(2).Position;
p(4).Position =  [0.9 0.5 0  ].*p(4).Position;
p(6).Position =  [0.4 0.5 0  ].*p(6).Position;
leg1 = legend('Inflow' , 'Sediment flux', ...
              'Nitrification' );
 set(leg1,...
    'Location','eastoutside', 'box', 'off', 'FontSize', 6);
% title([currentFolder '  ' ' NOx budget Storm event' ] );
fig_p = subplot(2,1,2)
p = pie2(NOx_out_Storm);
pText = findobj(p,'Type','text');
colormap(fig_p , [ 0.5  0.5  0.5;      %grey
       0, 0.4470, 0.7410 ; % blue      
          0 1 0;  % green     
          1 1 0]) ;% yellow
      p(2).Position = [ 0.3  0.5 0 ] .*p(2).Position;
      p(4).Position = [ 0.3  0.5 0 ] .*p(4).Position;
            p(8).Position = [ 0.2  1.2 0 ] .*p(8 ).Position;
leg1 = legend('Outflow',  'Denitrification', 'Pelagic uptake', 'Benthic net uptake');
 set(leg1,...
    'Location','eastoutside', 'box', 'off', 'FontSize', 6);

% title([currentFolder ] );
set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 8; ySize = 8;
xLeft = 0;   yTop = 0;
set(gcf,'paperposition',[xLeft yTop xSize ySize])
% saveas(gcf, [file '3 NO3\Pie NOx Storm in out budget percent'],'png');

print(gcf,[file '3 NO3\Pie NOx Storm in out budget percent_legend.png'],'-dpng','-r300');



%----------------------sourc ----
% figure
% p = pie(source_NO3);
% pText = findobj(p,'Type','text');
% 
% leg1 = legend('Influent','Outfluent','Sediment flux', 'Denitrification', 'nitrification' );
%  set(leg1,...
%     'Location','eastoutside');
% 
% set(gcf, 'PaperPositionMode', 'manual');
% set(gcf, 'PaperUnits', 'centimeters');
% xSize = 10; ySize = 10;
% xLeft = 0;   yTop = 0;
% set(gcf,'paperposition',[xLeft yTop xSize ySize])
% saveas(gcf, [file '\3 NO3\Pie NO3 budget percent'],'png');


% 
% percentValues = get(pText,'String'); 
% txt = {'Influent : ','Outfluent :','Atmospheric flux :', ...
%                 'SOD :', 'PGPP :', 'NEP :' }'; 
% combinedtxt = strcat(txt,percentValues);
% 
% pText(1).String = combinedtxt(1);
% pText(2).String = combinedtxt(2);
% pText(3).String = combinedtxt(3);
% pText(4).String = combinedtxt(4);
% pText(5).String = combinedtxt(5);
% pText(6).String = combinedtxt(6);




% calculate kv for long time

net_removal.Date =  DEnitriNO3.Date;
net_removal.Data =  DEnitriNO3.Data + uptake_NO3.Data +  BCP_uptake_NO3.Data ...
                                  - SedNO3.Data - NitriNH4.Data; 
figure
plot(net_removal.Date  , net_removal.Data, '*'  )

net_removal_area.Date = net_removal.Date;
net_removal_area.Data = net_removal.Data ./ wetArea.Data;

figure
plot(net_removal_area.Date , net_removal_area.Data, '*')




file_inflow =  [ dicmodel currentFolder   '\BCs\'   BC_inflow ];
fid = fopen(file_inflow ,'rt');
str = repmat('%f ', [1 24] );
data_inlet = textscan(fid,['%s' str],'Headerlines',1,'Delimiter',',');
ISOTime_in = datenum(data_inlet{1,1},'dd/mm/yyyy HH:MM:SS');
% Inflow.Date = ISOTime_in;
% Inflow.Data = data_inlet{1,2};

InflowNit.Date  = ISOTime_in;
InflowNit.Data  = data_inlet{1,10} *N_mmol_g ;  %  convert   mmol /m3 to mg/L

figure
plot(InflowNit.Date ,InflowNit.Data, '*'  )

iii_odd = (1: 2 :17568)';

net_removal_area_Cin.Date = net_removal.Date; 
net_removal_area_Cin.Data = net_removal.Data ./ wetArea.Data ./ InflowNit.Data(iii_odd);

net_removal_area_CinDaily = dailySum(net_removal_area_Cin);


figure
plot(net_removal_area_CinDaily.Date ,net_removal_area_CinDaily.Data, '*' )

%-------------------------------------
fileRet = [  dicmodel currentFolder  '\Output\11. Residence time\'  'Residence_Time_weir.csv'];
 fid = fopen(fileRet,'rt');
data = textscan(fid,'%s %f','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
Weir_RET.Date = dateTime ;
Weir_RET.Data = data{1,2} ; %d
Weir_RETDay = dailyDelta(Weir_RET);
transport.Date = Weir_RETDay.Date;
transport.Data = 600 ./ Weir_RETDay.varMean;

Dam.Date = transport.Date;
Dam.Data  = net_removal_area_CinDaily.Data ./transport.Data;

figure
plot(Dam.Date ,Dam.Data , '*')
xlim([sTime  eTime]);
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel',timeLable,'TickLength',[0.005 0.015]);
ylabel('Damkohlar')
title('NO3')
set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 15; ySize = 10;
xLeft = 0;   yTop = 0;
set(gcf,'paperposition',[xLeft yTop xSize ySize])
saveas(gcf, [file '3 NO3\Damkohlar'],'png');
% 
% transINDaily = dailySum(transIN);
% 
% figure
% plot(net_removalDaily.Date   ,net_removalDaily.Data, '*' ) 
% hold on
% plot(transINDaily.Date ,transINDaily.Data  , 'o')
% figure
% plot(net_removalDaily.Date  , net_removalDaily.Data./transINDaily.Data, '*' )
% 
% 
% 
% set(gca,'XTick',[ datenum(timeTick )],'XTickLabel',timeLable,'Tickngth',[0.005 0.015]);
% 



