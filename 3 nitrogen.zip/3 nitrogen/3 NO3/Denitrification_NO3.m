


% load('D:\Research in UWA\overview of data available in anvil\all_togehter_plotting\anvil.mat');
% addpath('E:\Simulation_UWA_WD\2 For model variables\Function');
% addpath('E:\Simulation_UWA_WD\2 For model variables\Supporting information');
% BasicRead
currentOutput = '3 nitrogen\3 NO3\'; 
fileOutput =  [dicmodel currentFolder '\Output\' currentOutput ];
if ~exist(fileOutput,'dir')      % check  whether the outdir  exists in the file of 'dir';
    mkdir(fileOutput);           % if not exists, create the file of 'outdir'
end

varid = netcdf.inqVarID(ncid,'WQ_DIAG_NIT_DENIT');
NIT_DENIT = netcdf.getVar(ncid,varid) /1000*14  ;  %mmol/m3/d to g/m3/d; 

fileBasicmat = [dicmodel currentFolder '\Output\Basic.mat'];
load(fileBasicmat);

[NIT_DENITSumSpace, NIT_DENITCVMean ]  = ThreeVolume2twoarea(NIT_DENIT, Basic, Cell_whole_channel);

%the unit of first variable  is g N /d,
% the unit of second variable is g N/m2/d.

figure
subplot(2,1,1)
plot(ResTime, NIT_DENITSumSpace)
hold on
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([  currentFolder   '    ' 'Denitrification of NO_{3} across the wetland ']);
xlim([sTime  eTime]);
ylabel({ ' (g N /d)'}) 
xlabel('Date (2015)');
grid on 

subplot(2,1,2)
plot(ResTime, NIT_DENITCVMean)
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([  currentFolder   '    ' 'Denitrification of NO_{3} across the wetland ']);
xlim([sTime  eTime]);
ylabel({ ' (g N /m2  /d)'}) 
xlabel('Date (2015)');
grid on 


set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 15;
xLeft = 0;  yTop = 0;
set(gcf,'paperposition',[xLeft yTop xSize ySize])
saveas(gcf,[fileOutput  'Denitrification of NO3 across wetland'],'png');
saveas(gcf,[fileOutput  'Denitrification of NO3 across wetland'],'fig');


filecsv=  [ fileOutput  'Denitrification of NO3 _wholeWetland.csv' ];
 fid = fopen(filecsv,'wt');
fprintf(fid,'ISOTime, NIT_DENITSumSpace (g N/d),NIT_DENITCVMean(g N/m2/d) \n');
for i = 1:length(ResTime)
    fprintf(fid,'%s,',datestr(ResTime(i),'dd/mm/yyyy HH:MM:SS'));
    fprintf(fid,'%4.8f,%4.8f \n', NIT_DENITSumSpace(1,i) ,NIT_DENITCVMean(1,i));
                       
end
fclose(fid);
 