

 clearvars -except anvil
 close all
 clc
% load('E:\Simulation_UWA_WD\2 For model variables\Supporting information\anvil.mat');
 addpath('E:\Simulation_UWA_WD\2 For model variables\Function');
 addpath('E:\Simulation_UWA_WD\2 For model variables\Supporting information');

yysTime_05_17  = datenum('2005/01/01 00:00:00');
 yyeTime_05_17  = datenum('2017/12/31 23:55:00');
 yyTick_05_17 = { '2005/01/01' ...
                     '2006/01/01' ... 
                     '2007/01/01'...
                     '2008/01/01'...
                     '2009/01/01'...
                     '2010/01/01' ...
                     '2011/01/01' ...
                      '2012/01/01 '...
                      '2013/01/01 '...
                      '2014/01/01 '...
                      '2015/01/01 '...
                      '2016/01/01 '...
                      '2017/01/01 ' }';
yyLable_05_17 = {'05' '06' '07'  '08' '09' '10' '11' '12' '13' '14' '15' '16' '17'    }';  


NIT_DoW_inlet =  anvil.SWQ.MSANVCBIN.LRD.DoW.WQ_NIT_NIT;
NIT_DoW_inlet.Data =  NIT_DoW_inlet.Data / 1000 *14;
FNOx_UWA_inlet_storm3 = anvil.SWQ.MSANVCBIN.HRD.daily.dailyStorm_03.FNOx;
FNOx_UWA_inlet_storm4 = anvil.SWQ.MSANVCBIN.HRD.daily.dailyStorm_04.FNOx;
FNOx_UWA_inlet_storm5 = anvil.SWQ.MSANVCBIN.HRD.daily.dailyStorm_05.FNOx;
FNOx_UWA_inlet_Opportunistic = anvil.SWQ.MSANVCBIN.HRD.Opportunistic.FNOx;

 finalVar =   addStructVar(NIT_DoW_inlet  ,FNOx_UWA_inlet_storm3 );
 finalVar =   addStructVar( finalVar   ,FNOx_UWA_inlet_storm4 );
  finalVar =   addStructVar( finalVar   ,FNOx_UWA_inlet_storm5 );
   finalVar =   addStructVar( finalVar   ,FNOx_UWA_inlet_Opportunistic  );
   
   
   %--------------------------------
fileFlowDaily  = 'E:\Simulation_UWA_WD\1 For model\0 boundaryPlot\longTermtrendNutrient\Flow_20050101_20180630.csv';
fid = fopen(fileFlowDaily ,'rt');
data = textscan(fid,'%s %f','Headerlines',1,'Delimiter',',');
Flow_05_18.Date = datenum(data{1,1},'yyyy-mm-dd');
Flow_05_18.Data = data{1,2};


%------------------------------------
fileInletFlow = 'E:\Simulation_UWA_WD\1 For model\0 boundaryPlot\longTermtrendNutrient\Inlet_LongDischarge2012_2017 daily.csv';
fid = fopen(fileInletFlow,'rt');
dataFlow = textscan(fid,'%s %f','Headerlines',1,'Delimiter',',');
LongDis.Date = datenum(dataFlow{1,1},'yyyy/mm/dd');
LongDis.Data = dataFlow{1,2};


% combine the generaated Flow and measued flow together
gene_ob_flow = Flow_05_18;
 
for  ii = 1 : length(LongDis.Date)
     ss = find( LongDis.Date(ii) == gene_ob_flow.Date  );
     if ss & ~isnan(LongDis.Data(ii))
         gene_ob_flow.Data(ss)  =  LongDis.Data(ii);
     end
end

figure
plot(gene_ob_flow.Date  , gene_ob_flow.Data )
datetick('x', 19)

%-----------------
fileAirTemp = 'E:\Simulation_UWA_WD\1 For model\0 boundaryPlot\longTermtrendNutrient\dailyAverageAirTemp2005to201806.csv';
fid = fopen(fileAirTemp,'rt');
dataAirTemp = textscan(fid,'%s %f','Headerlines',1,'Delimiter',',');
LongAirTemp.Date = datenum(dataAirTemp{1,1},'dd/mm/yyyy');
LongAirTemp.Data = dataAirTemp{1,2};





% zero_Var = zeros( length(finalVar.Date)  , 1) ;
%  ss_1 = find(   datenum(2012, 7, 19)  <=  finalVar.Date   & finalVar.Date <= datenum(2017, 2, 1)    ) ;
%  ss_2 = find(  datenum(2017, 4, 13)  <=  finalVar.Date   & finalVar.Date <= datenum(2017, 7, 18) )
%  zero_Var(ss_1) = 1;
%  zero_Var(ss_2) = 1;
  
%  finalVarPeriod.Date = finalVar.Date(logical(zero_Var));
%   finalVarPeriod.Data = finalVar.Data(logical(zero_Var));
  flow_target    =  findFlowDateNutrients(  finalVar.Date, gene_ob_flow );
  AirTemp_target    =  findFlowDateNutrients(  finalVar.Date, LongAirTemp );
% finalVarPeriod.Data(49) = mean(finalVarPeriod.Data);
% 
gene_ob_flow.Date
% color_nonStorm = [0 0 1];
% color_Storm = [1 0 0];
% figure
% loglog(flow_target.Data,finalVarPeriod.Data, '*' ) 
% hold on 
% PositionEq =   [0.155891792267715 0.724216670270468 0.580874872838252 0.122040072859745];
% plotTrendLine(   log(flow_target.Data)   , log( finalVarPeriod.Data), 'poly1', ... 
% color_nonStorm, PositionEq) ;
%    
%  [eq, gof, output ] =  fit(log(flow_target.Data)  , log( finalVarPeriod.Data) , 'poly1');
 

figure
subplot(2,1, 1)
plot(AirTemp_target.Date   , AirTemp_target.Data, '*' )
 hold on
  set(gca,'XTick',[datenum(yyTick_05_17  )],'XTickLabel',yyLable_05_17,'TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
title('The value of air temperature and flow corresponding to sample date of NOx')
box(gca,'on');
xlabel('Year')
xlim([yysTime_05_17  yyeTime_05_17]);
ylabel({'Air temperature', '(^{o}C)'});
grid on 
 subplot(2, 1, 2)
 plot( flow_target.Date  ,flow_target.Data, '*' )
 set(gca,'XTick',[datenum(yyTick_05_17  )],'XTickLabel',yyLable_05_17,'TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
% title('The model temp and flow')
box(gca,'on');
xlabel('Year')
xlim([yysTime_05_17  yyeTime_05_17]);
ylabel({'flow', '(m^{3}/s)'});
grid on 
set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 10;
xLeft = 0; yTop = 0;

set(gcf,'paperposition',[xLeft yTop xSize ySize])
saveas(gcf, [   'Target period temp flow for NOx'],'png');
saveas(gcf, [ 'Target period temp flow for NOx'],'fig');

 x1 = log(AirTemp_target.Data);
x2 =  log(flow_target.Data);    % Contains NaN data
y = log(finalVar.Data);
X = [ones(size(x1))  x1  ];
[b_temp_Q,  ~, ~, ~,  stats_temp_Q] = regress(y,X)  ;

[eq, gof, output ] = fit(AirTemp_target.Data ,    finalVar.Data  ,  'exp1'); 

plot(f,x,y)
figure
plot( AirTemp_target.Data ,  finalVar.Data  , '*'  )
% scatter3(x1,x2,y,'*r')
% % zlim([0 1.5]);
% hold on
%  
%  figure
% x1 = AirTemp_target.Data;
% x2 =  flow_target.Data;    % Contains NaN data
% y = finalVarPeriod.Data;
% X = [ones(size(x1)) x1 x2  ];
% [b,bint,r,rint,stats] = regress(y,X)  ;
% scatter3(x1,x2,y,'*r')
% % zlim([0 1.5]);
% hold on
% 
% x1fit = min(x1):1:max(x1);
% x2fit = min(x2): 0.01 : max(x2);
% [X1FIT,X2FIT] = meshgrid(x1fit,x2fit);
% YFIT = b(1) + b(2)*X1FIT + b(3)*X2FIT  ;
% mesh(X1FIT,X2FIT,YFIT)
% 
% grid on 
% xlabel(' Water temp (^{\circ}C)', 'Rotation',30);
% ylabel('Inflow rate (m^{3}/s)', 'Rotation',-30);
% zlabel('NOx (mg/L)');
% 
% % leg1 = legend('Non storm period','Storm event');
% % set(leg1,...
% %     'Position',[0.22104526958291 0.645307917888567 0.219226856561546 0.0773460410557185]);
% 
% % title([ 'scenario'  currentFolder  ]);
%  set(gcf, 'PaperPositionMode', 'manual');
% set(gcf, 'PaperUnits', 'centimeters');
% xSize = 20; ySize = 10;
% xLeft = 0; yTop = 0;
% 
% set(gcf,'paperposition',[xLeft yTop xSize ySize])
% saveas(gcf, [   ' Relationship NOx_Flow waterTemp'],'png');
% saveas(gcf, [ ' Relationship NOx__Flow waterTemp'],'fig');
% 

for ii = 1 : length(flow_target.Data)
    
   model_temp_NOx(ii, 1) = exp( b_temp_Q(1) + b_temp_Q(2)* log(AirTemp_target.Data(ii)) + b_temp_Q(3) * log(flow_target.Data(ii)) ) ;
    
end



figure
plot( finalVar.Date,  finalVar.Data, '*')
 hold on 
%  plot( finalVarPeriod.Date,  model_temp_NOx , 'o')
%  hold on 
%  hline = refline([0 mean(finalVarPeriod.Data )]);
%  hline.Color = 'r';
%  leg1 = legend('Measured', 'Modelled', 'Measured average');
%  set(leg1, 'location', 'best');
set(gca,'XTick',[datenum(yyTick_05_17  )],'XTickLabel',yyLable_05_17,'TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
title('The model temp and flow')
box(gca,'on');
xlabel('Year')
xlim([yysTime_05_17  yyeTime_05_17]);
ylabel({'NOx', '(mg/L)'});
grid on 
set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 10;
xLeft = 0; yTop = 0;

set(gcf,'paperposition',[xLeft yTop xSize ySize])
saveas(gcf, [   'Measured and modelled NOx temp flow'],'png');
saveas(gcf, [ 'Measured and modelled NOx temp flow'],'fig');
[mae_temp_Q, rmse_temp_Q, ns_temp_Q]    = modelPerformance( log(finalVarPeriod.Data),  log( model_temp_NOx) );

% datestr('x', 19)
figure
plot(finalVarPeriod.Data  ,model_temp_NOx , '*'  )
hline = refline(1,0);
hline.Color = 'r';
title('The model temp and flow')
xlabel('Measured NOx (mg/L)');
ylabel('Modelled NOx (mg/L)');

set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 10; ySize = 10;
xLeft = 0; yTop = 0;

set(gcf,'paperposition',[xLeft yTop xSize ySize])
saveas(gcf, [   'Performance_Measured and modelled NOx temp flow'],'png');
saveas(gcf, [ 'Performance_Measured and modelled NOx temp flow'],'fig');

% find corresponding flow rate on the date of nutrients
% 
% 
% length(NIT_DoW_inlet.Date)
% length(orignalVar.Date)
% length( finalVar.Date)
% figure
% plot( NIT_DoW_inlet.Date , NIT_DoW_inlet.Data, '*');
% hold on 
% plot( orignalVar.Date , orignalVar.Data, 'o');
% hold on 


% regeresson betweeen discharge and julian day

JulianDay_Var =  calculateJulianDay(finalVarPeriod.Date);


x1 = log(JulianDay_Var.JD);
x2 =  log(flow_target.Data);    % Contains NaN data
y = log (finalVarPeriod.Data);
X = [ones(size(x1)) x1 x2  ];
[b_Julian_Q, ~ ,~ ,~ , stats_Julian_Q] = regress(y,X)  ;
% scatter3(x1,x2,y,'*r')
% zlim([0 1.5]);
% hold on

for ii = 1 : length(flow_target.Data)
    
   model_Julian_NOx(ii, 1) =  exp( b_Julian_Q(1) + b_Julian_Q(2)*  log(JulianDay_Var.JD(ii)) + b_Julian_Q(3) * log( flow_target.Data(ii)));
    
end
[mae_Julian_Q, rmse_Julian_Q, ns_Julian_Q]    = modelPerformance( log( finalVarPeriod.Data), log( model_Julian_NOx));

figure
plot( finalVarPeriod.Date,  finalVarPeriod.Data, '*')
 hold on 
 plot( finalVarPeriod.Date,  model_Julian_NOx, 'o')
 hold on 
 hline = refline([0 mean(finalVarPeriod.Data )]);
 hline.Color = 'r';
 leg1 = legend('Measured', 'Modelled', 'Measured average');
 set(leg1, 'location', 'best');
set(gca,'XTick',[datenum(yyTick_05_17  )],'XTickLabel',yyLable_05_17,'TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
title('The model Julian day and flow')
box(gca,'on');
xlabel('Year')
xlim([yysTime_05_17  yyeTime_05_17]);
ylabel({'NOx', '(mg/L)'});
grid on 
set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 10;
xLeft = 0; yTop = 0;

set(gcf,'paperposition',[xLeft yTop xSize ySize])
saveas(gcf, [   'Measured and modelled NOx Julian day flow'],'png');
saveas(gcf, [ 'Measured and modelled NOx Julian day flow'],'fig');

figure
plot(finalVarPeriod.Data  , model_Julian_NOx , '*'  )
hline = refline(1,0);
hline.Color = 'r';
title('The model Julian and flow')
xlabel('Measured NOx (mg/L)');
ylabel('Modelled NOx (mg/L)');

set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 10; ySize = 10;
xLeft = 0; yTop = 0;

set(gcf,'paperposition',[xLeft yTop xSize ySize])
saveas(gcf, [   'Performance_Measured and modelled NOx Julian flow'],'png');
saveas(gcf, [ 'Performance_Measured and modelled NOx Julian flow'],'fig');


% generation of NOx duirng the April and May 2015
sTime  = datenum('2015/04/01 00:00:00');
 eTime  = datenum('2015/05/31 23:55:00');
 timeTick = {'2015/04/01 00:00:00'...
                  '2015/04/10 00:00:00'...
                  '2015/04/20 00:00:00'...
                  '2015/05/01 00:00:00'...
                  '2015/05/10 00:00:00'...
                  '2015/05/20 00:00:00'...
                  '2015/05/31 00:00:00'}';
timeLable = {' Apr 01' ' Apr 10'  ' Apr 20'   ' May 01' ' May 10'   ' May 20'  ' May 31'   }';  
period = { '01/04/2015', '06/04/2015' , ...
                 '07/04/2015',   '14/04/2015', ...
                   '15/04/2015',   '30/04/2015', ...
                   '01/05/2015',  '5/05/2015', ...
                   '6/05/2015',    '15/05/2015', ...
                   '16/05/2015',    '21/05/2015', ...
                   '22/05/2015', '31/05/2015' };

ss_temp = find( sTime  <=    LongAirTemp.Date  &   LongAirTemp.Date <= eTime );
AirTemp_period.Date =  LongAirTemp.Date(ss_temp);
AirTemp_period.Data =  LongAirTemp.Data(ss_temp);

ss_flow = find( sTime  <=    LongDis.Date  &   LongDis.Date <= eTime );
Flow_period.Date =  LongDis.Date(ss_flow);
Flow_period.Data =  LongDis.Data(ss_flow); % the unit is m3/s

generate_temp_NOx.Date = AirTemp_period.Date;
for ii = 1 : length(AirTemp_period.Data)
    
   generate_temp_NOx.Data(ii, 1) = exp( b_temp_Q(1) + b_temp_Q(2)* log(AirTemp_period.Data(ii)) + b_temp_Q(3) * log(Flow_period.Data(ii)) ) ;
    
end

figure
subplot(2,1,1)
plot(AirTemp_period.Date, AirTemp_period.Data, '*')
hold on
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
subplot(2,1,2)
plot(Flow_period.Date, Flow_period.Data, '*')
hold on
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
%-------------------------------------------
figure
plot( generate_temp_NOx.Date  , generate_temp_NOx.Data, '*')
hold on 

FNOx_UWA_inlet_storm4 = anvil.SWQ.MSANVCBIN.HRD.daily.dailyStorm_04.FNOx;
plot(FNOx_UWA_inlet_storm4.Date, FNOx_UWA_inlet_storm4.Data, 'sk' );
hold on 
FNOx_UWA_inlet_storm5 = anvil.SWQ.MSANVCBIN.HRD.daily.dailyStorm_05.FNOx;
plot(FNOx_UWA_inlet_storm5.Date, FNOx_UWA_inlet_storm5.Data, '+k' );
hold on 

AddShade([0 0], [1.2  1.2 ], period  )
leg1 = legend('Generated NOx', 'Obserbed NOx in April' , 'Obserbed NOx in May');
set(leg1,'Position',[0.294456066945607 0.803539019963702 0.228556485355648 0.0957350272232304]);
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([   ' Generated NOx ']);
xlim([sTime  eTime]);
ylim([ 0   1.2]);
ylabel('NOx (mg/L)'); 
xlabel('Date (2015)');
grid on

 set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 10;
xLeft = 0;   yTop = 0;
set(gcf,'paperposition',[xLeft yTop xSize ySize])
saveas(gcf,[  'Generated NOx '],'png');
saveas(gcf,[ 'Generated NOx '],'fig');



writeDaily(generate_temp_NOx, 'daily_generated_NOx.csv', 'NOx (mg/L)')
 generate_temp_NOx_5min =  interpolate5min( generate_temp_NOx);
 writeMinute(generate_temp_NOx_5min, '5min_generated_NOx.csv', 'NOx (mg/L)');
