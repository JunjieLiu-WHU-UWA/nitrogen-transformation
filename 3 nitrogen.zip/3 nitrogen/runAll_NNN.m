


addpath('E:\Simulation_UWA_WD\3 nitrogen\2 NH4');
addpath('E:\Simulation_UWA_WD\3 nitrogen\3 NO3');
addpath('E:\Simulation_UWA_WD\3 nitrogen\4 DON');
addpath('E:\Simulation_UWA_WD\3 nitrogen\5 PON');
addpath('E:\Simulation_UWA_WD\3 nitrogen\6 TN');

CalibriationNH4
Nitrification_NH4
Sediment_flux_NH4
uptake_NH4_PHY
Transport_in_out_NH4

calibriationNOx
Denitrification_NO3
SedimentFlux_NO3
uptake_NO3_PHY
benthic_uptake_nitrogen
transport_in_out_NO3

CalibriationDON
Miner_DON
SedimentFlux_DON
Transport_in_out_DON

CalibriationPON
Decom_PON
Settle_PON
transport_in_out_PON

CalibriationTN
compositionOfTN

OutletStatistical_calibriation_longTerm

Inlet_outlet_NH4_NO3_DON_PON_TN

Process_mass_sediment_flux
compare_rate_internal_process
compare_rate_sediment_flux
Process_mass_influent_effluent
Process_mass_internal_process


compareRatetransportInOut

% budget analysis
Budget_NH4_figure
budget_NO3_figure
Budget_DON_figure
budget_PON_figure
