% clearvars -except anvil sTime eTime   timeTick timeLable dicmodel currentFolder
clc
close all
% addpath('E:\Simulation_UWA_WD\2 For model variables\Function');
% addpath('E:\Simulation_UWA_WD\2 For model variables\Supporting information');
% BasicRead
currentOutput = '3 nitrogen\'; 
fileOutput =  [dicmodel currentFolder '\Output\' currentOutput ];
if ~exist(fileOutput,'dir')      % check  whether the outdir  exists in the file of 'dir';
    mkdir(fileOutput);           % if not exists, create the file of 'outdir'
end
num_fig = 6;



rate_pro = figure
subplot( num_fig, 1, 1)
fileNH4 = [ fileOutput '2 NH4\Nitrification of NH4 _wholeWetland.csv'];
fid = fopen(fileNH4,'rt');
data = textscan(fid,'%s %f %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
NH4_nitri.Date = dateTime;
NH4_nitri.Data = data{1,2};
[ NH4_nitrinonStorm,  NH4_nitriStorm, sumNH4_nitriperiod ]    =  ...
    sum_10min_six_period( NH4_nitri,  period_10min );

pp = plot(NH4_nitri.Date  , NH4_nitri.Data   );
hold on 
AddShade([0  0] , [200  200] , period );
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel','','TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);
ylabel({'Nitrification',' NH_{4}', '(g/d)'});
%  text( sTime + 8,800,'(a)');
 text(0.08,1.1,'(a)','units','normalized');
 title([ currentFolder])
 grid on 



subplot( num_fig, 1, 2)
fileNH4 = [ fileOutput '3 NO3\Denitrification of NO3 _wholeWetland.csv'];
fid = fopen(fileNH4,'rt');
data = textscan(fid,'%s %f %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
NO3_denitri.Date = dateTime;
NO3_denitri.Data = data{1,2};

[ NO3_denitrinonStorm,  NO3_denitriStorm, sumNO3_denitriperiod ]    =  ...
    sum_10min_six_period( NO3_denitri,  period_10min );

pp = plot(NO3_denitri.Date , NO3_denitri.Data   )
hold on 
AddShade([0  0] , [1000  1000] , period );
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel','','TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);
ylabel({'Denitrification',' NO_{3}', '(g/d)'});
%  text( sTime + 8,800,'(a)');
 text(0.08,1.1,'(b)','units','normalized');
%  title([ currentFolder])
 grid on 
 
 
subplot( num_fig, 1, 3)
file = [ fileOutput '4 DON\Mineralisation of DON _wholeWetland.csv'];
fid = fopen(file,'rt');
data = textscan(fid,'%s %f %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');

DON_miner.Date = dateTime;
DON_miner.Data = data{1,2};

[ DON_minernonStorm,  DON_minerStorm, sumDON_minerperiod ]    =  ...
    sum_10min_six_period( DON_miner,  period_10min );
pp =  plot(DON_miner.Date  , DON_miner.Data   );
hold on 
AddShade([0  0] , [60  60] , period );
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel','','TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);
ylabel({'Mineralisation ',' DON', '(g/d)'});
%  text( sTime + 8,800,'(a)');
 text(0.08,1.1,'(c)','units','normalized');
%  title([ currentFolder])
 grid on 
 
 
subplot( num_fig, 1, 4)
file = [ fileOutput '5 PON\PON decomposition _wholeWetland.csv'];
fid = fopen(file,'rt');
data = textscan(fid,'%s %f %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');

PON_decom.Date = dateTime;
PON_decom.Data = data{1,2};
pp = plot(PON_decom.Date  , PON_decom.Data   )
hold on 
AddShade([0  0] , [1  1] , period );
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel','','TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);
ylim([ 0 1 ]);
ylabel({'Decomposition ','PON', '(g/d)'});
%  text( sTime + 8,800,'(a)');
 text(0.08,1.1,'(d)','units','normalized');
%  title([ currentFolder])
 grid on 

subplot( num_fig, 1, 5)
file = [ fileOutput '3 NO3\NO3 uptake by phytoplankton _wholeWetland.csv'];
fid = fopen(file,'rt');
data = textscan(fid,'%s %f %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');

NO3_pelagic.Date = dateTime;
NO3_pelagic.Data = data{1,2};
[ NO3_pelagicnonStorm,  NO3_pelagicStorm, sumNO3_pelagicperiod ]    =  ...
    sum_10min_six_period( NO3_pelagic,  period_10min );
h(1) =  plot(NO3_pelagic.Date  , NO3_pelagic.Data, 'k-'   );   %g/d
hold on 

file = [ fileOutput '2 NH4\NH4 uptake by phytoplankton _wholeWetland.csv'];
fid = fopen(file,'rt');
data = textscan(fid,'%s %f %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
NH4_pelagic.Date = dateTime;
NH4_pelagic.Data = data{1,2};

[ NH4_pelagicnonStorm,  NH4_pelagicStorm, sumNH4_pelagicperiod ]    =  ...
    sum_10min_six_period( NH4_pelagic,  period_10min );
h(2) = plot(NH4_pelagic.Date  , NH4_pelagic.Data, 'k--'     );   %g/d
hold on 

AddShade([0  0] , [20  20] , period );
leg1 = legend(h(1:2), 'NO_{3}' , 'NH_{4}');
set(leg1,'Orientation','horizontal','Location','northeast');


set(gca,'XTick',[ datenum(timeTick )],'XTickLabel','','TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
% set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);
ylabel({'Pelagic uptake', '(g/d)'});
%  text( sTime + 8,800,'(a)');
 text(0.08,1.1,'(e)','units','normalized');
%  title([ currentFolder])
 grid on 
%

subplot( num_fig, 1, 6)
file = [ fileOutput '3 NO3\Benthic  nitrogen uptake_wholeWetland.csv'];
fid = fopen(file,'rt');
data = textscan(fid,'%s %f %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
NH4_NO3_benthic.Date = dateTime;
NH4_NO3_benthic.Data = data{1,2};

[ NH4_NO3_benthicnonStorm,  NH4_NO3_benthicStorm, sumNH4_NO3_benthicperiod ]    =  ...
    sum_10min_six_period( NH4_NO3_benthic,  period_10min );

h(2) = plot(NH4_NO3_benthic.Date  , NH4_NO3_benthic.Data, 'k'   );   %g/d
hold on 

AddShade([-5000   -5000] , [10000  10000] , period );

set(gca,'XTick',[ datenum(timeTick )],'XTickLabel', timeLable ,'TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
% set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);
ylabel({'Benthic net uptake','NO_{3} or NH_{4}(g/d)'});
%  text( sTime + 8,800,'(a)');
 text(0.08,1.1,'(f)','units','normalized');
%  title([ currentFolder])
 grid on 

 
 set(rate_pro, 'PaperPositionMode', 'manual');
set(rate_pro, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 29;
xLeft = 0;   yTop = 0;
set(rate_pro,'paperposition',[xLeft yTop xSize ySize])
saveas(rate_pro, [fileOutput 'Process_mass_internal_process'],'png');




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
rate_merge = figure
subplot(3, 1, 1)
yyaxis left
h(1) =  plot(DON_miner.Date  , DON_miner.Data   );
hold on 
h(2) = plot(NH4_nitri.Date  , NH4_nitri.Data   );
hold on
ylabel({'(g/d)'});
yyaxis right
h(3) = plot(NO3_denitri.Date , NO3_denitri.Data, 'r'   );
hold on
ylabel({'Denitrification', '(g/d)'},'Color',[1 0 0]);
AddShade([0  0] , [3000  3000] , period );
leg1 = legend(h(1:2), 'Mineralisation', 'Nitrification');
   set(leg1,  'Position',[0.156903765690377 0.816298342541436 0.197175732217573 0.0971454880294658]);
xlim([sTime  eTime]);
grid on
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel', '' ,'TickLength',[0.005 0.015]);
set(gca,'YColor',[1 0 0]);
set(gca,'GridAlpha',0.5);
 text(0.08,1.1,'(a)','units','normalized');

subplot(3, 1, 2)
% yyaxis left
% h(1) =  plot(DON_miner.Date  , DON_miner.Data   );
% hold on 


% ylabel({'Mineralisation ',' DON', '(g/d)'});
% pp = plot(PON_decom.Date  , PON_decom.Data   )
% hold on 
% yyaxis right
h(2) =  plot(NO3_pelagic.Date  , NO3_pelagic.Data, '-'   );   %g/d
hold on
h(3) = plot(NH4_pelagic.Date  , NH4_pelagic.Data, '--'     );   %g/d
hold on
ylim([0  10  ]);
ylabel({'Pelagic uptake', '(g/d)'});
AddShade([0  0] , [20  20] , period );
legend(h(2:3), 'NO_{3}', 'NH_{4}');
xlim([sTime  eTime]);
grid on
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel', '' ,'TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
 text(0.08,1.1,'(b)','units','normalized');
 
 
subplot(3, 1, 3)
h(2) = plot(NH4_NO3_benthic.Date  , NH4_NO3_benthic.Data, 'k'   );   %g/d
AddShade([-2000   -2000] , [4000  4000] , period );
xlim([sTime  eTime]);

ylabel({'Benthic net uptake','NO_{3} or NH_{4}(g/d)'});
grid on
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel', timeLable ,'TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
 text(0.08,1.1,'(c)','units','normalized');
 
 
 set(rate_merge, 'PaperPositionMode', 'manual');
set(rate_merge, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 15;
xLeft = 0;   yTop = 0;
set(rate_merge,'paperposition',[xLeft yTop xSize ySize])
% saveas(rate_merge, [fileOutput 'Process_mass_internal_process_merge'],'png');

print(rate_merge,[fileOutput  'fig Process_mass_internal_process_merge.png'],'-dpng','-r300');

% unit is g 
InteranlProcess (1, 2)  = DON_minernonStorm   ; %mineralisation in   during non storm period 
InteranlProcess(2, 2)  = NH4_nitrinonStorm ; % nitrification  in   during non storm period 
InteranlProcess(3, 2)  =  NO3_denitrinonStorm ;  % denitrification in   during non storm period 
InteranlProcess(4, 2)  =NO3_pelagicnonStorm  ;  %pelagic uptake of NO3  in   during non storm period 
InteranlProcess(5, 2)  =  NH4_pelagicnonStorm ; %pelagic uptake of NH4 during non storm period
InteranlProcess(6, 2)  =  NH4_NO3_benthicnonStorm ; %benthic uptake of NH4 or NO3 during non storm period


InteranlProcess (1, 3)  =  DON_minerStorm  ; %mineralisation in   during  storm period 
InteranlProcess(2, 3)  = NH4_nitriStorm  ; % nitrification  in   during  storm period 
InteranlProcess(3, 3)  =  NO3_denitriStorm;  % denitrification in   during  storm period 
InteranlProcess(4, 3)  =  NO3_pelagicStorm;  %pelagic uptake of NO3  in   during  storm period 
InteranlProcess(5, 3)  =  NH4_pelagicStorm ; %pelagic uptake of NH4 during  storm period
InteranlProcess(6, 3)  =  NH4_NO3_benthicStorm ; %benthic uptake of NH4 or NO3 during  storm period
%

InteranlProcess(1, 1)  =   InteranlProcess(1, 2) +  InteranlProcess(1, 3);    %mineralisation   during  whole period 
InteranlProcess(2, 1)  =   InteranlProcess(2, 2) +  InteranlProcess(2, 3)     ;  % nitrificaion   during  whole  period 
InteranlProcess(3, 1)  =   InteranlProcess(3, 2) +  InteranlProcess(3, 3)     ;  %denitrifiicaiont   during  whole  period 
InteranlProcess(4, 1)  =  InteranlProcess(4, 2) +  InteranlProcess(4, 3)     ;   %pelagic uptake of NO3 in   during  whole  period 
InteranlProcess(5, 1)  =  InteranlProcess(5, 2) +  InteranlProcess(5, 3) ;    %pelagic uptake of NH4 out during  whoel  period
InteranlProcess(6, 1)  =  InteranlProcess(6, 2) +  InteranlProcess(6, 3) ;    %benthic uptake of NH4 or NO3  during  whoel  period

xlswrite([fileOutput 'flux_mass_tranport_sediment_process.xlsx'],InteranlProcess, 'internalProcess',   'B2:D7');