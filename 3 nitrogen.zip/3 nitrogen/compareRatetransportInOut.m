

clc
close all
% addpath('E:\Simulation_UWA_WD\2 For model variables\Function');
% addpath('E:\Simulation_UWA_WD\2 For model variables\Supporting information');
% BasicRead] 
currentOutput = '3 nitrogen\'; 
fileOutput =  [dicmodel currentFolder '\Output\' currentOutput ];
if ~exist(fileOutput,'dir')      % check  whether the outdir  exists in the file of 'dir';
    mkdir(fileOutput);           % if not exists, create the file of 'outdir'
end

fileNH4 = [ fileOutput '2 NH4\NH4 transport_in_perArea.csv'];
fid = fopen(fileNH4,'rt');
data = textscan(fid,'%s %f','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
NH4transport_in_perArea.Date = dateTime;
NH4transport_in_perArea.Data = data{1,2};  % g N /m2/d

NH4transport_in_perAreaDaily = dailySum(NH4transport_in_perArea);
fileNitri_NH4DailyOut = [ fileOutput '2 NH4\NH4 transport_in_perArea_rate_wholeWetland.csv'];
writeDaily(NH4transport_in_perAreaDaily,  fileNitri_NH4DailyOut  ,  'transport_NH4Daily(g N/m2 /d)'  );
[NH4transport_in_perAreaDailynonStorm,  NH4transport_in_perAreaDailyStorm ]   = ...
   divide2period( NH4transport_in_perAreaDaily);

[h_transport_in_perArea_NH4Daily,p_transport_in_perArea_NH4Daily, ci, stats] = ...
    ttest2(NH4transport_in_perAreaDailynonStorm.Data,   NH4transport_in_perAreaDailyStorm.Data);
%------------

fileNO3 = [ fileOutput '3 NO3\NO3 transport_in_perArea.csv'];
fid = fopen(fileNO3,'rt');
data = textscan(fid,'%s %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
NO3transport_in_perArea.Date = dateTime;
NO3transport_in_perArea.Data = data{1,2};  % g N /m2/d

NO3transport_in_perAreaDaily = dailySum(NO3transport_in_perArea);
fileNitri_NO3DailyOut = [ fileOutput '3 NO3\NO3 transport_in_perArea_rate_wholeWetland.csv'];
writeDaily(NO3transport_in_perAreaDaily,  fileNitri_NO3DailyOut  ,  'transport_NO3Daily(g N/m2 /d)'  );
[NO3transport_in_perAreaDailynonStorm,  NO3transport_in_perAreaDailyStorm ]   = ...
   divide2period( NO3transport_in_perAreaDaily);
[h_transport_in_perArea_NO3Daily,p_transport_in_perArea_NO3Daily, ci, stats] = ...
    ttest2(NO3transport_in_perAreaDailynonStorm.Data,   NO3transport_in_perAreaDailyStorm.Data);
%----- DON


fileDON = [ fileOutput '4 DON\DON transport_in_perArea.csv'];
fid = fopen(fileDON,'rt');
data = textscan(fid,'%s %f','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
DONtransport_in_perArea.Date = dateTime;
DONtransport_in_perArea.Data = data{1,2};  % g N /m2/d

DONtransport_in_perAreaDaily = dailySum(DONtransport_in_perArea);
fileNitri_DONDailyOut = [ fileOutput '4 DON\DON transport_in_perArea_rate_wholeWetland.csv'];
writeDaily(DONtransport_in_perAreaDaily,  fileNitri_DONDailyOut  ,  'transport_DONDaily(g N/m2 /d)'  );
[DONtransport_in_perAreaDailynonStorm,  DONtransport_in_perAreaDailyStorm ]   = ...
   divide2period( DONtransport_in_perAreaDaily);

[h_transport_in_perArea_DONDaily,p_transport_in_perArea_DONDaily, ci, stats] = ...
    ttest2(DONtransport_in_perAreaDailynonStorm.Data,   DONtransport_in_perAreaDailyStorm.Data);

%PON

filePON = [ fileOutput '5 PON\PON transport_in_perArea.csv'];
fid = fopen(filePON,'rt');
data = textscan(fid,'%s %f','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
PONtransport_in_perArea.Date = dateTime;
PONtransport_in_perArea.Data = data{1,2};  % g N /m2/d

PONtransport_in_perAreaDaily = dailySum(PONtransport_in_perArea);
fileNitri_PONDailyOut = [ fileOutput '5 PON\PON transport_in_perArea_rate_wholeWetland.csv'];
writeDaily(PONtransport_in_perAreaDaily,  fileNitri_PONDailyOut  ,  'transport_PONDaily(g N/m2 /d)'  );
[PONtransport_in_perAreaDailynonStorm,  PONtransport_in_perAreaDailyStorm ]   = ...
   divide2period( PONtransport_in_perAreaDaily);

[h_transport_in_perArea_PONDaily,p_transport_in_perArea_PONDaily, ci, stats] = ...
    ttest2(PONtransport_in_perAreaDailynonStorm.Data,   PONtransport_in_perAreaDailyStorm.Data);

% calculate the median  during non storm period % g N /m2/d
% NO3
TransportIn_nonStorm(1 , 1 ) =  median(NO3transport_in_perAreaDailynonStorm.Data  );
% NH4
TransportIn_nonStorm(2 , 1 ) =  median(NH4transport_in_perAreaDailynonStorm.Data  );
% DON
TransportIn_nonStorm(3 , 1 ) =  median(DONtransport_in_perAreaDailynonStorm.Data );
% PON
TransportIn_nonStorm(4 , 1 ) =  median(PONtransport_in_perAreaDailynonStorm.Data );

TransportIn_nonStorm = TransportIn_nonStorm * 1000;  % mg N /m2/d
% calculate the median  during storm period  g N /m2/d
% NO3
TransportIn_Storm(1 , 1 ) =  median(NO3transport_in_perAreaDailyStorm.Data  );
% NH4
TransportIn_Storm(2 , 1 ) =  median(NH4transport_in_perAreaDailyStorm.Data  );
% DON
TransportIn_Storm(3 , 1 ) =  median(DONtransport_in_perAreaDailyStorm.Data );
% PON
TransportIn_Storm(4 , 1 ) =  median(PONtransport_in_perAreaDailyStorm.Data );

TransportIn_Storm = TransportIn_Storm * 1000;  % mg N /m2/d

% calculate the median  during whole period  g N /m2/d
% NO3
TransportIn_whole(1 , 1 ) =  median(NO3transport_in_perAreaDaily.Data  );
% NH4
TransportIn_whole(2 , 1 ) =  median(NH4transport_in_perAreaDaily.Data  );
% DON
TransportIn_whole(3 , 1 ) =  median(DONtransport_in_perAreaDaily.Data );
% PON
TransportIn_whole(4 , 1 ) =  median(PONtransport_in_perAreaDaily.Data );

TransportIn_whole = TransportIn_whole * 1000;  % mg N /m2/d

%%%
fileNH4 = [ fileOutput '2 NH4\NH4 transport_out_perArea.csv']; 
fid = fopen(fileNH4,'rt');
data = textscan(fid,'%s %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
NH4transport_out_perArea.Date = dateTime;
NH4transport_out_perArea.Data = data{1,2};  % g N /m2/d

NH4transport_out_perAreaDaily = dailySum(NH4transport_out_perArea);
fileNitri_NH4DailyOut = [ fileOutput '2 NH4\NH4 transport_out_perArea_rate_wholeWetland.csv'];
writeDaily(NH4transport_out_perAreaDaily,  fileNitri_NH4DailyOut  ,  'transport_NH4Daily(g N/m2 /d)'  );
[NH4transport_out_perAreaDailynonStorm,  NH4transport_out_perAreaDailyStorm ]   = ...
   divide2period( NH4transport_out_perAreaDaily);

[h_transport_out_perArea_NH4Daily,p_transport_out_perArea_NH4Daily, ci, stats] = ...
    ttest2(NH4transport_out_perAreaDailynonStorm.Data,   NH4transport_out_perAreaDailyStorm.Data);
%------------

fileNO3 = [ fileOutput '3 NO3\NO3 transport_out_perArea.csv'];
fid = fopen(fileNO3,'rt');
data = textscan(fid,'%s %f %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
NO3transport_out_perArea.Date = dateTime;
NO3transport_out_perArea.Data = data{1,2};  % g N /m2/d

NO3transport_out_perAreaDaily = dailySum(NO3transport_out_perArea);
fileNitri_NO3DailyOut = [ fileOutput '3 NO3\NO3 transport_out_perArea_rate_wholeWetland.csv'];
writeDaily(NO3transport_out_perAreaDaily,  fileNitri_NO3DailyOut  ,  'transport_NO3Daily(g N/m2 /d)'  );
[NO3transport_out_perAreaDailynonStorm,  NO3transport_out_perAreaDailyStorm ]   = ...
   divide2period( NO3transport_out_perAreaDaily);
[h_transport_out_perArea_NO3Daily,p_transport_out_perArea_NO3Daily, ci, stats] = ...
    ttest2(NO3transport_out_perAreaDailynonStorm.Data,   NO3transport_out_perAreaDailyStorm.Data);
%----- DON


fileDON = [ fileOutput '4 DON\DON transport_out_perArea.csv'];
fid = fopen(fileDON,'rt');
data = textscan(fid,'%s %f %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
DONtransport_out_perArea.Date = dateTime;
DONtransport_out_perArea.Data = data{1,2};  % g N /m2/d

DONtransport_out_perAreaDaily = dailySum(DONtransport_out_perArea);
fileNitri_DONDailyOut = [ fileOutput '4 DON\DON transport_out_perArea_rate_wholeWetland.csv'];
writeDaily(DONtransport_out_perAreaDaily,  fileNitri_DONDailyOut  ,  'transport_DONDaily(g N/m2 /d)'  );
[DONtransport_out_perAreaDailynonStorm,  DONtransport_out_perAreaDailyStorm ]   = ...
   divide2period( DONtransport_out_perAreaDaily);

[h_transport_out_perArea_DONDaily,p_transport_out_perArea_DONDaily, ci, stats] = ...
    ttest2(DONtransport_out_perAreaDailynonStorm.Data,   DONtransport_out_perAreaDailyStorm.Data);

%PON

filePON = [ fileOutput '5 PON\PON transport_out_perArea.csv'];
fid = fopen(filePON,'rt');
data = textscan(fid,'%s %f %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
PONtransport_out_perArea.Date = dateTime;
PONtransport_out_perArea.Data = data{1,2};  % g N /m2/d

PONtransport_out_perAreaDaily = dailySum(PONtransport_out_perArea);
fileNitri_PONDailyOut = [ fileOutput '5 PON\PON transport_out_perArea_rate_wholeWetland.csv'];
writeDaily(PONtransport_out_perAreaDaily,  fileNitri_PONDailyOut  ,  'transport_PONDaily(g N/m2 /d)'  );
[PONtransport_out_perAreaDailynonStorm,  PONtransport_out_perAreaDailyStorm ]   = ...
   divide2period( PONtransport_out_perAreaDaily);

[h_transport_out_perArea_PONDaily,p_transport_out_perArea_PONDaily, ci, stats] = ...
    ttest2(PONtransport_out_perAreaDailynonStorm.Data,   PONtransport_out_perAreaDailyStorm.Data);

% calculate the median  duroutg non storm period % g N /m2/d
% NO3
Transportout_nonStorm(1 , 1 ) =  median(NO3transport_out_perAreaDailynonStorm.Data  );
% NH4
Transportout_nonStorm(2 , 1 ) =  median(NH4transport_out_perAreaDailynonStorm.Data  );
% DON
Transportout_nonStorm(3 , 1 ) =  median(DONtransport_out_perAreaDailynonStorm.Data );
% PON
Transportout_nonStorm(4 , 1 ) =  median(PONtransport_out_perAreaDailynonStorm.Data );

Transportout_nonStorm = Transportout_nonStorm * 1000;  % mg N /m2/d
% calculate the median  duroutg storm period  g N /m2/d
% NO3
Transportout_Storm(1 , 1 ) =  median(NO3transport_out_perAreaDailyStorm.Data  );
% NH4
Transportout_Storm(2 , 1 ) =  median(NH4transport_out_perAreaDailyStorm.Data  );
% DON
Transportout_Storm(3 , 1 ) =  median(DONtransport_out_perAreaDailyStorm.Data );
% PON
Transportout_Storm(4 , 1 ) =  median(PONtransport_out_perAreaDailyStorm.Data );

Transportout_Storm = Transportout_Storm * 1000;  % mg N /m2/d


% calculate the median  during whole period  g N /m2/d
% NO3
Transportout_whole(1 , 1 ) =  median(NO3transport_out_perAreaDaily.Data  );
% NH4
Transportout_whole(2 , 1 ) =  median(NH4transport_out_perAreaDaily.Data  );
% DON
Transportout_whole(3 , 1 ) =  median(DONtransport_out_perAreaDaily.Data );
% PON
Transportout_whole(4 , 1 ) =  median(PONtransport_out_perAreaDaily.Data );

Transportout_whole = Transportout_whole * 1000;  % mg N /m2/d



%---------------Write  TransportInOut_Storm  at inlet  into file ---------------------------------------------------------
 filename = [ fileOutput 'Transport_in_out_nitrogen_non_storm.csv'];
fid = fopen(filename,'wt');
fprintf(fid,'species (mg N /m2/d), NO3, NH4, DON, PON\n');
fprintf(fid,'TransportIn_nonStorm,');
for ii = 1 : length(TransportIn_nonStorm)
     if  ii == length(TransportIn_nonStorm)
         
          fprintf(fid,'%4.4f\n ',    TransportIn_nonStorm(ii));
     else
 fprintf(fid,'%4.4f, ',    TransportIn_nonStorm(ii));
     end

 
end
fprintf(fid,'TransportIn_Storm,');
for ii = 1 : length(TransportIn_Storm)
     if  ii == length(TransportIn_Storm)
         
          fprintf(fid,'%4.4f\n ',    TransportIn_Storm(ii));
     else
 fprintf(fid,'%4.4f, ',    TransportIn_Storm(ii));
     end

 
end

fprintf(fid,'TransportIn_whole,');
for ii = 1 : length(TransportIn_whole)
     if  ii == length(TransportIn_whole)
         
          fprintf(fid,'%4.4f\n ',    TransportIn_whole(ii));
     else
 fprintf(fid,'%4.4f, ',    TransportIn_whole(ii));
     end

 
end

fprintf(fid,'Transportout_nonStorm,');
for ii = 1 : length(Transportout_nonStorm)
     if  ii == length(Transportout_nonStorm)
         
          fprintf(fid,'%4.4f\n ',    Transportout_nonStorm(ii));
     else
 fprintf(fid,'%4.4f, ',    Transportout_nonStorm(ii));
     end

 
end
fprintf(fid,'Transportout_Storm,');
for ii = 1 : length(Transportout_Storm)
     if  ii == length(Transportout_Storm)
         
          fprintf(fid,'%4.4f\n ',    Transportout_Storm(ii));
     else
 fprintf(fid,'%4.4f, ',    Transportout_Storm(ii));
     end

 
end




fprintf(fid,'Transportout_whole,');
for ii = 1 : length(Transportout_whole)
     if  ii == length(Transportout_whole)
         
          fprintf(fid,'%4.4f\n ',    Transportout_whole(ii));
     else
 fprintf(fid,'%4.4f, ',    Transportout_whole(ii));
     end

 
end

fclose(fid);