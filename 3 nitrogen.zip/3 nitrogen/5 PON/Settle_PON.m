% load('D:\Research in UWA\overview of data available in anvil\all_togehter_plotting\anvil.mat');
% addpath('E:\Simulation_UWA_WD\2 For model variables\Function');
% addpath('E:\Simulation_UWA_WD\2 For model variables\Supporting information');
% BasicRead
currentOutput = '3 nitrogen\5 PON\'; 
fileOutput =  [dicmodel currentFolder '\Output\' currentOutput ];
if ~exist(fileOutput,'dir')      % check  whether the outdir  exists in the file of 'dir';
    mkdir(fileOutput);           % if not exists, create the file of 'outdir'
end

varid = netcdf.inqVarID(ncid,'WQ_DIAG_OGM_SED_PON');
OGM_SED_PON = netcdf.getVar(ncid,varid) /1000*14  *24*3600;  %mmol/m2/d to g/m2/d; 

fileBasicmat = [dicmodel currentFolder '\Output\Basic.mat'];
load(fileBasicmat);

[OGM_SED_PONSumSpace, OGM_SED_PONCVMean ]  = ThreeVolume2twoarea(OGM_SED_PON, Basic, Cell_whole_channel);
 %the unit of first variable  is g N /d,
% the unit of second variable is g N/m2/d.

figure
subplot(2,1,1)
plot(ResTime, OGM_SED_PONSumSpace)

set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([  currentFolder   '    ' 'PON sedimentation across the wetland ']);
xlim([sTime  eTime]);
ylabel({ ' (g N /d)'}) 
xlabel('Date (2015)');
grid on 

subplot(2,1,2)
plot(ResTime, OGM_SED_PONCVMean)

 set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([  currentFolder   '    ' 'Rate of PON sedimentationacross the wetland ']);
xlim([sTime  eTime]);
ylabel({ ' (g N /m2  /d)'}) 
xlabel('Date (2015)');
grid on 

set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 15;
xLeft = 0;  yTop = 0;

set(gcf,'paperposition',[xLeft yTop xSize ySize])

saveas(gcf,[fileOutput  'PON sedimentation across wetland'],'png');
saveas(gcf,[fileOutput  'PON sedimentation across wetland'],'fig');


 filecsv=  [ fileOutput  'PON sedimentation _wholeWetland.csv' ];
 fid = fopen(filecsv,'wt');
fprintf(fid,'ISOTime, OGM_SED_PONSumSpace (g N/d),OGM_SED_PONCVMean (g N/m2/d) \n');
for i = 1:length(ResTime)
    fprintf(fid,'%s,',datestr(ResTime(i),'dd/mm/yyyy HH:MM:SS'));
    fprintf(fid,'%4.8f,%4.8f \n', OGM_SED_PONSumSpace(1,i) ,OGM_SED_PONCVMean(1,i));
                       
end
fclose(fid);





 