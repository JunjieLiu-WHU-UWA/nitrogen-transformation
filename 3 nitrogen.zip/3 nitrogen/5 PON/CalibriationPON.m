



% load('D:\Research in UWA\overview of data available in anvil\all_togehter_plotting\anvil.mat');
% addpath('E:\Simulation_UWA_WD\2 For model variables\Function');
% addpath('E:\Simulation_UWA_WD\2 For model variables\Supporting information');
% BasicRead
currentOutput = '3 nitrogen\5 PON\'; 
fileOutput =  [dicmodel currentFolder '\Output\' currentOutput ];
if ~exist(fileOutput,'dir')      % check  whether the outdir  exists in the file of 'dir';
    mkdir(fileOutput);           % if not exists, create the file of 'outdir'
end
varid = netcdf.inqVarID(ncid,'WQ_OGM_PON');
OGM_PON = netcdf.getVar(ncid,varid) /1000*14  ;  %mmol/m3/d to g/m3/d; 

weirOGM_PON = OGM_PON (idx2weirCell,: );
% inletOGM_PON = OGM_PON (idx2InletCell,: );


file_inflow =  [ dicmodel currentFolder   '\BCs\'   BC_inflow ];
fid = fopen(file_inflow ,'rt');
str = repmat('%f ', [1 24] );
data_inlet = textscan(fid,['%s' str],'Headerlines',1,'Delimiter',',');
ISOTime_in = datenum(data_inlet{1,1},'dd/mm/yyyy HH:MM:SS');
inletOGM_PON.Date = ISOTime_in;
inletOGM_PON.Data = data_inlet{1,16} *N_mmol_g ; %  the unit is  mmol /m3  to mg/L


figure

plot(ResTime,weirOGM_PON(1,:)  )
hold on

PN_UWA_04 =  anvil.SWQ.MSANVCBOUT.HRD.Storm_04.PN;
ss = find(sTime <= PN_UWA_04.Date & PN_UWA_04.Date <= eTime);
plot(PN_UWA_04.Date(ss,1),PN_UWA_04.Data(ss,1),'b*'); clear ss
hold on 

PN_UWA_05 =  anvil.SWQ.MSANVCBOUT.HRD.Storm_05.PN;
ss = find(sTime <= PN_UWA_05.Date & PN_UWA_05.Date <= eTime);
plot(PN_UWA_05.Date(ss,1),PN_UWA_05.Data(ss,1),'r*'); clear ss
hold on 
leg1 = legend( 'modelled PON', 'Storm 04' , 'Storm 05');
set(leg1,'Location','best');
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([  currentFolder ' PON at outlet  ']);
xlim([sTime  eTime]);
ylabel('mg/L'); 
xlabel('Date (2015)');
grid on 

saveas(gcf,[fileOutput  'PON at outlet'],'png');
saveas(gcf,[fileOutput  'PON at outlet'],'fig');


filecsv =  [ fileOutput 'PON_weir.csv' ];
fid = fopen(filecsv,'wt');
fprintf(fid,'ISOTime, PON concentration (mg/L) \n');
for i = 1:length(ResTime)
    fprintf(fid,'%s,',datestr(ResTime(i),'dd/mm/yyyy HH:MM:SS'));
    fprintf(fid,'%4.4f \n', weirOGM_PON(1,i) );
end
fclose(fid);

%-------comparison PON at inlet and outlet---------------------------------------
figure
h(1) = plot(inletOGM_PON.Date,  inletOGM_PON.Data  )
hold on

PN_UWA_04 =  anvil.SWQ.MSANVCBIN.HRD.Storm_04.PN;
ss = find(sTime <= PN_UWA_04.Date & PN_UWA_04.Date <= eTime);
h(2) = plot(PN_UWA_04.Date(ss,1),PN_UWA_04.Data(ss,1),'b*'); clear ss
hold on 

PN_UWA_05 =  anvil.SWQ.MSANVCBIN.HRD.Storm_05.PN;
ss = find(sTime <= PN_UWA_05.Date & PN_UWA_05.Date <= eTime);
h(3) = plot(PN_UWA_05.Date(ss,1),PN_UWA_05.Data(ss,1),'b*'); clear ss


h(4) = plot(ResTime,weirOGM_PON(1,:)  )
hold on


PN_UWA_04 =  anvil.SWQ.MSANVCBOUT.HRD.Storm_04.PN;
ss = find(sTime <= PN_UWA_04.Date & PN_UWA_04.Date <= eTime);
h(5)  = plot(PN_UWA_04.Date(ss,1),PN_UWA_04.Data(ss,1),'rs'); clear ss
hold on 

PN_UWA_05 =  anvil.SWQ.MSANVCBOUT.HRD.Storm_05.PN;
ss = find(sTime <= PN_UWA_05.Date & PN_UWA_05.Date <= eTime);
h(6) = plot(PN_UWA_05.Date(ss,1),PN_UWA_05.Data(ss,1),'rs'); clear ss


leg1 = legend(h([1 2 4 5]),  'Inlet ', '', 'Outlet', '');
set(leg1,'Location','best');

set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([  currentFolder ' PON at inlet and  outlet  ']);
xlim([sTime  eTime]);
ylabel('mg/L'); 
xlabel('Date (2015)');
grid on  

set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 10;
xLeft = 0; yTop = 0;
set(gcf,'paperposition',[xLeft yTop xSize ySize])
saveas(gcf,[fileOutput  'PON at inlet and outlet'],'png');
