


% load('D:\Research in UWA\overview of data available in anvil\all_togehter_plotting\anvil.mat');
% addpath('E:\Simulation_UWA_WD\2 For model variables\Function');
% addpath('E:\Simulation_UWA_WD\2 For model variables\Supporting information');
% BasicRead
currentOutput = '3 nitrogen\5 PON\'; 
fileOutput =  [dicmodel currentFolder '\Output\' currentOutput ];
if ~exist(fileOutput,'dir')      % check  whether the outdir  exists in the file of 'dir';
    mkdir(fileOutput);           % if not exists, create the file of 'outdir'
end

varid = netcdf.inqVarID(ncid,'WQ_DIAG_OGM_PON_MINER');
OGM_PON_MINER = netcdf.getVar(ncid,varid) /1000*14  ;  %mmol/m3/d to g/m3/d; 

fileBasicmat = [dicmodel currentFolder '\Output\Basic.mat'];
load(fileBasicmat);

[OGM_PON_MINERSumSpace, OGM_PON_MINERCVMean ]  = ThreeVolume2twoarea(OGM_PON_MINER, Basic, Cell_whole_channel);
 %the unit of first variable  is g N /d,
% the unit of second variable is g N/m2/d.

figure
subplot(2,1,1)
plot(ResTime, OGM_PON_MINERSumSpace)

set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([  currentFolder   '    ' 'PON decomposition across the wetland ']);
xlim([sTime  eTime]);
ylabel({ ' (g N /d)'}) 
xlabel('Date (2015)');
grid on 

subplot(2,1,2)
plot(ResTime, OGM_PON_MINERCVMean)

 set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([  currentFolder   '    ' 'Rate of PON decomposition sedimentationacross the wetland ']);
xlim([sTime  eTime]);
ylabel({ ' (g N /m2  /d)'}) 
xlabel('Date (2015)');
grid on 

set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 15;
xLeft = 0;  yTop = 0;

set(gcf,'paperposition',[xLeft yTop xSize ySize])

saveas(gcf,[fileOutput  'PON decomposition across wetland'],'png');
saveas(gcf,[fileOutput  'PON decomposition across wetland'],'fig');


 filecsv=  [ fileOutput  'PON decomposition _wholeWetland.csv' ];
 fid = fopen(filecsv,'wt');
fprintf(fid,'ISOTime, OGM_PON_MINERSumSpace (g N/d),OGM_PON_MINERCVMean (g N/m2/d) \n');
for i = 1:length(ResTime)
    fprintf(fid,'%s,',datestr(ResTime(i),'dd/mm/yyyy HH:MM:SS'));
    fprintf(fid,'%4.8f,%4.8f \n', OGM_PON_MINERSumSpace(1,i) ,OGM_PON_MINERCVMean(1,i));
                       
end
fclose(fid);

 