%this script is to analyze the budget of oxygen
clc
close all
% clearvars -except anvil 

% addpath('E:\Simulation_UWA_WD\2 For model variables\Function');
% addpath('E:\Simulation_UWA_WD\2 For model variables\Supporting information');
% BasicRead
file =  [dicmodel currentFolder '\Output\3 nitrogen\' ];
% 
% budget_PON = zeros( 4 ,1   );
labels = {'Influent','Outfluent','sedimentation', 'decomposition'}';
figure
% Transport in
fileTran = [file '5 PON\PON transport_in.csv' ];
fid = fopen(fileTran,'rt');
data = textscan(fid,'%s %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
transIN_PON.Date = dateTime;
transIN_PON.Data = data{1,2}; % the unit is g/d
source_PON(1,1) = trapz(transIN_PON.Date, transIN_PON.Data  );

[ transIN_PONnonStorm,  transIN_PONStorm, sumtransIN_PONperiod ]    = sum_10min_six_period( transIN_PON,  period_10min );



subplot(4,1,1)
pp = plot(transIN_PON.Date, transIN_PON.Data);
AddShade([0  0] , [30000  30000] , period );
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel','','TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);
% ylim([0 1000 ]);
ylabel({'PON',' Input', '(g/d)'});
%  text( sTime + 8,800,'(a)');
 text(0.08,1.1,'(a)','units','normalized');
 title(['Scenario   '  currentFolder])
 grid on 


% transport out
fileTran = [ file '5 PON\PON transport_out.csv'];
fid = fopen(fileTran,'rt');
data = textscan(fid,'%s %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
transOut_PON.Date = dateTime;
transOut_PON.Data = data{1,2}; % the unit is g/d
sink_PON(1,1) = trapz(transOut_PON.Date, transOut_PON.Data  );

[ transOut_PONnonStorm, transOut_PONStorm, sumtransOut_PONperiod ]    = sum_10min_six_period( transOut_PON,   period_10min );


subplot(4,1,2)
pp = plot(transOut_PON.Date, transOut_PON.Data   );
AddShade([0  0] , [6000  6000] , period );
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel','','TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);
% ylim([0 1000 ]);
ylabel({'PON',' Output', '(g/d)'});
%  text( sTime + 8,800,'(a)');
 text(0.08,1.1,'(b)','units','normalized');
%  title(['Scenario   '  currentFolder])
 grid on 



% sedimentation of PON
 fileAtm = [ file '5 PON\PON sedimentation _wholeWetland.csv'];
 fid = fopen(fileAtm,'rt');
data = textscan(fid,'%s %f %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
SedPON.Date = dateTime ;
SedPON.Data = data{1,2} * (-1) ;% the unit is g/d
sink_PON(2,1) = trapz(SedPON.Date, SedPON.Data  );

[ SedPONnonStorm, SedPONStorm, sumSedPONperiod ]    = sum_10min_six_period( SedPON,   period_10min );


subplot(4,1,3)
pp = plot( SedPON.Date , SedPON.Data);
AddShade([0  0] , [150  150] , period );
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel','','TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);
% ylim([0 1000 ]);
ylabel({'Sedimentation','PON', '(g/d)'});
%  text( sTime + 8,800,'(a)');
 text(0.08,1.1,'(c)','units','normalized');
%  title(['Scenario   '  currentFolder])
 grid on 

 

% decomposition of PON
 fileAtm = [ file '5 PON\PON decomposition _wholeWetland.csv'];
 fid = fopen(fileAtm,'rt');
data = textscan(fid,'%s %f %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
DecomPON.Date = dateTime ;
DecomPON.Data = data{1,2};% the unit is g/d
sink_PON(3,1) = trapz(DecomPON.Date, DecomPON.Data  );
 [ DecomPONnonStorm, DecomPONStorm, sumDecomPONperiod ]    = sum_10min_six_period(DecomPON,   period_10min );


 
subplot(4,1,4)
pp = plot( DecomPON.Date, DecomPON.Data);
AddShade([0  0] , [1  1] , period );
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel',timeLable,'TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);
% ylim([0 1000 ]);
ylabel({'PON',' decomposition', '(g/d)'});
%  text( sTime + 8,800,'(a)');
 text(0.08,1.1,'(d)','units','normalized');
%  title(['Scenario   '  currentFolder])
 grid on 

 
 set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 29;
xLeft = 0;   yTop = 0;
set(gcf,'paperposition',[xLeft yTop xSize ySize])
saveas(gcf, [file '\5 PON\PON budget mass'],'png');




% 
% figure
% p = pie(sink_PON);
% pText = findobj(p,'Type','text');
% 
% leg1 = legend('Influent','Outfluent','Sedimentation', 'MIneralisastion', 'decomposition' );
%  set(leg1,...
%     'Location','eastoutside');
% 
% set(gcf, 'PaperPositionMode', 'manual');
% set(gcf, 'PaperUnits', 'centimeters');
% xSize = 10; ySize = 10;
% xLeft = 0;   yTop = 0;
% set(gcf,'paperposition',[xLeft yTop xSize ySize])
% saveas(gcf, [file '\5 PON\Pie PON budget percent'],'png');
% 
% 


%------------------------------- non storm period----  in 
PON_in_nonStorm(1,1)  =  transIN_PONnonStorm;

% out
PON_out_nonStorm(1,1)  =  transOut_PONnonStorm;
PON_out_nonStorm(2,1)  =  SedPONnonStorm;
PON_out_nonStorm(3,1)  =   DecomPONnonStorm;

% ------------------storm period
% in
PON_in_Storm(1,1)  =  transIN_PONStorm;

% out
PON_out_Storm(1,1)  =  transOut_PONStorm;
PON_out_Storm(2,1)  =    SedPONStorm;
PON_out_Storm(3,1)  =   DecomPONStorm;


% 
% percentValues = get(pText,'String'); 
% txt = {'Influent : ','Outfluent :','Atmospheric flux :', ...
%                 'SOD :', 'PGPP :', 'NEP :' }'; 
% combinedtxt = strcat(txt,percentValues);
% 
% pText(1).String = combinedtxt(1);
% pText(2).String = combinedtxt(2);
% pText(3).String = combinedtxt(3);
% pText(4).String = combinedtxt(4);
% pText(5).String = combinedtxt(5);
% pText(6).String = combinedtxt(6);