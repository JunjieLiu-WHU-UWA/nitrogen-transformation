
clc
close all
addpath('E:\Simulation_UWA_WD\2 For model variables\Function');
addpath('E:\Simulation_UWA_WD\2 For model variables\Supporting information');
BasicRead 
currentOutput = '3 nitrogen\'; 
fileOutput =  [dicmodel currentFolder '\Output\' currentOutput ];
if ~exist(fileOutput,'dir')      % check  whether the outdir  exists in the file of 'dir';
    mkdir(fileOutput);           % if not exists, create the file of 'outdir'
end

% input of NO3, NH4, DON, PON, TN
file_inflow =  [ dicmodel currentFolder   '\BCs\'   BC_inflow ];
fid = fopen(file_inflow ,'rt');
str = repmat('%f ', [1 24] );
data_inlet = textscan(fid,['%s' str],'Headerlines',1,'Delimiter',',');
ISOTime_in = datenum(data_inlet{1,1},'dd/mm/yyyy HH:MM:SS');
InflowNit.Date  = ISOTime_in;
InflowNit.Data  = data_inlet{1,10}  *N_mmol_g   ;  %  the unit is  mmol /m3  to mg/L

inletNIT_AMM.Date  = ISOTime_in;
inletNIT_AMM.Data  = data_inlet{1,9}  *N_mmol_g   ;  %  the unit is  mmol /m3  to mg/L

inletOGM_DON.Date  = ISOTime_in;
inletOGM_DON.Data  = data_inlet{1,15}  *N_mmol_g   ;  %  the unit is  mmol /m3  to mg/L

inletOGM_PON.Date = ISOTime_in;
inletOGM_PON.Data = data_inlet{1,16} *N_mmol_g ; %  the unit is  mmol /m3  to mg/L


inletTN.Date = ISOTime_in;
inletTN.Data =  InflowNit.Data +  inletNIT_AMM.Data +  inletOGM_DON.Data +  inletOGM_PON.Data ...
    + data_inlet{1,24}  * N_mmol_g ;  % data_inlet{1,24} is nitrogn in the phytoplankton


% output of NO3
fileNO3 = [ fileOutput '3 NO3\Nit_weir_10min.csv'];
fid = fopen(fileNO3,'rt');
data = textscan(fid,'%s %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
Nit_weir_10min.Date =  dateTime;
Nit_weir_10min.Data =  data{1,2};
[weirNIT_nonStorm, weirNIT_Storm] =  seperate10minperiod(Nit_weir_10min, period_10min     );

%output of NH4

fileAMM = [ fileOutput '2 NH4\NH4_weir_10min.csv'];
fid = fopen(fileAMM,'rt');
data = textscan(fid,'%s %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
AMM_weir_10min.Date =  dateTime;
AMM_weir_10min.Data =  data{1,2};
[weirAMM_nonStorm, weirAMM_Storm] =  seperate10minperiod(AMM_weir_10min, period_10min     );

% output of DON
fileDON = [ fileOutput '4 DON\DON_weir.csv'];
fid = fopen(fileDON,'rt');
data = textscan(fid,'%s %f  ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
DON_weir_10min.Date =  dateTime;
DON_weir_10min.Data =  data{1,2};
[weirDON_nonStorm, weirDON_Storm] =  seperate10minperiod(DON_weir_10min, period_10min     );


% output of PON
filePON = [ fileOutput '5 PON\PON_weir.csv'];
fid = fopen(filePON,'rt');
data = textscan(fid,'%s %f  ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
PON_weir_10min.Date =  dateTime;
PON_weir_10min.Data =  data{1,2};
[weirPON_nonStorm, weirPON_Storm] =  seperate10minperiod(PON_weir_10min, period_10min     );

% output of TN
fileTN = [ fileOutput '6 TN\TN_weir.csv'];
fid = fopen(fileTN,'rt');
data = textscan(fid,'%s %f  ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
TN_weir_10min.Date =  dateTime;
TN_weir_10min.Data =  data{1,2};
[weirTN_nonStorm, weirTN_Storm] =  seperate10minperiod(TN_weir_10min, period_10min     );

% long historical data during nonstormperiod

fileNIT = [ dicmodel '\3 nitrogen\3 NO3\shortTermGeneration\' 'NIT_outlet_historical_nonStorm.csv'];
fid = fopen(fileNIT,'rt');
data = textscan(fid,'%s %f  ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
NIT_inlet_histo_nonstorm.Date =  dateTime;
NIT_inlet_histo_nonstorm.Data =  data{1,2};



% AMM at inlet historial data
fileAMM = [ dicmodel '\3 nitrogen\2 NH4\shortGenerationNH4\' 'AMM_outlet_historical_nonStorm.csv'];
fid = fopen(fileAMM,'rt');
data = textscan(fid,'%s %f  ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
AMM_inlet_histo_nonstorm.Date =  dateTime;
AMM_inlet_histo_nonstorm.Data =  data{1,2};

%DON
fileDON = [ dicmodel '\3 nitrogen\4 DON\shortTermGeneration\' 'DON_outlet_historical_nonStorm.csv'];
fid = fopen(fileDON,'rt');
data = textscan(fid,'%s %f  ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
DON_inlet_histo_nonstorm.Date =  dateTime;
DON_inlet_histo_nonstorm.Data =  data{1,2};




% TN
fileTN = [ dicmodel '\3 nitrogen\6 TN\' 'TN_outlet_historical_nonStorm.csv'];
fid = fopen(fileTN,'rt');
data = textscan(fid,'%s %f  ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
TN_inlet_histo_nonstorm.Date =  dateTime;
TN_inlet_histo_nonstorm.Data =  data{1,2};



figure('color','w')
set(gcf, 'InvertHardCopy', 'off');
NIT_ylim = [ 0  1.5 ];
ax1 = axes('position', [0.1 0.77 0.6 0.15  ]);
h(1) = plot(InflowNit.Date,  InflowNit.Data  );
hold on

NIT_UWA_in_04 =  anvil.SWQ.MSANVCBIN.HRD.Storm_04.FNOx;
ss = find(sTime <= NIT_UWA_in_04.Date & NIT_UWA_in_04.Date <= eTime);
h(2) = plot(NIT_UWA_in_04.Date(ss,1),NIT_UWA_in_04.Data(ss,1),'b*'); clear ss
hold on 

NIT_UWA_in_05 =  anvil.SWQ.MSANVCBIN.HRD.Storm_05.FNOx;
ss = find(sTime <= NIT_UWA_in_05.Date & NIT_UWA_in_05.Date <= eTime);
h(3) = plot(NIT_UWA_in_05.Date(ss,1),NIT_UWA_in_05.Data(ss,1),'b*'); clear ss
hold on 
%%%outlet

h(4) = plot(Nit_weir_10min.Date, Nit_weir_10min.Data  );
hold on

NIT_UWA_out_04 =  anvil.SWQ.MSANVCBOUT.HRD.Storm_04.FNOx;
ss = find(sTime <= NIT_UWA_out_04.Date & NIT_UWA_out_04.Date <= eTime);
h(5) = plot(NIT_UWA_out_04.Date(ss,1),NIT_UWA_out_04.Data(ss,1),'rs'); clear ss
hold on 

NIT_UWA_out_05 =  anvil.SWQ.MSANVCBOUT.HRD.Storm_05.FNOx;
ss = find(sTime <= NIT_UWA_out_05.Date & NIT_UWA_out_05.Date <= eTime);
h(6) = plot(NIT_UWA_out_05.Date(ss,1),NIT_UWA_out_05.Data(ss,1),'rs'); clear ss
hold on 
AddShade([0  0] , [1.5 1.5] , period );
leg1 = legend(h([1 2 4 5]),  'Inlet ', '', 'Outlet', '');
set(leg1,'Location','best');


set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',''  );
% title([  currentFolder ' NO_{3} at inlet and  outlet  ']);
xlim([sTime  eTime]);
ylabel('mg/L'); 
% xlabel('Date (2015)');
grid on 
ylim(NIT_ylim );
text(0.01,0.8,'a) NO_{3}','units','normalized');

ax2 = axes('position', [0.75  0.77 0.15 0.15  ]);
yyaxis(ax2,'left');
set(ax2,'YTickLabel','', 'YColor',[0 0 0]);
yyaxis(ax2,'right');

group = [ ones( length(NIT_inlet_histo_nonstorm.Data), 1) *1 ;  ...
ones(length(weirNIT_nonStorm.Data), 1)*2 ];
boxplot(ax2, [NIT_inlet_histo_nonstorm.Data ;  weirNIT_nonStorm.Data], group,'label',{'',''});
xlim([0 3]);
% ylabel('DON (mg/L)');
% set(ax2,'XTick',[ 1.0  2.0  ], 'XTickLabel',{'Measured',   'Modelled'   }, 'XColor',[1 1 1]);
 ylabel('mg/L');                                                     
ylim(NIT_ylim );
% xtickangle(ax2  , 45);
box_change_colour(ax2);

%%%%%%%%%%%%%%%



ax3 = axes('position', [0.1  0.59  0.6 0.15  ]);
amm_ylim = [ 0  1.0 ];
h(1) = plot(inletNIT_AMM.Date,  inletNIT_AMM.Data );
hold on

AMM_UWA_in_04 =  anvil.SWQ.MSANVCBIN.HRD.Storm_04.FNH3;
ss = find(sTime <= AMM_UWA_in_04.Date & AMM_UWA_in_04.Date <= eTime);
h(2) = plot(AMM_UWA_in_04.Date(ss,1),AMM_UWA_in_04.Data(ss,1),'b*'); clear ss
hold on 

AMM_UWA_in_05 =  anvil.SWQ.MSANVCBIN.HRD.Storm_05.FNH3;
ss = find(sTime <= AMM_UWA_in_05.Date & AMM_UWA_in_05.Date <= eTime);
h(3) = plot(AMM_UWA_in_05.Date(ss,1),AMM_UWA_in_05.Data(ss,1),'b*'); clear ss
hold on 
%%%%%%%% outlet
h(4) = plot(AMM_weir_10min.Date,AMM_weir_10min.Data  );
hold on

AMM_UWA_out_04 =  anvil.SWQ.MSANVCBOUT.HRD.Storm_04.FNH3;
ss = find(sTime <= AMM_UWA_out_04.Date & AMM_UWA_out_04.Date <= eTime);
h(5) = plot(AMM_UWA_out_04.Date(ss,1),AMM_UWA_out_04.Data(ss,1),'rs'); clear ss
hold on 

AMM_UWA_out_05 =  anvil.SWQ.MSANVCBOUT.HRD.Storm_05.FNH3;
ss = find(sTime <= AMM_UWA_out_05.Date & AMM_UWA_out_05.Date <= eTime);
h(6) = plot(AMM_UWA_out_05.Date(ss,1),AMM_UWA_out_05.Data(ss,1),'rs'); clear ss
hold on 
AddShade([0  0] , [1.0  1.0] , period );
% leg1 = legend(h([1 2 4 5]),  'Inlet ', '', 'Outlet', '');
% set(leg1,'Location','best');
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',''  );
% title([  currentFolder ' NH_{4} at inlet and outlet  ']);
xlim([sTime  eTime]);
ylabel('mg/L'); 
% xlabel('Date (2015)');
grid on 
ylim(amm_ylim );
% ylabel('mg/L'); 
text(0.01,0.8,'b) NH_{4}','units','normalized');

ax4 = axes('position', [0.75  0.59 0.15 0.15  ]);
yyaxis(ax4,'left');
set(ax4,'YTickLabel','', 'YColor',[0 0 0]);
yyaxis(ax4,'right');

group = [ ones( length(AMM_inlet_histo_nonstorm.Data), 1) *1 ;  ...
ones(length(weirAMM_nonStorm.Data), 1)*2 ];
boxplot(ax4,[AMM_inlet_histo_nonstorm.Data ;  weirAMM_nonStorm.Data], group,'label',{'',''});
xlim([0 3]);
% ylabel('DON (mg/L)');
%set(gca,'XTick',[ 1.0  2.0  ], 'XTickLabel',{'Measured',   'Modelled'   },'xcolor','w');

ylabel('mg/L');  
ylim(amm_ylim );
%xtickangle(ax4  , 45);
box_change_colour(ax4);
%   ylabel('mg/L');                                                    




ax5 = axes('position', [0.1  0.41 0.6 0.15  ]);


DON_ylim = [ 0  1.5 ];
h(1) = plot(inletOGM_DON.Date,inletOGM_DON.Data  );
hold on
DON_UWA_in_04 =  anvil.SWQ.MSANVCBIN.HRD.Storm_04.DON;
ss = find(sTime <= DON_UWA_in_04.Date & DON_UWA_in_04.Date <= eTime);
h(2) = plot(DON_UWA_in_04.Date(ss,1),DON_UWA_in_04.Data(ss,1),'b*'); clear ss
hold on 

DON_UWA_in_05 =  anvil.SWQ.MSANVCBIN.HRD.Storm_05.DON;
ss = find(sTime <= DON_UWA_in_05.Date & DON_UWA_in_05.Date <= eTime);
h(3) = plot(DON_UWA_in_05.Date(ss,1),DON_UWA_in_05.Data(ss,1),'b*'); clear ss
hold on 

% weir

h(4)  = plot(DON_weir_10min.Date,DON_weir_10min.Data );
hold on
DON_UWA_out_04 =  anvil.SWQ.MSANVCBOUT.HRD.Storm_04.DON;
ss = find(sTime <= DON_UWA_out_04.Date & DON_UWA_out_04.Date <= eTime);
h(5) = plot(DON_UWA_out_04.Date(ss,1),DON_UWA_out_04.Data(ss,1),'rs'); clear ss
hold on 

DON_UWA_out_05 =  anvil.SWQ.MSANVCBOUT.HRD.Storm_05.DON;
ss = find(sTime <= DON_UWA_out_05.Date & DON_UWA_out_05.Date <= eTime);
h(6) = plot(DON_UWA_out_05.Date(ss,1),DON_UWA_out_05.Data(ss,1),'rs'); clear ss
hold on 

% leg1 = legend(h([1 2 4 5]),  'Inlet ', '', 'Outlet', '');
% set(leg1,'Location','best');
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',''  );
% title([  currentFolder ' DON at inlet and outlet  ']);
xlim([sTime  eTime]);
ylabel('mg/L'); 
AddShade([0  0] , [1.5  1.5] , period );
% xlabel('Date (2015)');
grid on 
ylim(DON_ylim );
text(0.01,0.8,'c) DON','units','normalized');

ax6 = axes('position', [0.75  0.41 0.15 0.15  ]);
yyaxis(ax6,'left');
set(ax6,'YTickLabel','', 'YColor',[0 0 0]);
yyaxis(ax6,'right');

group = [ ones( length(DON_inlet_histo_nonstorm.Data), 1) *1 ;  ...
ones(length(weirDON_nonStorm.Data), 1)*2 ];
BP = boxplot(ax6,[DON_inlet_histo_nonstorm.Data ;  weirDON_nonStorm.Data], group,'label',{'',''});
xlim([0 3]);
% ylabel('DON (mg/L)');
%set(gca,'XTick',[ 1.0  2.0  ], 'XTickLabel',{'Measured',  'Modelled'   });
ylabel('mg/L');                                                     
ylim(DON_ylim );
%xtickangle(ax6  , 45);
box_change_colour(ax6);





ax7 = axes('position', [0.1  0.23  0.6  0.15  ]);

PON_ylim = [ 0  1.0 ];
h(1) = plot(inletOGM_PON.Date,  inletOGM_PON.Data  );
hold on

PON_UWA_in_04 =  anvil.SWQ.MSANVCBIN.HRD.Storm_04.PN;
ss = find(sTime <= PON_UWA_in_04.Date & PON_UWA_in_04.Date <= eTime);
h(2) = plot(PON_UWA_in_04.Date(ss,1),PON_UWA_in_04.Data(ss,1),'b*'); clear ss
hold on 

PON_UWA_in_05 =  anvil.SWQ.MSANVCBIN.HRD.Storm_05.PN;
ss = find(sTime <= PON_UWA_in_05.Date & PON_UWA_in_05.Date <= eTime);
h(3) = plot(PON_UWA_in_05.Date(ss,1),PON_UWA_in_05.Data(ss,1),'b*'); clear ss


h(4) = plot(PON_weir_10min.Date,PON_weir_10min.Data  );
hold on

PON_UWA_out_04 =  anvil.SWQ.MSANVCBOUT.HRD.Storm_04.PN;
ss = find(sTime <= PON_UWA_out_04.Date & PON_UWA_out_04.Date <= eTime);
h(5)  = plot(PON_UWA_out_04.Date(ss,1),PON_UWA_out_04.Data(ss,1),'rs'); clear ss
hold on 

PON_UWA_out_05 =  anvil.SWQ.MSANVCBOUT.HRD.Storm_05.PN;
ss = find(sTime <= PON_UWA_out_05.Date & PON_UWA_out_05.Date <= eTime);
h(6) = plot(PON_UWA_out_05.Date(ss,1),PON_UWA_out_05.Data(ss,1),'rs'); clear ss


% leg1 = legend(h([1 2 4 5]),  'Inlet ', '', 'Outlet', '');
% set(leg1,'Location','best');

set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',''  );
% title([  currentFolder ' PON at inlet and  outlet  ']);
xlim([sTime  eTime]);
ylabel('mg/L'); 
AddShade([0  0] , [1.0  1.0] , period );
% xlabel('Date (2015)');
grid on  
ylim(PON_ylim  );
text(0.01,0.8,'d) PON','units','normalized');
% 
% ax2 = axes('position', [0.75  0.1 0.15 0.8  ])
% yyaxis(ax2,'left');
% set(ax2,'YTickLabel','', 'YColor',[0 0 0]);
% yyaxis(ax2,'right');
% 
% group_NIT = [ ones( length(PON_inlet_histo_nonstorm.Data), 1) *1 ;  ...
% ones(length(weirNIT_nonStorm.Data), 1)*2 ];
% boxplot([NIT_inlet_histo_nonstorm.Data ;  weirNIT_nonStorm.Data], group_NIT);
% % ylabel('DON (mg/L)');
% set(gca,'XTick',[ 1.0  2.0  ], 'XTickLabel',{'Measured', ...
%                                                           'Modelled'   });
%  ylabel('mg/L');                                                     
% ylim(PON_ylim );
% 
% box_change_colour(ax2);

ax9 = axes('position', [0.1  0.05   0.6 0.15  ]);


TN_ylim = [ 0  4.0 ];
h(1) = plot(inletTN.Date, inletTN.Data );
hold on

TN_UWA_in_04 =  anvil.SWQ.MSANVCBIN.HRD.Storm_04.UTN;
ss = find(sTime <= TN_UWA_in_04.Date & TN_UWA_in_04.Date <= eTime);
h(2) =  plot(TN_UWA_in_04.Date(ss,1),TN_UWA_in_04.Data(ss,1),'b*'); clear ss
hold on 

TN_UWA_in_05 =  anvil.SWQ.MSANVCBIN.HRD.Storm_05.UTN;
ss = find(sTime <= TN_UWA_in_05.Date & TN_UWA_in_05.Date <= eTime);
h(3) = plot(TN_UWA_in_05.Date(ss,1),TN_UWA_in_05.Data(ss,1),'b*'); clear ss
hold on 

% weir
h(4) = plot(TN_weir_10min.Date,TN_weir_10min.Data );
hold on


TN_DoW_out =  anvil.SWQ.MSANVCBOUT.LRD.DoW.WQ_DIAG_TOT_TN;
ss = find(sTime <= TN_DoW_out.Date & TN_DoW_out.Date <= eTime);
TN_DoW_out_period.Date = TN_DoW_out.Date(ss,1);
TN_DoW_out_period.Data = TN_DoW_out.Data(ss,1)./1000*14;
h(5) = plot(TN_DoW_out.Date(ss,1),TN_DoW_out.Data(ss,1)./1000*14,'rs'); clear ss
hold on 


TN_UWA_out_04 =  anvil.SWQ.MSANVCBOUT.HRD.Storm_04.UTN;
ss = find(sTime <= TN_UWA_out_04.Date & TN_UWA_out_04.Date <= eTime);
h(6) = plot(TN_UWA_out_04.Date(ss,1),TN_UWA_out_04.Data(ss,1),'rs'); clear ss
hold on 

TN_UWA_out_05 =  anvil.SWQ.MSANVCBOUT.HRD.Storm_05.UTN;
ss = find(sTime <= TN_UWA_out_05.Date & TN_UWA_out_05.Date <= eTime);
h(7) = plot(TN_UWA_out_05.Date(ss,1),TN_UWA_out_05.Data(ss,1),'rs'); clear ss
hold on 

AddShade([0  0] , [3.0  3.0] , period );
% leg1 = legend(h([1 2 4 5]),  'Inlet ', '', 'Outlet', '');
% set(leg1,'Location','best');

% 
% leg1 = legend( 'modelled inlet TN', 'modelled outlet TN');
% set(leg1,'Location','best');
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
% title([  currentFolder ' TN at inlet and outlet  ']);
xlim([sTime  eTime]);
ylabel('mg/L'); 
xlabel('Date (2015)');
grid on 
text(0.01,0.8,'e) TN','units','normalized');

ax10 = axes('position', [0.75  0.05 0.15 0.15  ]);
yyaxis(ax10,'left');
set(ax10,'YTickLabel','', 'YColor',[0 0 0]);
yyaxis(ax10,'right');

group = [ ones( length(TN_inlet_histo_nonstorm.Data), 1) *1 ;  ...
ones(length(weirTN_nonStorm.Data), 1)*2 ];
boxplot(ax10,[TN_inlet_histo_nonstorm.Data ;  weirTN_nonStorm.Data], group,'label',{'Measured','Modelled'});
xlim([0 3]);
% ylabel('DON (mg/L)');
%set(gca,'XTick',[ 1.0  2.0  ], 'XTickLabel',{'Measured',  'Modelled'   });
 ylabel('mg/L');                                                     
ylim(TN_ylim );
xtickangle(ax10  , 45);
box_change_colour(ax10);


 set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 29;
xLeft = 0; yTop = 0;
set(gcf,'paperposition',[xLeft yTop xSize ySize])
saveas(gcf,[fileOutput  'all NNN at inlet and outlet '],'png');
% 
% subplot(  num_fig  ,  1  , 3 )
% 
% 
% subplot(  num_fig  ,  1  , 4 )
% 
% subplot(  num_fig  ,  1  , 5 )
%-----------------calculate model coefficient

NIT_UWA_out_04_05 =   addStructVar(NIT_UWA_out_04   ,NIT_UWA_out_05   );
Nit_weir_10min_target    =  findNutrientsOnsameTime( NIT_UWA_out_04_05.Date, Nit_weir_10min);
[mae_NIT, rmse_NIT, ns_NIT]    = modelPerformance( NIT_UWA_out_04_05.Data, Nit_weir_10min_target.Data);
  
  AMM_UWA_out_04_05 =   addStructVar(AMM_UWA_out_04   ,AMM_UWA_out_05   );
AMM_weir_10min_target    =  findNutrientsOnsameTime( AMM_UWA_out_04_05.Date, AMM_weir_10min);
[mae_AMM, rmse_AMM, ns_AMM]    = modelPerformance( AMM_UWA_out_04_05.Data, AMM_weir_10min_target.Data);
  

  DON_UWA_out_04_05 =   addStructVar(DON_UWA_out_04   ,DON_UWA_out_05   );
DON_weir_10min_target    =  findNutrientsOnsameTime( DON_UWA_out_04_05.Date, DON_weir_10min);
[mae_DON, rmse_DON, ns_DON]    = modelPerformance( DON_UWA_out_04_05.Data, DON_weir_10min_target.Data);
  
% figure
% plot(DON_UWA_out_04_05.Date ,DON_UWA_out_04_05.Data, '*' )
% hold on 
% plot(DON_weir_10min_target.Date  ,DON_weir_10min_target.Data, 'o' )
% figure
% plot(DON_UWA_out_04_05.Data ,DON_weir_10min_target.Data, '*' )

PON_UWA_out_04_05 =   addStructVar(PON_UWA_out_04   ,PON_UWA_out_05   );
PON_weir_10min_target    =  findNutrientsOnsameTime( PON_UWA_out_04_05.Date, PON_weir_10min);
[mae_PON, rmse_PON, ns_PON]    = modelPerformance( PON_UWA_out_04_05.Data, PON_weir_10min_target.Data);
%   figure
% plot(PON_UWA_out_04_05.Date ,PON_UWA_out_04_05.Data, '*' )
% hold on 
% plot(PON_weir_10min_target.Date  ,PON_weir_10min_target.Data, 'o' )
% figure
% plot(PON_UWA_out_04_05.Data ,PON_weir_10min_target.Data, '*' )


TN_UWA_out_04_05 =   addStructVar(TN_UWA_out_04   ,TN_UWA_out_05   );
TN_UWA_out_04_05_DoW =   addStructVar(TN_UWA_out_04_05  ,TN_DoW_out_period   );
TN_weir_10min_target    =  findNutrientsOnsameTime( TN_UWA_out_04_05_DoW.Date, TN_weir_10min);
[mae_TN, rmse_TN, ns_TN]    = modelPerformance( TN_UWA_out_04_05_DoW.Data, TN_weir_10min_target.Data);
  
% figure
% plot( TN_UWA_out_04_05_DoW.Date , TN_UWA_out_04_05_DoW.Data, '*' )
NNN_mae_rmse_ns = zeros(5, 3 );

NNN_mae_rmse_ns(1, 1) = mae_NIT;
NNN_mae_rmse_ns(1, 2) = rmse_NIT;
NNN_mae_rmse_ns(1, 3) = ns_NIT;

NNN_mae_rmse_ns(2, 1) = mae_AMM;
NNN_mae_rmse_ns(2, 2) = rmse_AMM;
NNN_mae_rmse_ns(2, 3) = ns_AMM;

NNN_mae_rmse_ns(3, 1) = mae_DON;
NNN_mae_rmse_ns(3, 2) = rmse_DON;
NNN_mae_rmse_ns(3, 3) = ns_DON;


NNN_mae_rmse_ns(4, 1) = mae_PON;
NNN_mae_rmse_ns(4, 2) = rmse_PON;
NNN_mae_rmse_ns(4, 3) = ns_PON;

NNN_mae_rmse_ns(5, 1) = mae_TN;
NNN_mae_rmse_ns(5, 2) = rmse_TN;
NNN_mae_rmse_ns(5, 3) = ns_TN;




filename = [ fileOutput  'ModelPerformance_NNN.csv'];
fid = fopen(filename,'wt');
fprintf(fid, ...
  'model efficiency, mae , rmse, ns\n');
fprintf(fid,'NO3,');
for ii = 1 : length(NNN_mae_rmse_ns(1, :))
     if  ii == length(NNN_mae_rmse_ns(1, :))
         
          fprintf(fid,'%4.4f\n ',    NNN_mae_rmse_ns(1, ii));
     else
 fprintf(fid,'%4.4f, ',    NNN_mae_rmse_ns(1, ii));
     end

 
end
fprintf(fid,'NH4,');
for ii = 1 : length(NNN_mae_rmse_ns(2, :))
     if  ii == length(NNN_mae_rmse_ns(2, :))
         
          fprintf(fid,'%4.4f\n ',    NNN_mae_rmse_ns(2, ii));
     else
 fprintf(fid,'%4.4f, ',    NNN_mae_rmse_ns(2, ii));
     end

 
end


fprintf(fid,'DON,');
for ii = 1 : length(NNN_mae_rmse_ns(3, :))
     if  ii == length(NNN_mae_rmse_ns(3, :))
         
          fprintf(fid,'%4.4f\n ',    NNN_mae_rmse_ns(3, ii));
     else
 fprintf(fid,'%4.4f, ',    NNN_mae_rmse_ns(3, ii));
     end

 
end


fprintf(fid,'PON,');
for ii = 1 : length(NNN_mae_rmse_ns(4, :))
     if  ii == length(NNN_mae_rmse_ns(4, :))
         
          fprintf(fid,'%4.4f\n ',    NNN_mae_rmse_ns(4, ii));
     else
 fprintf(fid,'%4.4f, ',    NNN_mae_rmse_ns(4, ii));
     end

 
end


fprintf(fid,'TN,');
for ii = 1 : length(NNN_mae_rmse_ns(5, :))
     if  ii == length(NNN_mae_rmse_ns(5, :))
         
          fprintf(fid,'%4.4f\n ',    NNN_mae_rmse_ns(5, ii));
     else
 fprintf(fid,'%4.4f, ',    NNN_mae_rmse_ns(5, ii));
     end

 
end

fclose(fid);

