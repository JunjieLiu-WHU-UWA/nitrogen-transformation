 addpath('E:\Simulation_UWA_WD\2 For model variables\Supporting information');
 BasicRead
 % nitrogen at inlet
figure
subplot(2,1,1)
TN_DoW =  anvil.SWQ.MSANVCBIN.LRD.DoW.WQ_DIAG_TOT_TN;
ss = find(sTime <= TN_DoW.Date & TN_DoW.Date <= eTime);
plot(TN_DoW.Date(ss,1),TN_DoW.Data(ss,1)./1000*14,'o'); clear ss
hold on 

TKN_DoW =  anvil.SWQ.MSANVCBIN.LRD.DoW.WQ_DIAG_TOT_TKN;
ss = find(sTime <= TKN_DoW.Date & TKN_DoW.Date <= eTime);
plot(TKN_DoW.Date(ss,1),TKN_DoW.Data(ss,1)./1000*14,'+'); clear ss
hold on 

DON_DoW =  anvil.SWQ.MSANVCBIN.LRD.DoW.WQ_OGM_DON;
ss = find(sTime <= DON_DoW.Date & DON_DoW.Date <= eTime);
plot(DON_DoW.Date(ss,1),DON_DoW.Data(ss,1)./1000 *14,'*'); clear ss
hold on 

AMM_DoW =  anvil.SWQ.MSANVCBIN.LRD.DoW.WQ_NIT_AMM;
ss = find(sTime <= AMM_DoW.Date & AMM_DoW.Date <= eTime);
plot(AMM_DoW.Date(ss,1),AMM_DoW.Data(ss,1)./1000 *14,'s'); clear ss
hold on 

NIT_DoW =  anvil.SWQ.MSANVCBIN.LRD.DoW.WQ_NIT_NIT;
ss = find(sTime <= NIT_DoW.Date & NIT_DoW.Date <= eTime);
 plot(NIT_DoW.Date(ss,1),NIT_DoW.Data(ss,1)./1000 *14,'<'); clear ss
hold on 

legend('TN', 'TKN', 'DON', 'NH_{4}', 'NO_{3}');
xlim([sTime  eTime]);
ylabel({' mg/L '});
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
set(gca,'TickLength',[0.005 0.015]);
title({'Nitrogen concentration at inlet from Dow.', ...
    'There is no TKN, DON, PON, NH4, NO3', ' recorded druing this period from DoW'})
ylim([0  2.0]);
grid on


%--------------------

subplot(2,1,2)
TN_UWA_04 =  anvil.SWQ.MSANVCBIN.HRD.Storm_04.UTN;
ss = find(sTime <= TN_UWA_04.Date & TN_UWA_04.Date <= eTime);
plot(TN_UWA_04.Date(ss,1),TN_UWA_04.Data(ss,1),'bo'); clear ss
hold on 

TN_UWA_05 =  anvil.SWQ.MSANVCBIN.HRD.Storm_05.UTN;
ss = find(sTime <= TN_UWA_05.Date & TN_UWA_05.Date <= eTime);
plot(TN_UWA_05.Date(ss,1),TN_UWA_05.Data(ss,1),'ro'); clear ss
hold on 

DON_UWA_04 =  anvil.SWQ.MSANVCBIN.HRD.Storm_04.DON;
ss = find(sTime <= DON_UWA_04.Date & DON_UWA_04.Date <= eTime);
plot(DON_UWA_04.Date(ss,1),DON_UWA_04.Data(ss,1),'b*'); clear ss
hold on 

DON_UWA_05 =  anvil.SWQ.MSANVCBIN.HRD.Storm_05.DON;
ss = find(sTime <= DON_UWA_05.Date & DON_UWA_05.Date <= eTime);
plot(DON_UWA_05.Date(ss,1),DON_UWA_05.Data(ss,1),'r*'); clear ss
hold on 


AMM_UWA_04 =  anvil.SWQ.MSANVCBIN.HRD.Storm_04.FNH3;
ss = find(sTime <= AMM_UWA_04.Date & AMM_UWA_04.Date <= eTime);
plot(AMM_UWA_04.Date(ss,1),AMM_UWA_04.Data(ss,1),'bs'); clear ss
hold on 

AMM_UWA_05 =  anvil.SWQ.MSANVCBIN.HRD.Storm_05.FNH3;
ss = find(sTime <= AMM_UWA_05.Date & AMM_UWA_05.Date <= eTime);
plot(AMM_UWA_05.Date(ss,1),AMM_UWA_05.Data(ss,1),'rs'); clear ss
hold on 

NIT_UWA_04 =  anvil.SWQ.MSANVCBIN.HRD.Storm_04.FNOx;
ss = find(sTime <= NIT_UWA_04.Date & NIT_UWA_04.Date <= eTime);
plot(NIT_UWA_04.Date(ss,1),NIT_UWA_04.Data(ss,1),'b<'); clear ss
hold on 

NIT_UWA_05 =  anvil.SWQ.MSANVCBIN.HRD.Storm_05.FNOx;
ss = find(sTime <= NIT_UWA_05.Date & NIT_UWA_05.Date <= eTime);
plot(NIT_UWA_05.Date(ss,1),NIT_UWA_05.Data(ss,1),'r<'); clear ss
hold on 

legend('TN', ''  , 'DON','',  'NH_{4}', '', 'NO_{3}', '');
xlim([sTime  eTime]);
ylabel({' mg/L '});
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
set(gca,'TickLength',[0.005 0.015]);
title({'Nitrogen concentration at inlet from UWA', ...
    'there is  no TKN recrored from UWA'})
ylim([0  2.0]);
grid on
set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20;ySize = 20;
xLeft = 0;yTop = 0;

set(gcf,'paperposition',[xLeft yTop xSize ySize])
saveas(gcf,[  'Nitrogen_inlet'],'png');
saveas(gcf,[  'NItrogen_inlet'],'fig');


%nitrogen at outlet
figure
subplot(2,1,1)
TN_DoW =  anvil.SWQ.MSANVCBOUT.LRD.DoW.WQ_DIAG_TOT_TN;
ss = find(sTime <= TN_DoW.Date & TN_DoW.Date <= eTime);
plot(TN_DoW.Date(ss,1),TN_DoW.Data(ss,1)./1000*14,'o'); clear ss
hold on 

TKN_DoW =  anvil.SWQ.MSANVCBOUT.LRD.DoW.WQ_DIAG_TOT_TKN;
ss = find(sTime <= TKN_DoW.Date & TKN_DoW.Date <= eTime);
plot(TKN_DoW.Date(ss,1),TKN_DoW.Data(ss,1),'+'); clear ss
hold on 

DON_DoW =  anvil.SWQ.MSANVCBOUT.LRD.DoW.WQ_OGM_DON;
ss = find(sTime <= DON_DoW.Date & DON_DoW.Date <= eTime);
plot(DON_DoW.Date(ss,1),DON_DoW.Data(ss,1),'*'); clear ss
hold on 

AMM_DoW =  anvil.SWQ.MSANVCBOUT.LRD.DoW.WQ_NIT_AMM;
ss = find(sTime <= AMM_DoW.Date & AMM_DoW.Date <= eTime);
plot(AMM_DoW.Date(ss,1),AMM_DoW.Data(ss,1),'s'); clear ss
hold on 

NIT_DoW =  anvil.SWQ.MSANVCBOUT.LRD.DoW.WQ_NIT_NIT;
ss = find(sTime <= NIT_DoW.Date & NIT_DoW.Date <= eTime);
 plot(NIT_DoW.Date(ss,1),NIT_DoW.Data(ss,1),'<'); clear ss
hold on 

legend('TN', 'TKN', 'DON', 'NH_{4}', 'NO_{3}');
xlim([sTime  eTime]);
ylabel({' mg/L '});
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
set(gca,'TickLength',[0.005 0.015]);
title({'Nitrogen concentration at outlet from Dow.', ...
    'There is no TKN, DON, PON, NH4, NO3', ' recorded druing this period from DoW'})
ylim([0  2.0]);
grid on


%--------------------

subplot(2,1,2)
TN_UWA_04 =  anvil.SWQ.MSANVCBOUT.HRD.Storm_04.UTN;
ss = find(sTime <= TN_UWA_04.Date & TN_UWA_04.Date <= eTime);
plot(TN_UWA_04.Date(ss,1),TN_UWA_04.Data(ss,1),'bo'); clear ss
hold on 

TN_UWA_05 =  anvil.SWQ.MSANVCBOUT.HRD.Storm_05.UTN;
ss = find(sTime <= TN_UWA_05.Date & TN_UWA_05.Date <= eTime);
plot(TN_UWA_05.Date(ss,1),TN_UWA_05.Data(ss,1),'ro'); clear ss
hold on 

DON_UWA_04 =  anvil.SWQ.MSANVCBOUT.HRD.Storm_04.DON;
ss = find(sTime <= DON_UWA_04.Date & DON_UWA_04.Date <= eTime);
plot(DON_UWA_04.Date(ss,1),DON_UWA_04.Data(ss,1),'b*'); clear ss
hold on 

DON_UWA_05 =  anvil.SWQ.MSANVCBOUT.HRD.Storm_05.DON;
ss = find(sTime <= DON_UWA_05.Date & DON_UWA_05.Date <= eTime);
plot(DON_UWA_05.Date(ss,1),DON_UWA_05.Data(ss,1),'r*'); clear ss
hold on 


AMM_UWA_04 =  anvil.SWQ.MSANVCBOUT.HRD.Storm_04.FNH3;
ss = find(sTime <= AMM_UWA_04.Date & AMM_UWA_04.Date <= eTime);
plot(AMM_UWA_04.Date(ss,1),AMM_UWA_04.Data(ss,1),'bs'); clear ss
hold on 

AMM_UWA_05 =  anvil.SWQ.MSANVCBOUT.HRD.Storm_05.FNH3;
ss = find(sTime <= AMM_UWA_05.Date & AMM_UWA_05.Date <= eTime);
plot(AMM_UWA_05.Date(ss,1),AMM_UWA_05.Data(ss,1),'rs'); clear ss
hold on 

NIT_UWA_04 =  anvil.SWQ.MSANVCBOUT.HRD.Storm_04.FNOx;
ss = find(sTime <= NIT_UWA_04.Date & NIT_UWA_04.Date <= eTime);
plot(NIT_UWA_04.Date(ss,1),NIT_UWA_04.Data(ss,1),'b<'); clear ss
hold on 

NIT_UWA_05 =  anvil.SWQ.MSANVCBOUT.HRD.Storm_05.FNOx;
ss = find(sTime <= NIT_UWA_05.Date & NIT_UWA_05.Date <= eTime);
plot(NIT_UWA_05.Date(ss,1),NIT_UWA_05.Data(ss,1),'r<'); clear ss
hold on 

legend('TN', ''  , 'DON','',  'NH_{4}', '', 'NO_{3}', '');
xlim([sTime  eTime]);
ylabel({' mg/L '});
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
set(gca,'TickLength',[0.005 0.015]);
title({'Nitrogen concentration at outlet from UWA', ...
    'there is  no TKN recrored from UWA'})
ylim([0  2.0]);
grid on
set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20;ySize = 20;
xLeft = 0;yTop = 0;

set(gcf,'paperposition',[xLeft yTop xSize ySize])
saveas(gcf,[  'Nitrogen_outlet'],'png');
saveas(gcf,[  'NItrogen_outlet'],'fig');