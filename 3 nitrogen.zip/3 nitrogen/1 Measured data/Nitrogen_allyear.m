
 addpath('E:\Simulation_UWA_WD\2 For model variables\Supporting information');
 BasicRead
% figure
% all 
figure
subplot(5,1,1)
TN_DoW =  anvil.SWQ.MSANVCBIN.LRD.DoW.WQ_DIAG_TOT_TN;
plot(TN_DoW.Date,TN_DoW.Data./1000*14,'o'); 
hold on 
leg1 = legend('TN Inlet');
set(leg1, 'location','best');
ylabel({'mg/L'});
xlim([datenum(Allyear(1,:))  datenum(Allyear(end,:))]);
set(gca,'XTick', [ datenum(Allyear)], 'XTickLabel',  datestr( datenum(Allyear), 'yy'));
set(gca,'TickLength',[0.005 0.015]);
xlabel('Year');

subplot(5,1,2)
TKN_DoW =  anvil.SWQ.MSANVCBIN.LRD.DoW.WQ_DIAG_TOT_TKN;
plot(TKN_DoW.Date,TKN_DoW.Data./1000 *14,'+');
leg1 = legend('TKN Inlet');
set(leg1, 'location','best');
ylabel({'mg/L'});
xlim([datenum(Allyear(1,:))  datenum(Allyear(end,:))]);
set(gca,'XTick', [ datenum(Allyear)], 'XTickLabel',  datestr( datenum(Allyear), 'yy'));
set(gca,'TickLength',[0.005 0.015]);
xlabel('Year');

subplot(5,1,3)
DON_DoW =  anvil.SWQ.MSANVCBIN.LRD.DoW.WQ_OGM_DON;
plot(DON_DoW.Date,DON_DoW.Data./1000 *14,'*'); 
hold on 
leg1 = legend('DON Inlet');
set(leg1, 'location','best');
ylabel({'mg/L'});
xlim([datenum(Allyear(1,:))  datenum(Allyear(end,:))]);
set(gca,'XTick', [ datenum(Allyear)], 'XTickLabel',  datestr( datenum(Allyear), 'yy'));
set(gca,'TickLength',[0.005 0.015]);
xlabel('Year');


subplot(5,1,4)
AMM_DoW =  anvil.SWQ.MSANVCBIN.LRD.DoW.WQ_NIT_AMM;
plot(AMM_DoW.Date,AMM_DoW.Data./1000 *14,'s'); 
hold on 
leg1 = legend('NH_{4} Inlet');
set(leg1, 'location','best');
ylabel({'mg/L'});
xlim([datenum(Allyear(1,:))  datenum(Allyear(end,:))]);
set(gca,'XTick', [ datenum(Allyear)], 'XTickLabel',  datestr( datenum(Allyear), 'yy'));
set(gca,'TickLength',[0.005 0.015]);
xlabel('Year');


subplot(5,1,5)
NIT_DoW =  anvil.SWQ.MSANVCBIN.LRD.DoW.WQ_NIT_NIT;
 plot(NIT_DoW.Date,NIT_DoW.Data./1000 *14,'<'); 
hold on 
leg1 = legend('NO_{x} Inlet');
set(leg1, 'location','best');
ylabel({'mg/L'});
xlim([datenum(Allyear(1,:))  datenum(Allyear(end,:))]);
set(gca,'XTick', [ datenum(Allyear)], 'XTickLabel',  datestr( datenum(Allyear), 'yy'));
set(gca,'TickLength',[0.005 0.015]);
xlabel('Year');


set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20;ySize = 25;
xLeft = 0;yTop = 0;
set(gcf,'paperposition',[xLeft yTop xSize ySize])
saveas(gcf,[  'Nitrogen_inlet_all'],'png');
saveas(gcf,[ 'Nitrogen_inlet_all'],'fig');

%---------------------------------

figure
subplot(5,1,1)
TN_DoW =  anvil.SWQ.MSANVCBOUT.LRD.DoW.WQ_DIAG_TOT_TN;
plot(TN_DoW.Date,TN_DoW.Data./1000*14,'o'); 
hold on 
leg1 = legend('TN outlet');
set(leg1, 'location','best');
ylabel({'mg/L'});
xlim([datenum(Allyear(1,:))  datenum(Allyear(end,:))]);
set(gca,'XTick', [ datenum(Allyear)], 'XTickLabel',  datestr( datenum(Allyear), 'yy'));
set(gca,'TickLength',[0.005 0.015]);
xlabel('Year');

subplot(5,1,2)
TKN_DoW =  anvil.SWQ.MSANVCBOUT.LRD.DoW.WQ_DIAG_TOT_TKN;
plot(TKN_DoW.Date,TKN_DoW.Data./1000 *14,'+');
leg1 = legend('TKN outlet');
set(leg1, 'location','best');
ylabel({'mg/L'});
xlim([datenum(Allyear(1,:))  datenum(Allyear(end,:))]);
set(gca,'XTick', [ datenum(Allyear)], 'XTickLabel',  datestr( datenum(Allyear), 'yy'));
set(gca,'TickLength',[0.005 0.015]);
xlabel('Year');

subplot(5,1,3)
DON_DoW =  anvil.SWQ.MSANVCBOUT.LRD.DoW.WQ_OGM_DON;
plot(DON_DoW.Date,DON_DoW.Data./1000 *14,'*'); 
hold on 
leg1 = legend('DON outlet');
set(leg1, 'location','best');
ylabel({'mg/L'});
xlim([datenum(Allyear(1,:))  datenum(Allyear(end,:))]);
set(gca,'XTick', [ datenum(Allyear)], 'XTickLabel',  datestr( datenum(Allyear), 'yy'));
set(gca,'TickLength',[0.005 0.015]);
xlabel('Year');


subplot(5,1,4)
AMM_DoW =  anvil.SWQ.MSANVCBOUT.LRD.DoW.WQ_NIT_AMM;
plot(AMM_DoW.Date,AMM_DoW.Data./1000 *14,'s'); 
hold on 
leg1 = legend('NH_{4} outlet');
set(leg1, 'location','best');
ylabel({'mg/L'});
xlim([datenum(Allyear(1,:))  datenum(Allyear(end,:))]);
set(gca,'XTick', [ datenum(Allyear)], 'XTickLabel',  datestr( datenum(Allyear), 'yy'));
set(gca,'TickLength',[0.005 0.015]);
xlabel('Year');


subplot(5,1,5)
NIT_DoW =  anvil.SWQ.MSANVCBOUT.LRD.DoW.WQ_NIT_NIT;
 plot(NIT_DoW.Date,NIT_DoW.Data./1000 *14,'<'); 
hold on 
leg1 = legend('NO_{x} outlet');
set(leg1, 'location','best');
ylabel({'mg/L'});
xlim([datenum(Allyear(1,:))  datenum(Allyear(end,:))]);
set(gca,'XTick', [ datenum(Allyear)], 'XTickLabel',  datestr( datenum(Allyear), 'yy'));
set(gca,'TickLength',[0.005 0.015]);
xlabel('Year');


set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20;ySize = 25;
xLeft = 0;yTop = 0;
set(gcf,'paperposition',[xLeft yTop xSize ySize])
saveas(gcf,[  'Nitrogen_outlet_all'],'png');
saveas(gcf,[ 'Nitrogen_outlet_all'],'fig');
