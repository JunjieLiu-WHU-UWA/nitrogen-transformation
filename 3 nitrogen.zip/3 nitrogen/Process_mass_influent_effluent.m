% clearvars -except anvil sTime eTime   timeTick timeLable dicmodel currentFolder
clc
close all
addpath('E:\Simulation_UWA_WD\2 For model variables\Function');
addpath('E:\Simulation_UWA_WD\2 For model variables\Supporting information');
BasicRead
currentOutput = '3 nitrogen\'; 
file =  [dicmodel currentFolder '\Output\' currentOutput ];
if ~exist(file,'dir')      % check  whether the outdir  exists in the file of 'dir';
    mkdir(file);           % if not exists, create the file of 'outdir'
end
num_fig = 4 ;
mass_com = figure
subplot(num_fig, 1, 1)
title([ currentFolder ]);
fileTran = [file '3 NO3\NO3 transport_in.csv' ];
fid = fopen(fileTran,'rt');
data = textscan(fid,'%s %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
transIN_NOx.Date = dateTime;
transIN_NOx.Data = data{1,2}; % the unit is g/d
[ transIN_NOxnonStorm,  transIN_NOxStorm, sumtransIN_NOxperiod ]    =  ...
    sum_10min_six_period( transIN_NOx,  period_10min );
h(1) =  plot(transIN_NOx.Date, transIN_NOx.Data./1000, 'b');   %kg/d
hold on 

fileTran = [ file '3 NO3\NO3 transport_out.csv'];
fid = fopen(fileTran,'rt');
data = textscan(fid,'%s %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
transOut_NOx.Date = dateTime;
transOut_NOx.Data = data{1,2}; % the unit is g/d
[ transOut_NOxnonStorm,  transOut_NOxStorm, sumtransOut_NOxperiod ]    =  ...
    sum_10min_six_period( transOut_NOx,  period_10min );
h(2)  = plot(transOut_NOx.Date, transOut_NOx.Data ./1000 , 'r' );  %kg/d

AddShade([0  0] , [40 40] , period );
leg1 = legend(h(1:2), 'Influent', 'Effluent');
set(leg1,'Orientation','horizontal','Location','northwest');
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel','','TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
% set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);
ylim([0 30 ]);
ylabel({'NO_{3}', '(g/d)'});
%  text( sTime + 8,800,'(a)');
 text(0.08,1.1,'(a)','units','normalized');
 grid on
 title([ currentFolder ]);
 
 subplot(num_fig, 1, 2)
 % in 
 fileTran = [file '2 NH4\NH4 transport_in.csv' ];
fid = fopen(fileTran,'rt');
data = textscan(fid,'%s %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
transIn_NH4.Date = dateTime;
transIn_NH4.Data = data{1,2}; % the unit is g/d

[ transIn_NH4nonStorm,  transIn_NH4Storm, sumtransIn_NH4period ]    =  ...
    sum_10min_six_period( transIn_NH4,  period_10min );

  plot(transIn_NH4.Date, transIn_NH4.Data./1000, 'b'); % the unit is kg/d
  hold on 
 % out
 fileTran = [ file '2 NH4\NH4 transport_out.csv'];
fid = fopen(fileTran,'rt');
data = textscan(fid,'%s %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
transOut_NH4.Date = dateTime;
transOut_NH4.Data = data{1,2}; % the unit is g/d

[ transOut_NH4nonStorm,  transOut_NH4Storm, sumtransOut_NH4period ]    =  ...
    sum_10min_six_period( transOut_NH4,  period_10min );

pp = plot(transOut_NH4.Date, transOut_NH4.Data./1000 , 'r'  );% the unit is kg/d
hold on
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel','','TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
% set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);
ylim([0 15 ]);
AddShade([0  0] , [15 15] , period );
ylabel({'NH_{4}', '(kg/d)'});
%  text( sTime + 8,800,'(a)');
 text(0.08,1.1,'(b)','units','normalized');
 grid on
 
  subplot(num_fig, 1, 3)
 % Transport in
fileTran = [file '4 DON\DON transport_in.csv' ];
fid = fopen(fileTran,'rt');
data = textscan(fid,'%s %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
transIN_DON.Date = dateTime;
transIN_DON.Data = data{1,2}; % the unit is g/d

[ transIN_DONnonStorm,  transIN_DONStorm, sumtransIN_DONperiod ]    =  ...
    sum_10min_six_period( transIN_DON,  period_10min );

plot(transIN_DON.Date, transIN_DON.Data ./1000, 'b'); %kg/d
hold on

% transport out
fileTran = [ file '4 DON\DON transport_out.csv'];
fid = fopen(fileTran,'rt');
data = textscan(fid,'%s %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
transOut_DON.Date = dateTime;
transOut_DON.Data = data{1,2}; % the unit is g/d

[ transOut_DONnonStorm,  transOut_DONStorm, sumtransOut_DONperiod ]    =  ...
    sum_10min_six_period( transOut_DON,  period_10min );

pp = plot(transOut_DON.Date, transOut_DON.Data ./1000, 'r'   );%kg/d
AddShade([0  0] , [30 30] , period );
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel','','TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
% set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);
ylim([0 30 ]);
ylabel({'DON', '(kg/d)'});
%  text( sTime + 8,800,'(a)');
 text(0.08,1.1,'(c)','units','normalized');
%  title(['Scenario   '  currentFolder])
 grid on 

 
   subplot(num_fig, 1, 4)
% Transport in
fileTran = [file '5 PON\PON transport_in.csv' ];
fid = fopen(fileTran,'rt');
data = textscan(fid,'%s %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
transIN_PON.Date = dateTime;
transIN_PON.Data = data{1,2}; % the unit is g/d

[ transIN_PONnonStorm,  transIN_PONStorm, sumtransIN_PONperiod ]    =  ...
    sum_10min_six_period( transIN_PON,  period_10min );

plot(transIN_PON.Date, transIN_PON.Data./1000, 'b'); %kg/d
hold on
% transport out
fileTran = [ file '5 PON\PON transport_out.csv'];
fid = fopen(fileTran,'rt');
data = textscan(fid,'%s %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
transOut_PON.Date = dateTime;
transOut_PON.Data = data{1,2}; % the unit is g/d
[ transOut_PONnonStorm,  transOut_PONStorm, sumtransOut_PONperiod ]    =  ...
    sum_10min_six_period( transOut_PON,  period_10min );

plot(transOut_PON.Date, transOut_PON.Data./1000, 'r'   ); %kg/d
AddShade([0  0] , [20  20] , period );
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel',timeLable,'TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
% set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);
ylim([0 20 ]);
ylabel({'PON',  '(kg/d)'});
%  text( sTime + 8,800,'(a)');
 text(0.08,1.1,'(d)','units','normalized');
%  title(['Scenario   '  currentFolder])
 grid on 

 
 set(mass_com, 'PaperPositionMode', 'manual');
set(mass_com, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 29;
xLeft = 0;   yTop = 0;
set(mass_com,'paperposition',[xLeft yTop xSize ySize])
saveas(mass_com, [file 'Process_mass_inflent_effluent'],'png');


figure
%
h(1) =  plot(transIN_NOx.Date, transIN_NOx.Data./1000, 'b-');   %kg/d
hold on 
h(2)  = plot(transOut_NOx.Date, transOut_NOx.Data ./1000 , 'b:' );  %kg/d
hold on
%
  plot(transIn_NH4.Date, transIn_NH4.Data./1000, 'r-'); % the unit is kg/d
  hold on 
pp = plot(transOut_NH4.Date, transOut_NH4.Data./1000 , 'r:'  );% the unit is kg/d
hold on 
% 

plot(transIN_DON.Date, transIN_DON.Data ./1000, 'g-'); %kg/d
hold on
plot(transOut_DON.Date, transOut_DON.Data ./1000, 'g:'   );%kg/d
hold on 

%
plot(transIN_PON.Date, transIN_PON.Data./1000, 'k-'); %kg/d
hold on 
plot(transOut_PON.Date, transOut_PON.Data./1000, 'k:'   ); %kg/d
hold on


inflow(:, 1) = transIN_NOx.Data;
inflow(:, 2) =  transIn_NH4.Data;
inflow(:, 3) =  transIN_DON.Data;
inflow(:, 4) =  transIN_PON.Data;
inflow_sum = sum(inflow, 2);

outflow(:, 1) = transOut_NOx.Data;
outflow(:, 2) =  transOut_NH4.Data;
outflow(:, 3) =  transOut_DON.Data;
outflow(:, 4) =  transOut_PON.Data;
outflow_sum = sum(outflow, 2);



mass_merge = figure
% subplot(2, 1, 1)
hh = area(transIN_PON.Date, inflow./1000 );
  set(hh(1),...
    'FaceColor',[0 0 1]);
set(hh(2),...
    'FaceColor',[1 0 0]);
set(hh(3),...
    'FaceColor',[0 1 0]);
set(hh(4),...
    'FaceColor',[0 0 0]);

hold on
hhh = area(transOut_PON.Date, outflow./1000 *(-1) );
  set(hhh(1),...
    'FaceColor',[0 0 1]);
set(hhh(2),...
    'FaceColor',[1 0 0]);
set(hhh(3),...
    'FaceColor',[0 1 0]);
set(hhh(4),...
    'FaceColor',[0 0 0]);
% set(hhh, 'Ydir','reverse')
% AddShade([0  0] , [20  20] , period );
 leg_in = legend(hh(1:4), 'NO_{3}', 'NH_{4}', 'DON',   'PON' );
set( leg_in , 'Orientation','horizontal', 'Position', ...
    [0.185147507629706 0.262171052631581 0.449135300101729 0.0509868421052632]);
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel',timeLable,'TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
% set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
grid on
clear ss
xlim([sTime  eTime]);
ylim([- 60  80 ]);
ylabel({ 'kg/d'});
 text(1.05,0.5,'Inflow','units','normalized', 'Rotation',90);
  text(1.05,0.3,'Outflow','units','normalized', 'Rotation',90);
  title([ currentFolder ]);
 annotation(mass_merge,'arrow',[0.919456066945607 0.919456066945607],...
     [0.444672191528545 0.287292817679558],'LineWidth',1);
 annotation(mass_merge,'arrow',[0.919456066945607 0.919456066945607],...
    [0.477821362799263 0.646408839779006],'LineWidth',1);
%%%%%

zoom_Sdate = datenum('2015/04/20 00:00:00');
zoom_Edate = datenum('2015/05/1 00:00:00');
ss_inflow =  find(zoom_Sdate  <  transIN_PON.Date  & transIN_PON.Date  < zoom_Edate );


axes('position', [0.18  0.65  0.5 0.25  ]);
hh = area(transIN_PON.Date(ss_inflow), inflow(ss_inflow, :)./1000 );
  set(hh(1),...
    'FaceColor',[0 0 1]);
set(hh(2),...
    'FaceColor',[1 0 0]);
set(hh(3),...
    'FaceColor',[0 1 0]);
set(hh(4),...
    'FaceColor',[0 0 0]);

hold on
ss_outflow = find(zoom_Sdate  <  transOut_PON.Date  & transOut_PON.Date  < zoom_Edate );
hhh = area(transOut_PON.Date(ss_outflow), outflow(ss_outflow, :)./1000 *(-1) );
  set(hhh(1),...
    'FaceColor',[0 0 1]);
set(hhh(2),...
    'FaceColor',[1 0 0]);
set(hhh(3),...
    'FaceColor',[0 1 0]);
set(hhh(4),...
    'FaceColor',[0 0 0]);
% set(hhh, 'Ydir','reverse')
% AddShade([0  0] , [20  20] , period );
%  leg_in = legend(hh(1:4), 'NO_{3}', 'NH_{4}', 'DON',   'PON' );
% set( leg_in , 'Orientation','horizontal', 'Location','northwest');
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel','','TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
% set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
grid on
clear ss
xlim([zoom_Sdate  zoom_Edate]);
annotation(mass_merge,'arrow',[0.37029501525941 0.18616480162767],...
    [0.470052631578947 0.639473684210526]);
annotation(mass_merge,'arrow',[0.515768056968464 0.673448626653103],...
    [0.468736842105263 0.647368421052632]);


% subplot(2, 1, 2)
% area(transOut_PON.Date , inflow_sum(inlet_odd) - outflow_sum  )



 set(mass_merge, 'PaperPositionMode', 'manual');
set(mass_merge, 'PaperUnits', 'centimeters');
xSize = 15; ySize = 16;
xLeft = 0;   yTop = 0;
set(mass_merge,'paperposition',[xLeft yTop xSize ySize])
saveas(mass_merge, [file 'Process_mass_inflent_effluent_merge'],'png');


%Process_mass_inflent_effluent_merge_differInOut
mass_merge = figure
% subplot(2, 1, 1)
ax1 = axes('position', [0.1  0.5 0.8 0.4  ]);

hh = area(transIN_PON.Date, inflow./1000 );
  set(hh(1),...
    'FaceColor',[0 0 1]);
set(hh(2),...
    'FaceColor',[1 0 0]);
set(hh(3),...
    'FaceColor',[0 1 0]);
set(hh(4),...
    'FaceColor',[0 0 0]);

hold on
hhh = area(transOut_PON.Date, outflow./1000 *(-1) );
  set(hhh(1),...
    'FaceColor',[0 0 1]);
set(hhh(2),...
    'FaceColor',[1 0 0]);
set(hhh(3),...
    'FaceColor',[0 1 0]);
set(hhh(4),...
    'FaceColor',[0 0 0]);
% set(hhh, 'Ydir','reverse')
% AddShade([0  0] , [20  20] , period );
 leg_in = legend(hh(1:4), 'NO_{3}', 'NH_{4}', 'DON',   'PON' );
set( leg_in , 'Orientation','horizontal', 'Position', ...
    [0.185147507629706 0.5562171052631581 0.449135300101729 0.0509868421052632]);
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel','','TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
% set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
grid on
clear ss
xlim([sTime  eTime]);
ylim([- 60  80 ]);
ylabel({ 'kg/d'});
 text(1.05,0.5,'Inflow','units','normalized', 'Rotation',90);
  text(1.05,0.1,'Outflow','units','normalized', 'Rotation',90);
  text(0.01,1.05,'a)','units','normalized');
  
%   title([ currentFolder ]);
 annotation(mass_merge,'arrow',[0.919456066945607 0.919456066945607],...
     [0.654672191528545 0.50287292817679558],'LineWidth',1); % outflow
 %Beginning and ending x-coordinates, specified as a two-element vector of the form [x_begin x_end].
 %Beginning and ending y-coordinates, specified as a two-element vector of the form [y_begin y_end].
 annotation(mass_merge,'arrow',[0.919456066945607 0.919456066945607],...
    [0.677821362799263 0.8846408839779006],'LineWidth',1); % inflow
%%%%%

zoom_Sdate = datenum('2015/04/20 00:00:00');
zoom_Edate = datenum('2015/05/1 00:00:00');
ss_inflow =  find(zoom_Sdate  <  transIN_PON.Date  & transIN_PON.Date  < zoom_Edate );

% small panel
axes('position', [0.18  0.74  0.5 0.12  ]);
hh = area(transIN_PON.Date(ss_inflow), inflow(ss_inflow, :)./1000 );
  set(hh(1),...
    'FaceColor',[0 0 1]);
set(hh(2),...
    'FaceColor',[1 0 0]);
set(hh(3),...
    'FaceColor',[0 1 0]);
set(hh(4),...
    'FaceColor',[0 0 0]);

hold on
ss_outflow = find(zoom_Sdate  <  transOut_PON.Date  & transOut_PON.Date  < zoom_Edate );
hhh = area(transOut_PON.Date(ss_outflow), outflow(ss_outflow, :)./1000 *(-1) );
  set(hhh(1),...
    'FaceColor',[0 0 1]);
set(hhh(2),...
    'FaceColor',[1 0 0]);
set(hhh(3),...
    'FaceColor',[0 1 0]);
set(hhh(4),...
    'FaceColor',[0 0 0]);
% set(hhh, 'Ydir','reverse')
% AddShade([0  0] , [20  20] , period );
%  leg_in = legend(hh(1:4), 'NO_{3}', 'NH_{4}', 'DON',   'PON' );
% set( leg_in , 'Orientation','horizontal', 'Location','northwest');
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel','','TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
% set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
grid on
clear ss
xlim([zoom_Sdate  zoom_Edate]);
annotation(mass_merge,'arrow',[0.341810783316378 0.18413021363174],...
    [0.677631578947368 0.739473684210526]);
annotation(mass_merge,'arrow',[0.498474059003052 0.672431332655137],...
    [0.678947368421053 0.735526315789474]);


ax2 = axes('position', [0.1  0.05 0.8 0.4  ]);

diff = (inflow_sum(inlet_odd) - outflow_sum); 
area(transOut_PON.Date , diff   /1000 )
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel',timeLable,'TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
% set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
grid on
clear ss
xlim([sTime  eTime]);
ylim([- 20  60 ]);
ylabel({ 'kg/d'});
text(0.01,1.05,'b)','units','normalized');
% small panel
axes('position', [0.18  0.23  0.5 0.2  ]);
area(transOut_PON.Date(ss_outflow) , diff(ss_outflow)   /1000 )
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel','','TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
% set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
% grid on
clear ss
xlim([zoom_Sdate  zoom_Edate]);
annotation(mass_merge,'arrow',[0.343845371312309 0.182095625635809],...
    [0.157894736842106 0.230263157894737]);
annotation(mass_merge,'arrow',[0.497456765005087 0.677517802644964],...
    [0.150000000000001 0.231578947368421]);


 set(mass_merge, 'PaperPositionMode', 'manual');
set(mass_merge, 'PaperUnits', 'centimeters');
xSize = 15; ySize = 16;
xLeft = 0;   yTop = 0;
set(mass_merge,'paperposition',[xLeft yTop xSize ySize])
saveas(mass_merge, [file 'fig Process_mass_inflent_effluent_merge_differInOut'],'png');

%  whole period
% the row is NO3, NH4, DON, PON
% the column is whole period in and out, nonstorm in and out, storm evetn
% in and out
NNN_in_out = zeros( 4, 6);


NNN_in_out(1, 3)  =  transIN_NOxnonStorm ; % NOx  in   during non storm period 
NNN_in_out(1, 4)  =   transOut_NOxnonStorm; % NOx  out during non storm period

NNN_in_out(2, 3)  =   transIn_NH4nonStorm ; % NH4  in   during non storm period 
NNN_in_out(2, 4)  =   transOut_NH4nonStorm;  % NH4  out during non storm period

NNN_in_out(3, 3)  =  transIN_DONnonStorm;  %DON  in   during non storm period 
NNN_in_out(3, 4)  =   transOut_DONnonStorm; % DON  out during non storm period

NNN_in_out(4, 3)  =  transIN_PONnonStorm;  %PON  in   during non storm period 
NNN_in_out(4, 4)  =   transOut_PONnonStorm; %PON  out during non storm period

%
NNN_in_out(1, 5)  =  transIN_NOxStorm ; % NOx  in   during  storm period 
NNN_in_out(1, 6)  =   transOut_NOxStorm; % NOx  out during storm period

NNN_in_out(2, 5)  =   transIn_NH4Storm; % NH4  in   during  storm period 
NNN_in_out(2, 6)  =   transOut_NH4Storm; % NH4  out during  storm period

NNN_in_out(3, 5)  =  transIN_DONStorm ;  %DON  in   during  storm period 
NNN_in_out(3, 6)  =   transOut_DONStorm; % DON  out during  storm period

NNN_in_out(4, 5)  =  transIN_PONStorm;  %PON  in   during  storm period 
NNN_in_out(4, 6)  =  transOut_PONStorm;  %PON  out during  storm period

%

NNN_in_out(1, 1)  =   NNN_in_out(1, 3) +  NNN_in_out(1, 5);    % NOx  in   during  whole period 
NNN_in_out(1, 2)  =  NNN_in_out(1, 4) +  NNN_in_out(1, 6) ;   % NOx  out during whole period

NNN_in_out(2, 1)  =   NNN_in_out(2, 3) +  NNN_in_out(2, 5)     ;           % NH4  in   during  whole  period 
NNN_in_out(2, 2)  =     NNN_in_out(2, 4) +  NNN_in_out(2, 6) ; % NH4  out during  whole  period

NNN_in_out(3, 1)  =   NNN_in_out(3, 3) +  NNN_in_out(3, 5)     ;  %DON  in   during  whole  period 
NNN_in_out(3, 2)  =    NNN_in_out(3, 4) +  NNN_in_out(3, 6) ;  % DON  out during  whole period

NNN_in_out(4, 1)  =  NNN_in_out(4, 3) +  NNN_in_out(4, 5)     ;   %PON  in   during  whole  period 
NNN_in_out(4, 2)  =  NNN_in_out(4, 4) +  NNN_in_out(4, 6) ;    %PON  out during  whoel  period

%%%%%%%%%%%%%%
xlswrite([file 'flux_mass_tranport_sediment_process.xlsx'],NNN_in_out, 'inflowOutflow',   'B3:G6');
% xlswrite(NNN_in_out,[file 'MassInflowOutflow.xls'],'Delimiter',' ') ; 