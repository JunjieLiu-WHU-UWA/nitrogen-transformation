
% load('D:\Research in UWA\overview of data available in anvil\all_togehter_plotting\anvil.mat');
addpath('E:\Simulation_UWA_WD\2 For model variables\Function');
addpath('E:\Simulation_UWA_WD\2 For model variables\Supporting information');
BasicRead
currentOutput = '3 nitrogen\'; 
fileOutput =  [dicmodel currentFolder '\Output\' currentOutput ];
if ~exist(fileOutput,'dir')      % check  whether the outdir  exists in the file of 'dir';
    mkdir(fileOutput);           % if not exists, create the file of 'outdir'
end

fileBC =  [ dicmodel currentFolder   '\BCs\'   'Met_sourthPerth_2005_2018.csv' ];
fid = fopen(fileBC ,'rt');
str = repmat('%f ', [1 7] );
data = textscan(fid, ['%s' str], 'Headerlines',1,'Delimiter',',');
ISOTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
AirTemp.Date = ISOTime;
AirTemp.Data = data{1,4};
AirTempDay = dailyDelta(AirTemp) % calculate daily maximum, minimum, delta, mean temperature.
AirTempDailyMean.Date =  AirTempDay.Date;
AirTempDailyMean.Data = AirTempDay.varMean;

ss =  find(     sTime <= AirTempDailyMean.Date & AirTempDailyMean.Date <=  eTime );
AirTempDailyMeanPeriod.Date = AirTempDailyMean.Date(ss);
AirTempDailyMeanPeriod.Data = AirTempDailyMean.Data(ss);

%inflow 

fileFlow = [  dicmodel currentFolder  '\Output\2. Flow\'  'FlowInDaily_wholeWetland.csv'];
 fid = fopen(fileFlow,'rt');
data = textscan(fid,'%s %f','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'yyyy/mm/dd');
Inflow_Daily.Date = dateTime ;
Inflow_Daily.Data = data{1,2} ; %m3/s


fileRet = [  dicmodel currentFolder  '\Output\11. Residence time\'  'Residence_Time_weir.csv'];
 fid = fopen(fileRet,'rt');
data = textscan(fid,'%s %f','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
Weir_RET.Date = dateTime ;
Weir_RET.Data = data{1,2} ; %d
Weir_RETDay = dailyDelta(Weir_RET);

fileDO = [  dicmodel currentFolder  '\Output\4. Oxygen\'  'WeirDO_daily.csv'];
 fid = fopen(fileDO,'rt');
data = textscan(fid,'%s %f %f  %f %f %f','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'yyyy/mm/dd');
DailyMaxDO.Date = dateTime ;
DailyMaxDO.Data = data{1,2} ; %d

DailyMinDO.Date = dateTime ;
DailyMinDO.Data = data{1,3} ; %d



%-----inlet concentration of nutrients-------------------
file_inflow =  [ dicmodel currentFolder   '\BCs\'   BC_inflow ];
fid = fopen(file_inflow ,'rt');
str = repmat('%f ', [1 24] );
data_inlet = textscan(fid,['%s' str],'Headerlines',1,'Delimiter',',');
ISOTime_in = datenum(data_inlet{1,1},'dd/mm/yyyy HH:MM:SS');
InflowNIT.Date  = ISOTime_in;
InflowNIT.Data  = data_inlet{1,10} * N_mmol_g ;  %  the unit is  mmol /m3 to mg/L
InflowNITDay = dailyDelta(InflowNIT);

InflowAMM.Date  = ISOTime_in;
InflowAMM.Data  = data_inlet{1,9} * N_mmol_g ;  %  the uAMM is  mmol /m3 to mg/L
InflowAMMDay = dailyDelta(InflowAMM);

InflowDON.Date  = ISOTime_in;
InflowDON.Data  = data_inlet{1,15} * N_mmol_g ;  %  the uAMM is  mmol /m3 to mg/L
InflowDONDay = dailyDelta(InflowDON);



% concentration of AMM, 


fileweir = [  dicmodel currentFolder  '\Output\3 nitrogen\2 NH4\'  'NH4_weir_10min.csv'];
 fid = fopen(fileweir,'rt');
data = textscan(fid,'%s %f','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
Weir_AMM.Date = dateTime ;
Weir_AMM.Data = data{1,2} ; %mg/L
Weir_AMMDay = dailyDelta(Weir_AMM);



% concentration of NOx, 

fileweir = [  dicmodel currentFolder  '\Output\3 nitrogen\3 NO3\'  'Nit_weir_10min.csv'];
 fid = fopen(fileweir,'rt');
data = textscan(fid,'%s %f','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
Weir_NIT.Date = dateTime ;
Weir_NIT.Data = data{1,2} ; %mg/L
Weir_NITDay = dailyDelta(Weir_NIT);

fileweir = [  dicmodel currentFolder  '\Output\3 nitrogen\4 DON\'  'DON_weir.csv'];
 fid = fopen(fileweir,'rt');
data = textscan(fid,'%s %f','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
Weir_DON.Date = dateTime ;
Weir_DON.Data = data{1,2} ; %mg/L
Weir_DONDay = dailyDelta(Weir_DON);
% 
RE_AMM.Date = Weir_AMMDay.Date;
RE_AMM.Data   =   CalcuRemovalData(InflowAMMDay.varMean, Weir_AMMDay.varMean  );
kv_AMM.Date  = Weir_AMMDay.Date;
kv_AMM.Data   =   CalcuKvData(InflowAMMDay.varMean, Weir_AMMDay.varMean,  Weir_RETDay.varMean );
 
% 
RE_NIT.Date = Weir_NITDay.Date;
RE_NIT.Data   =   CalcuRemovalData(InflowNITDay.varMean, Weir_NITDay.varMean  );
kv_NIT.Date  = Weir_NITDay.Date;
kv_NIT.Data   =   CalcuKvData(InflowNITDay.varMean, Weir_NITDay.varMean,  Weir_RETDay.varMean );
 

 RE_DON.Date = Weir_DONDay.Date;
RE_DON.Data   =   CalcuRemovalData(InflowDONDay.varMean, Weir_DONDay.varMean  );
kv_DON.Date  = Weir_DONDay.Date;
kv_DON.Data   =   CalcuKvData(InflowDONDay.varMean, Weir_DONDay.varMean,  Weir_RETDay.varMean );
 
 %remove the first  6 points
 latter_array = (7:1:61)';

x1 = AirTempDailyMeanPeriod.Data(latter_array);
x2  = Inflow_Daily.Data(latter_array);
x3 = Weir_RETDay.varMean(latter_array);
x4 =DailyMaxDO.Data( latter_array);    % Contains NaN data
x5 = DailyMinDO.Data(latter_array);

figure
subplot(4,1,1)
plot(AirTempDailyMeanPeriod.Date(latter_array) , AirTempDailyMeanPeriod.Data(latter_array) )
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',''  );
xlim([sTime  eTime]);
ylabel('Air temp (^{\circ}C)');
grid on

subplot(4,1,2)
plot(Inflow_Daily.Date(latter_array)  , Inflow_Daily.Data(latter_array) )
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel','' );
xlim([sTime  eTime]);
ylabel('Daily inflowrate (m^{3}/s) ');
grid on

subplot(4, 1, 3)
plot(Weir_RETDay.Date(latter_array) , Weir_RETDay.varMean(latter_array))
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel','' );
xlim([sTime  eTime]);
ylabel('residence time (d)');
grid on

subplot(4, 1, 4)
plot(DailyMinDO.Date(latter_array) , DailyMinDO.Data(latter_array) )
hold on
plot(DailyMaxDO.Date( latter_array) , DailyMaxDO.Data( latter_array) )
leg1 = legend('Daily max DO', 'Daily min DO' );
set(leg1,'Location','northwest');
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
xlim([sTime  eTime]);
ylabel('DO (mg/L)');
grid on

set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 20;
xLeft = 0;   yTop = 0;
set(gcf,'paperposition',[xLeft yTop xSize ySize])
saveas(gcf,[fileOutput  'Air temp flowrate residence time DO'],'png');

figure
plot( InflowAMMDay.Date( latter_array) , InflowAMMDay.varMean( latter_array), 'b' )
hold on

plot( InflowNITDay.Date( latter_array) , InflowNITDay.varMean( latter_array),'g' )
hold on

plot( InflowDONDay.Date( latter_array) , InflowDONDay.varMean( latter_array) , 'r')
hold on
leg1 = legend('Daily NH4', 'Daily NOx', 'Daily DON'  );
set(leg1,'Location','northwest');
xlim([sTime  eTime]);
ylabel('mg/L');
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );

set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 10;
xLeft = 0;   yTop = 0;
set(gcf,'paperposition',[xLeft yTop xSize ySize])
saveas(gcf,[fileOutput  'Daily NH4 NOx DON'],'png');

figure
plot(kv_AMM.Date(latter_array) , kv_AMM.Data(latter_array), 'b')
hold on
plot(kv_NIT.Date(latter_array) , kv_NIT.Data(latter_array), 'g')
hold on
plot(kv_DON.Date(latter_array) , kv_DON.Data(latter_array), 'r')
hold on

leg1 = legend('NH4', 'NOx', 'DON'  );
set(leg1,'Location','best');
xlim([sTime  eTime]);
ylabel('k_{v} (d^{-1})');
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );

set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 10;
xLeft = 0;   yTop = 0;
set(gcf,'paperposition',[xLeft yTop xSize ySize])
saveas(gcf,[fileOutput  'kv NH4 NOx DON'],'png');




figure
plot(RE_AMM.Date(latter_array) ,RE_AMM.Data(latter_array) .* 100, 'b' )
hold on
plot(RE_NIT.Date(latter_array) ,RE_NIT.Data(latter_array).* 100 , 'g')
hold on
plot(RE_DON.Date(latter_array) ,RE_DON.Data(latter_array).* 100 , 'r')
hold on

leg1 = legend('NH4', 'NOx', 'DON'  );
set(leg1,'Location','best');
xlim([sTime  eTime]);
ylabel('RE (%)');
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );

set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 10;
xLeft = 0;   yTop = 0;
set(gcf,'paperposition',[xLeft yTop xSize ySize])
saveas(gcf,[fileOutput  'RE percent NH4 NOx DON'],'png');







% the R2 statistic, the F-statistic and its p-value, and an estimate of the error variance.
ingredients(:, 1) =  AirTempDailyMeanPeriod.Data(latter_array);
ingredients(:, 2) =   Inflow_Daily.Data(latter_array);
ingredients(:, 3) =   Weir_RETDay.varMean(latter_array);
ingredients(:, 4) =   DailyMaxDO.Data( latter_array);    % Contains NaN data
ingredients(:, 5) =    DailyMinDO.Data(latter_array);  % Contains NaN data

x_AMM = ingredients;
x_AMM(:,6) = InflowAMMDay.varMean( latter_array);
mdl_AMM_kv = stepwiselm(x_AMM, kv_AMM.Data(latter_array) , 'constant','Upper','linear' );
mdl_AMM_RE = stepwiselm(x_AMM, RE_AMM.Data(latter_array) , 'constant','Upper','linear' );



x_NIT = ingredients;
x_NIT(:, 6) = InflowNITDay.varMean( latter_array);
mdl_NIT_kv = stepwiselm(x_NIT, kv_NIT.Data(latter_array), 'constant','Upper','linear'  );
mdl_NIT_RE = stepwiselm(x_NIT, RE_NIT.Data(latter_array), 'constant','Upper','linear'  );


x_DON = ingredients;
x_DON(:, 6) = InflowDONDay.varMean( latter_array);
mdl_DON_kv = stepwiselm(x_DON, kv_DON.Data(latter_array) , 'constant','Upper','linear');
mdl_DON_RE = stepwiselm(x_DON, RE_DON.Data(latter_array) , 'constant','Upper','linear' );
% ingredients(:, 5) =     InflowNitDay.varMean( latter_array); % Contains NaN data
% ingredients(:, 6) =  kv_NIT.Data( latter_array);
% 
% mdl = stepwiselm(ingredients, y2)
% mdl = stepwiselm(ingredients, y1)
% [coeff,score,latent] = pca(ingredients);


