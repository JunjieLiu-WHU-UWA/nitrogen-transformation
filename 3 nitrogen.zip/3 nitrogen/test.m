
figure1 = figure
ax1 = axes('position', [0.1 0.7 0.25 0.25  ]);
H = bar(nitrogen_in_nonStorm./1000, 'stacked') ;% convert g to kg
set(gca,'xticklabel',name);
ylabel('kg')
% text('inflow and sediment flux of nitrogen')
AX=legend(H, {'Inflow of NO_{3}','Inflow of NH_{4}', 'Inflow of DON', 'Inflow of PON',  ...
    'Sediment flux of NO_{3}', 'Sediment flux of NH_{4}', 'Sedimetn flux of DON'}, 'FontSize',8, ...
    'Position',[0.3850 0.755142857142857 0.235503560528993 0.278947368421052]);
xlim([0.5 2.5]);
text(0.01,1.05, '(a)','units','normalized');

ax2 = axes('position', [0.7 0.7 0.25 0.25  ]);
% yyaxis right
bar(nitrogen_in_nonStorm_percent, 'stacked')
set(gca,'xticklabel',name)
ylabel('%')
ylim([ 0 1 ])
xlim([0.5 2.5]);
text(0.01,1.05, '(b)','units','normalized');

%outflow
ax3 = axes('position', [0.1 0.4 0.25 0.25  ]);
H = bar(nitrogen_out_nonStorm./1000, 'stacked'); % convert g to kg
set(gca,'xticklabel',name)
ylabel('kg')
xlim([0.5 2.5]);

AX=legend(H, {'Outflow of NO_{3}', 'Outflow of NH_{4}', 'Outflow of DON',   'Outflow of PON'}, ...
  'FontSize',8, ...
    'Position',[0.40 0.55 0.192777212614446 0.159774436090225]);

% annotation(figure1,'textbox',...
%     [0.387571719226857 0.613533834586466 0.257392675483215 0.0556390977443608],...
%     'String',{'Outflow of nitrogen'},...
%     'FitBoxToText','off');
text(0.01,1.05, '(c)','units','normalized');

ax4 = axes('position', [0.7 0.4 0.25 0.25  ]);
% yyaxis right
bar(nitrogen_out_nonStorm_percent, 'stacked')
set(gca,'xticklabel',name)
ylabel('%')
ylim([ 0 1 ]);
xlim([0.5 2.5]);
text(0.01,1.05, '(d)','units','normalized');
  %removal
ax5 = axes('position', [0.1 0.1 0.25 0.25  ]);
H= bar(removal_nonStorm./1000, 'stacked')% convert g to kg
set(gca,'xticklabel',name)
ylabel('kg');
xlim([0.5 2.5]);
AX=legend(H, {'Sedimentation of PON', 'Denitrification', 'Benthic net uptake'}, ...
    'FontSize',8, ...
    'Position',[0.40 0.28 0.24059003051882 0.106015037593985]);

% annotation(figure1,'textbox',...
%     [0.406900305188199 0.314285714285714 0.204493387589013 0.0421052631578948],...
%     'String',{'Removal of nitrogen'},...
%     'FitBoxToText','off');
text(0.01,1.05, '(e)','units','normalized');

ax6 = axes('position', [0.7 0.1 0.25 0.25  ]);
% yyaxis right
bar(removal_nonStorm_percent, 'stacked')
set(gca,'xticklabel',name)
ylabel('%')
ylim([ 0 1 ]);
xlim([0.5 2.5]);
text(0.01,1.05, '(f)','units','normalized');

 set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 15; ySize = 25;
xLeft = 0; yTop = 0;

set(gcf,'paperposition',[xLeft yTop xSize ySize])
% saveas(gcf, [file   'EffectFlowrateOnSOD'],'jpg');
% saveas(gcf, [file   'EffectFlowrateOnSOD'],'fig');

print(gcf,[ file 'Nitrogen_bar.tiff'],'-dtiff','-r300');
print(gcf,[file 'Nitrogen_bar.png'],'-dpng','-r300');