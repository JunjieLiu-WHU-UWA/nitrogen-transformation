
close all
addpath('E:\Simulation_UWA_WD\2 For model variables\Function');
addpath('E:\Simulation_UWA_WD\2 For model variables\Supporting information');
BasicRead

currentOutput = '3 nitrogen\'; 
fileOutput =  [dicmodel currentFolder '\Output\' currentOutput ];
if ~exist(fileOutput,'dir')      % check  whether the outdir  exists in the file of 'dir';
    mkdir(fileOutput);           % if not exists, create the file of 'outdir'
end

sed = figure

subplot( 4, 1, 1)
fileNH4 = [ fileOutput '2 NH4\Sediment flux of NH4 _wholeWetland.csv'];
fid = fopen(fileNH4,'rt');
data = textscan(fid,'%s %f %f ','Headerlines',1,'Delimiter',',');
sedFluxNH4.Date = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
sedFluxNH4.Data = data{1,3};
pp = plot(sedFluxNH4.Date  , sedFluxNH4.Data  );
hold on 


SedFluxNH4Daily = dailySum(sedFluxNH4);
filesedFlux_NH4DailyOut = [ fileOutput '2 NH4\SedimentfluxofNH4_Daily_rate_wholeWetland.csv'];
writeDaily(SedFluxNH4Daily,  filesedFlux_NH4DailyOut  ,  'SedimentfluxofNH4Daily(g N/m2 /d)'  );
[SedFluxNH4DailynonStorm,  SedFluxNH4DailyStorm ]   = divide2period( SedFluxNH4Daily);
[h_SedFlux_NH4Daily,p_SedFlux_NH4Daily, ci, stats] = ttest2(SedFluxNH4DailynonStorm.Data,   SedFluxNH4DailyStorm.Data);

statis_comparison = zeros(4, 1);

statis_comparison(2, 1) = p_SedFlux_NH4Daily; %in the output file, the first is NO3. the second is NH4. 

set(gca,'XTick',[ datenum(timeTick )],'XTickLabel','','TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);
ylabel({'Sediment flux',' NH_{4}', '(gN /m2 /d)'});
%  text( sTime + 8,800,'(a)');
 text(0.08,1.1,'(a)','units','normalized');
 title([ currentFolder])
 grid on 



subplot( 4, 1, 2)
fileNO3 = [ fileOutput '3 NO3\Sediment flux of NO3 _wholeWetland.csv'];
fid = fopen(fileNO3,'rt');
data = textscan(fid,'%s %f %f ','Headerlines',1,'Delimiter',',');
sedFluxNO3.Date = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
sedFluxNO3.Data = data{1,3};
pp = plot(sedFluxNO3.Date  , sedFluxNO3.Data  );
hold on 

SedFluxNO3Daily = dailySum(sedFluxNO3);
filesedFlux_NO3DailyOut = [ fileOutput '3 NO3\SedimentfluxofNO3_Daily_rate_wholeWetland.csv'];
writeDaily(SedFluxNO3Daily,  filesedFlux_NO3DailyOut  ,  'SedimentfluxofNO3Daily(g N/m2 /d)'  );
[SedFluxNO3DailynonStorm,  SedFluxNO3DailyStorm ]   = divide2period( SedFluxNO3Daily);
[h_SedFlux_NO3Daily,p_SedFlux_NO3Daily, ci, stats] = ttest2(SedFluxNO3DailynonStorm.Data,   SedFluxNO3DailyStorm.Data);

statis_comparison(1, 1) = p_SedFlux_NO3Daily; %in the output file, the first is NO3. the second is NH4. 
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel','','TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);
ylabel({'Sediment flux',' NO_{3}', '(gN /m2 /d)'});
%  text( sTime + 8,800,'(a)');
 text(0.08,1.1,'(b)','units','normalized');
%  title([ currentFolder])
 grid on 
 
 
subplot( 4, 1, 3)

fileDON = [ fileOutput '4 DON\Sediment flux of DON _wholeWetland.csv'];
fid = fopen(fileDON,'rt');
data = textscan(fid,'%s %f %f ','Headerlines',1,'Delimiter',',');
sedFluxDON.Date = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
sedFluxDON.Data = data{1,3};
pp = plot(sedFluxDON.Date  , sedFluxDON.Data  );
hold on 

SedFluxDONDaily = dailySum(sedFluxDON);
filesedFlux_DONDailyOut = [ fileOutput '4 DON\SedimentfluxofDON_Daily_rate_wholeWetland.csv'];
writeDaily(SedFluxDONDaily,  filesedFlux_DONDailyOut  ,  'SedimentfluxofDONDaily(g N/m2 /d)'  );
[SedFluxDONDailynonStorm,  SedFluxDONDailyStorm ]   = divide2period( SedFluxDONDaily);
[h_SedFlux_DONDaily,p_SedFlux_DONDaily, ci, stats] = ttest2(SedFluxDONDailynonStorm.Data,   SedFluxDONDailyStorm.Data);

statis_comparison(3, 1) = p_SedFlux_DONDaily;
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel','','TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);
ylabel({'Sediment flux ',' DON', '(gN /m2 /d)'});
%  text( sTime + 8,800,'(a)');
 text(0.08,1.1,'(c)','units','normalized');
%  title([ currentFolder])
 grid on 
 
 
subplot( 4, 1, 4)

filePON = [ fileOutput '5 PON\PON sedimentation _wholeWetland.csv'];
fid = fopen(filePON,'rt');
data = textscan(fid,'%s %f %f ','Headerlines',1,'Delimiter',',');
sedimenPON.Date = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
sedimenPON.Data = data{1,3} *  (-1);
pp = plot(sedimenPON.Date  , sedimenPON.Data  );
hold on 

SedimenPONDaily = dailySum(sedimenPON);
filesedimen_PONDailyOut = [ fileOutput '5 PON\SedimentfluxofPON_Daily_rate_wholeWetland.csv'];
writeDaily(SedimenPONDaily,  filesedimen_PONDailyOut  ,  'SedimentfluxofPONDaily(g N/m2 /d)'  );
[sedimenPONDailynonStorm,  sedimenPONDailyStorm ]   = divide2period( SedimenPONDaily);
[h_sedimen_PONDaily,p_sedimen_PONDaily, ci, stats] = ttest2(sedimenPONDailynonStorm.Data,   sedimenPONDailyStorm.Data);

statis_comparison(4, 1) = p_sedimen_PONDaily;
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel','','TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);
ylabel({'Sedimentation ','PON', '(gN /m2 /d)'});
%  text( sTime + 8,800,'(a)');
 text(0.08,1.1,'(d)','units','normalized');
%  title([ currentFolder])
 grid on 


set(sed, 'PaperPositionMode', 'manual');
set(sed, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 29;
xLeft = 0;   yTop = 0;
set(sed,'paperposition',[xLeft yTop xSize ySize])
saveas(sed, [fileOutput 'Process_rate_NNN_sediment'],'png');



%comparison between non-strom and storm event

lenNonStorm  = length( SedFluxNH4DailynonStorm.Data  );
lenStorm = length(SedFluxNH4DailyStorm.Data);

all_box = [SedFluxNH4DailynonStorm.Data; SedFluxNH4DailyStorm.Data; ...
 SedFluxNO3DailynonStorm.Data; SedFluxNO3DailyStorm.Data; ...
  SedFluxDONDailynonStorm.Data; SedFluxDONDailyStorm.Data; ...
sedimenPONDailynonStorm.Data; sedimenPONDailyStorm.Data] * 1000;


all_grp = [  ones( lenNonStorm, 1) *1; ones( lenStorm, 1) * 2; ...
                  ones( lenNonStorm, 1) *3; ones( lenStorm, 1) * 4; ...
                  ones( lenNonStorm, 1) *5; ones( lenStorm, 1) * 6; ...
                  ones( lenNonStorm, 1) *7; ones( lenStorm, 1) * 8];
com_sed = figure
% yyaxis left
 boxplot(all_box, all_grp);
 hold on
%  yyaxis right
%   boxplot(all_box_ben, all_grp_ben);
set(gca,'XTick',[1.5  3.5 5.5 7.5  ], 'XTickLabel',{'Sediment flux of NH4', ...
                                                          'Sediment flux of  NO3', ...
                                                          'Sediment flux of DON', ...
                                                          'Sedimentation of PON' },'TickLength',[0.005 0.015]);
% set(fig, 'XTickLabel','');
max_value  = 120; 
ylabel({'mg N /m^{2}/d'});
x2 = [1.5  2.5];
y4 = [0  0 ];
y5= [max_value   max_value ];
patch('YData',[y4 fliplr(y5)],'XData',[x2 fliplr(x2)],...
    'FaceColor',[0.5 0.5 0.5], ...
    'EdgeColor','none');
alpha(0.5)

x2 = [3.5  4.5];
y4 = [0  0 ];
y5= [max_value   max_value ];
patch('YData',[y4 fliplr(y5)],'XData',[x2 fliplr(x2)],...
    'FaceColor',[0.5 0.5 0.5], ...
    'EdgeColor','none');
alpha(0.5)

x2 = [5.5  6.5];
y4 = [0  0 ];
y5= [max_value   max_value ];
patch('YData',[y4 fliplr(y5)],'XData',[x2 fliplr(x2)],...
    'FaceColor',[0.5 0.5 0.5], ...
    'EdgeColor','none');
alpha(0.5)

x2 = [7.5  8.5];
y4 = [0  0 ];
y5= [max_value   max_value ];
patch('YData',[y4 fliplr(y5)],'XData',[x2 fliplr(x2)],...
    'FaceColor',[0.5 0.5 0.5], ...
    'EdgeColor','none');
alpha(0.5)
% title([ currentFolder ]);



set(com_sed, 'PaperPositionMode', 'manual');
set(com_sed, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 10;
xLeft = 0; yTop = 0;

set(com_sed, 'paperposition',[xLeft yTop xSize ySize])
saveas(com_sed, [fileOutput   'Comparison of sediment flux nitrogen non storm'],'png');
% saveas(gcf, [fileOutput    'Comparison of process nitrorgen non storm'],'fig');
print(gcf,[fileOutput  'fig Comparison of sediment flux nitrogen non storm_label.png'],'-dpng','-r300');

% calculate the median  during non storm period %g N /m2/d
% NO3
sedFluxMedian_nonStorm(1 , 1 ) =  median(SedFluxNO3DailynonStorm.Data  );
% NH4
sedFluxMedian_nonStorm(2 , 1 ) =  median(SedFluxNH4DailynonStorm.Data  );
% DON
sedFluxMedian_nonStorm(3 , 1 ) =  median(SedFluxDONDailynonStorm.Data  );
%PON
sedFluxMedian_nonStorm(4 , 1 ) =  median(sedimenPONDailynonStorm.Data  );

sedFluxMedian_nonStorm = sedFluxMedian_nonStorm * 1000; %mg N /m2/d
% calculate the median  during  storm period  % g N /m2/d
% NO3
sedFluxMedian_Storm(1 , 1 ) =  median(SedFluxNO3DailyStorm.Data  );
% NH4
sedFluxMedian_Storm(2 , 1 ) =  median(SedFluxNH4DailyStorm.Data  );
% DON
sedFluxMedian_Storm(3 , 1 ) =  median(SedFluxDONDailyStorm.Data  );
%PON
sedFluxMedian_Storm(4 , 1 ) =  median(sedimenPONDailyStorm.Data  );

sedFluxMedian_Storm = sedFluxMedian_Storm * 1000; %mg N /m2/d


% calculate the median  during whole period % g N /m2/d
% NO3
sedFluxMedian_whole(1 , 1 ) =  median(SedFluxNO3Daily.Data  );
% NH4
sedFluxMedian_whole(2 , 1 ) =  median(SedFluxNH4Daily.Data  );
% DON
sedFluxMedian_whole(3 , 1 ) =  median(SedFluxDONDaily.Data  );
%PON
sedFluxMedian_whole(4 , 1 ) =  median(SedimenPONDaily.Data  );

sedFluxMedian_whole = sedFluxMedian_whole * 1000; %mg N /m2/d

%---------------Write sediment flux    into file ---------------------------------------------------------
 filename = [ fileOutput 'sedimentFlux_nitrogen_non_storm.csv'];
fid = fopen(filename,'wt');
fprintf(fid, ...
  'species (mg N /m2/d), sedFlux NO3, sedFlux NH4, sedFlux DON,sedmetation PON\n');
fprintf(fid,'sedFluxMedian_nonStorm,');
for ii = 1 : length(sedFluxMedian_nonStorm)
     if  ii == length(sedFluxMedian_nonStorm)
         
          fprintf(fid,'%4.4f\n ',    sedFluxMedian_nonStorm(ii));
     else
 fprintf(fid,'%4.4f, ',    sedFluxMedian_nonStorm(ii));
     end

 
end
fprintf(fid,'sedFluxMedian_Storm,');
for ii = 1 : length(sedFluxMedian_Storm)
     if  ii == length(sedFluxMedian_Storm)
         
          fprintf(fid,'%4.4f\n ',    sedFluxMedian_Storm(ii));
     else
 fprintf(fid,'%4.4f, ',    sedFluxMedian_Storm(ii));
     end

 
end


fprintf(fid,'sedFluxMedian_whole,');
for ii = 1 : length(sedFluxMedian_whole)
     if  ii == length(sedFluxMedian_whole)
         
          fprintf(fid,'%4.4f\n ',    sedFluxMedian_whole(ii));
     else
 fprintf(fid,'%4.4f, ',    sedFluxMedian_whole(ii));
     end

 
end
% I have check the mananual sequece of 
fprintf(fid,'p value,');
for ii = 1 : length(statis_comparison)
     if  ii == length(statis_comparison)
         
          fprintf(fid,'%4.4f\n ',    statis_comparison(ii));
     else
 fprintf(fid,'%4.4f, ',    statis_comparison(ii));
     end

 
end

fclose(fid);

% calibriation for sediment flux of NH4
fig_aaa = figure;
rate_SedFluxNH4 = [SedFluxNH4DailynonStorm.Data * 1000; ... % first is the modelled results
                  47.66 ; 33.47 ; -20.39;  27 ] ...  % second is the meausred resulsts
           % third is vluae from literature  % mg N/m2/d
               
 location_SedFluxNH4 =  [ones( lenNonStorm, 1) *1;   ...
                ones(4,1) * 2] ;
            
   boxplot(rate_SedFluxNH4,  location_SedFluxNH4) ;        
 set(gca,'XTick',[1  2   3 ], 'XTickLabel',{'Modlled', ...
                                                          'Measured'},'TickLength',[0.005 0.015]);  
ylabel('mg N /m^{2}/d');    
title([ currentFolder 'Sedimentflux' ]);
set(fig_aaa, 'PaperPositionMode', 'manual');
set(fig_aaa, 'PaperUnits', 'centimeters');
xSize = 8; ySize = 8;
xLeft = 0; yTop = 0;

set(fig_aaa, 'paperposition',[xLeft yTop xSize ySize])

 print(fig_aaa,[fileOutput  'CalibriationSedFluxNH4_model_measure_literature.tiff'],'-dtiff','-r300');
print(fig_aaa,[fileOutput  'CalibriationSedFluxNH4_model_measure_literature.png'],'-dpng','-r300');




% calibriation for sediment flux of NH4
fig_aaa = figure;
rate_SedFluxNH4 = [SedFluxNH4DailynonStorm.Data * 1000; ... % first is the modelled results
                   ];  % second is the meausred resulsts
           % third is vluae from literature  % mg N/m2/d
     
 location_SedFluxNH4 =  [ones( lenNonStorm, 1) *1];
      measure_SedFluxNH4 = [   47.66 ; 33.47 ; -20.39;  27  ] ;   % second is the meausred resulsts       
      location_sedFluxNH4 = [ 2 2 2 2];
      
   boxplot(rate_SedFluxNH4,  location_SedFluxNH4) ;        
   hold on
%    scatter(2.5 , 47.66)
   h(1) = scatter( location_sedFluxNH4, measure_SedFluxNH4, '*');
   % summer:
measure_SedFluxNH4_sum = [-1.47 -465.85  -2.74  130.69 ] ;% measurement in summer
  h(2) = scatter( location_sedFluxNH4,  measure_SedFluxNH4_sum, 's');
   xlim([0.5 2.5]);
  ylim([-500  140]);

%    
 set(gca,'XTick',[1  2    ], 'XTickLabel',{'Modelled', ...
                                                          'Measured'},'TickLength',[0.005 0.015]);  
ylabel('mg N /m^{2}/d');    
% title([ currentFolder 'Sedimentflux' ]);
%   legend(h(1:2), 'Winter', 'Summer');
  breakInfo = breakyaxis([-450  -50 ], 0.04);
% legend(gca,'show');

set(fig_aaa, 'PaperPositionMode', 'manual');
set(fig_aaa, 'PaperUnits', 'centimeters');
xSize = 8; ySize = 8;
xLeft = 0; yTop = 0;

set(fig_aaa, 'paperposition',[xLeft yTop xSize ySize])


print(fig_aaa,[fileOutput  'fig CalibriationSedFluxNH4_model_measure_WinSum.png'],'-dpng','-r300');
