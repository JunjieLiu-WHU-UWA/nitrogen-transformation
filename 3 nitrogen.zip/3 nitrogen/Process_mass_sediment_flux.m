% clearvars -except anvil sTime eTime   timeTick timeLable dicmodel currentFolder
clc
close all
addpath('E:\Simulation_UWA_WD\2 For model variables\Function');
addpath('E:\Simulation_UWA_WD\2 For model variables\Supporting information');
BasicRead
currentOutput = '3 nitrogen\'; 
fileOutput =  [dicmodel currentFolder '\Output\' currentOutput ];
if ~exist(fileOutput,'dir')      % check  whether the outdir  exists in the file of 'dir';
    mkdir(fileOutput);           % if not exists, create the file of 'outdir'
end

figure

subplot( 4, 1, 1)
fileNO3 = [ fileOutput '3 NO3\Sediment flux of NO3 _wholeWetland.csv'];
fid = fopen(fileNO3,'rt');
data = textscan(fid,'%s %f %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
sedNO3mass.Date =  dateTime;
sedNO3mass.Data =  data{1,2};

[sedNO3massnonStorm, sedNO3massStorm, sumsedNO3massperiod ]    =  ...
    sum_10min_six_period(sedNO3mass,  period_10min );
pp = plot(sedNO3mass.Date  , sedNO3mass.Data   );% g/d

hold on 
AddShade([0  0] , [250  250] , period );
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel','','TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);
ylabel({'Sediment flux',' NO_{3}', '(g/d)'});
%  text( sTime + 8,800,'(a)');
 text(0.08,1.1,'(a)','units','normalized');
 title([ currentFolder])
 grid on 
 
subplot( 4, 1, 2)
fileNH4 = [ fileOutput '2 NH4\Sediment flux of NH4 _wholeWetland.csv'];
fid = fopen(fileNH4,'rt');
data = textscan(fid,'%s %f %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');

sedNH4mass.Date = dateTime;
sedNH4mass.Data =  data{1,2};
[sedNH4massnonStorm, sedNH4massStorm, sumsedNH4massperiod ]    =  ...
    sum_10min_six_period(sedNH4mass,  period_10min );

pp = plot(sedNH4mass.Date  , sedNH4mass.Data   )% g/d
hold on 
AddShade([0  0] , [150  150] , period );
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel','','TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);
ylabel({'Sediment flux',' NH_{4}', '(g/d)'});
%  text( sTime + 8,800,'(a)');
 text(0.08,1.1,'(b)','units','normalized');

 grid on 



 
subplot( 4, 1, 3)
file = [ fileOutput '4 DON\Sediment flux of DON _wholeWetland.csv'];
fid = fopen(file,'rt');
data = textscan(fid,'%s %f %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
sedDONmass.Date = dateTime;
sedDONmass.Data = data{1,2};

[sedDONmassnonStorm, sedDONmassStorm, sumsedDONmassperiod ]    =  ...
    sum_10min_six_period(sedDONmass,  period_10min );

pp =  plot(sedDONmass.Date  , sedDONmass.Data  );% g/d
hold on 
AddShade([0  0] , [150  150] , period );
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel','','TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);
ylabel({'Sediment flux ',' DON', '(g/d)'});
%  text( sTime + 8,800,'(a)');
 text(0.08,1.1,'(c)','units','normalized');
%  title([ currentFolder])
 grid on 
 
 
subplot( 4, 1, 4)
file = [ fileOutput '5 PON\PON sedimentation _wholeWetland.csv'];
fid = fopen(file,'rt');
data = textscan(fid,'%s %f %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
sedPONmass.Date = dateTime ;
sedPONmass.Data = data{1,2};

[sedPONmassnonStorm, sedPONmassStorm, sumsedPONmassperiod ]    =  ...
    sum_10min_six_period(sedPONmass,  period_10min );

pp = plot(sedPONmass.Date  , sedPONmass.Data *(-1)  ) % g/d
hold on 
AddShade([0  0] , [150  150] , period );
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel',timeLable,'TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);
ylabel({'Sedimentation ','PON', '(g/d)'});
%  text( sTime + 8,800,'(a)');
 text(0.08,1.1,'(d)','units','normalized');
%  title([ currentFolder])
 grid on 


 set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 29;
xLeft = 0;   yTop = 0;
set(gcf,'paperposition',[xLeft yTop xSize ySize])
saveas(gcf, [fileOutput 'Process_mass_NNN_sediment'],'png');


figure
subplot(3, 1, 1)
file = [ dicmodel currentFolder '\Output\'  '11. Residence time\Residence_Time_weir.csv'];
fid = fopen(file,'rt');
data = textscan(fid,'%s %f','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
ResTimeOutlet.Date = dateTime;
ResTimeOutlet.Data = data{1,2};
plot(ResTimeOutlet.Date  ,ResTimeOutlet.Data );
AddShade([0  0] , [10  10] , period );
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel','','TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
% set(pp, 'Color',[0 0 0]); % black
% box(gca,'on');
% clear ss
xlim([sTime  eTime]);
ylabel( 'Residence time (d)');
grid on
%  title([ currentFolder])
 text(0.08,1.1,'(a)','units','normalized');
 
subplot(3, 1, 2)
file = [ dicmodel currentFolder '\Output\'  '4. Oxygen\DO concentrationAverageDepthSheet.csv'];
fid = fopen(file,'rt');
data = textscan(fid,'%s %f','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
OxyAveSheet.Date = dateTime;
OxyAveSheet.Data = data{1,2};
plot(OxyAveSheet.Date  ,OxyAveSheet.Data );
AddShade([0  0] , [10  10] , period );
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel','','TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
% set(pp, 'Color',[0 0 0]); % black
% box(gca,'on');
% clear ss
xlim([sTime  eTime]);
ylabel( 'DO (mg/L)');
grid on
%  title([ currentFolder])
 text(0.08,1.1,'(b)','units','normalized');

subplot(3, 1, 3)
pp = plot(sedNO3mass.Date  , sedNO3mass.Data, 'b'   );% g/d
hold on 
pp = plot(sedNH4mass.Date  , sedNH4mass.Data ,'r'  );% g/d
hold on
pp =  plot(sedDONmass.Date  , sedDONmass.Data , 'g' );% g/d
hold on
% pp = plot(sedPONmass.Date  , sedPONmass.Data *(-1), 'k'  ) ;% g/d


AddShade([0  0] , [1000  1000] , period );
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel',timeLable,'TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);
ylabel( '(g/d)');
% leg1 = legend('NO_{3}', 'NH_{4}', 'DON', 'PON');
leg1 = legend('NO_{3}', 'NH_{4}', 'DON');
set(leg1,...
    'Position',[0.306927772126145 0.274812030075188 0.449135300101729 0.0582706766917293],...
    'Orientation','horizontal');
%  text( sTime + 8,800,'(a)');
%  text(0.08,1.1,'(d)','units','normalized');
 text(0.08,1.1,'(c)','units','normalized');
 grid on 

 set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 15; ySize = 12;
xLeft = 0;   yTop = 0;
set(gcf,'paperposition',[xLeft yTop xSize ySize])
% saveas(gcf, [fileOutput 'fig Process_mass_NNN_sediment_merge_resdenceTime_DO'],'png');
print(gcf,[fileOutput  'fig Process_mass_NNN_sediment_merge_resdenceTime_DO'],'-dpng','-r300');


% unit is g 
SedimentFlux_all (1, 2)  =  sedNO3massnonStorm  ; %NO3 in   during non storm period 
SedimentFlux_all(2, 2)  = sedNH4massnonStorm ; % NH4  in   during non storm period 
SedimentFlux_all(3, 2)  =  sedDONmassnonStorm ;  % DON  in   during non storm period 
SedimentFlux_all(4, 2)  =  sedPONmassnonStorm ;  %PON  in   during non storm period 

% unit is g 
SedimentFlux_all (1, 3)  =  sedNO3massStorm  ; %NO3 in   during storm period 
SedimentFlux_all(2, 3)  = sedNH4massStorm ; % NH4  in   during storm period 
SedimentFlux_all(3, 3)  =  sedDONmassStorm ;  % DON  in   during storm period 
SedimentFlux_all(4, 3)  =  sedPONmassStorm ;  %PON  in   during storm period 


SedimentFlux_all(1, 1)  =   SedimentFlux_all(1, 2) +  SedimentFlux_all(1, 3);    %NO3 in   during whole period 
SedimentFlux_all(2, 1)  =   SedimentFlux_all(2, 2) +  SedimentFlux_all(2, 3)     ;  %NH4  in   during whole period 
SedimentFlux_all(3, 1)  =   SedimentFlux_all(3, 2) +  SedimentFlux_all(3, 3)     ;  %DON  in   during whole period 
SedimentFlux_all(4, 1)  =  SedimentFlux_all(4, 2) +  SedimentFlux_all(4, 3)     ;   %PON  in   during whole period 

xlswrite([fileOutput 'flux_mass_tranport_sediment_process.xlsx'],SedimentFlux_all, 'sedimentFlux',   'B2:D5');