addpath('E:\Simulation_UWA_WD\2 For model variables\Function');
addpath('E:\Simulation_UWA_WD\2 For model variables\Supporting information');
BasicRead
file =  [dicmodel currentFolder '\Output\3 nitrogen\' ];
nitrogen_in_nonStorm = [
1.20E+04	5.64E+03	1.84E+04	5.00E+03	2.07E+03	2.08E+04	1.03E+03 ; ...% non_storm in 
3.42E+04	1.95E+04	4.86E+04	1.55E+04	1.32E+03	7.68E+03	2.70E+02];  % storm in
nitrogen_in_nonStorm_percent = [
0.1848	0.0869	0.2834	0.0770	0.0318	0.3203	0.0159 % nonstrom in 
0.2694	0.1533	0.3825	0.1219	0.0104	0.0604	0.0021];    % storm in

nitrogen_out_nonStorm = [
3419.37	     4367.51	     13856.67   	2828.00 % non storm out
29595.00	14616.71	46180.00	12429.28 % storm out
]; 

nitrogen_out_nonStorm_percent = [
0.140	0.178	0.566	0.116 %  non storm
0.288	0.142	0.449	0.121   % storm out
]; 

removal_nonStorm = [
   1.11E+03	2.25E+04	1.04E+04 %  non storm
4.02E+02	8.97E+03	3.86E+03   %  storm

 ];

removal_nonStorm_percent = [
0.033	0.661	0.307 %  non storm
0.030	0.678	0.292 %  storm
]; 

name = { 'Non-storm' 'Storm'  };

figure
subplot(3, 2, 1)
H = bar(nitrogen_in_nonStorm./1000, 'stacked') ;% convert g to kg
set(gca,'xticklabel',name);
ylabel('kg')
title('inflow and sediment flux of nitrogen')
AX=legend(H, {'Inflow of NO_{3}','Inflow of NH_{4}', 'Inflow of DON', 'Inflow of PON',  ...
    'Sediment flux of NO_{3}', 'Sediment flux of NH_{4}', 'Sedimetn flux of DON'}, 'Location','Best','FontSize',8);
xlim([0.5 2.5]);

subplot(3, 2, 2)
bar(nitrogen_in_nonStorm_percent, 'stacked')
set(gca,'xticklabel',name)
ylabel('%')
ylim([ 0 1 ])
xlim([0.5 2.5]);
%outflow
subplot(3, 2, 3)
H = bar(nitrogen_out_nonStorm./1000, 'stacked'); % convert g to kg
set(gca,'xticklabel',name)
ylabel('kg')
xlim([0.5 2.5]);

AX=legend(H, {'Outflow of NO_{3}', 'Outflow of NH_{4}', 'Outflow of DON', 'Outflow of PON'}, ...
    'Location','Best','FontSize',8);

subplot(3, 2, 4)
bar(nitrogen_out_nonStorm_percent, 'stacked')
set(gca,'xticklabel',name)
ylabel('%')
ylim([ 0 1 ]);
xlim([0.5 2.5]);
  %removal
subplot(3, 2, 5)
H= bar(removal_nonStorm./1000, 'stacked')% convert g to kg
set(gca,'xticklabel',name)
ylabel('kg');
xlim([0.5 2.5]);
AX=legend(H, {'Sedimentation of PON', 'Denitrification', 'Benthic net uptake'}, ...
    'Location','Best','FontSize',8);


subplot(3, 2, 6)
bar(removal_nonStorm_percent, 'stacked')
set(gca,'xticklabel',name)
ylabel('%')
ylim([ 0 1 ]);
xlim([0.5 2.5]);

 set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 18; ySize = 15;
xLeft = 0; yTop = 0;

set(gcf,'paperposition',[xLeft yTop xSize ySize])
% saveas(gcf, [file   'EffectFlowrateOnSOD'],'jpg');
% saveas(gcf, [file   'EffectFlowrateOnSOD'],'fig');

print(gcf,[ file 'Nitrogen_bar_chaos.tiff'],'-dtiff','-r300');
print(gcf,[file 'Nitrogen_bar_chaos.png'],'-dpng','-r300');



%----------------
figure1 = figure
ax1 = axes('position', [0.1 0.7 0.25 0.25  ]);
H = bar(nitrogen_in_nonStorm./1000, 'stacked') ;% convert g to kg
set(gca,'xticklabel',name);
ylabel('kg')
% text('inflow and sediment flux of nitrogen')
AX=legend(H, {'Inflow of NO_{3}','Inflow of NH_{4}', 'Inflow of DON', 'Inflow of PON',  ...
    'Sediment flux of NO_{3}', 'Sediment flux of NH_{4}', 'Sedimetn flux of DON'}, 'FontSize',8, ...
    'Position',[0.3850 0.755142857142857 0.235503560528993 0.278947368421052]);
xlim([0.5 2.5]);
text(0.01,1.05, '(a)','units','normalized');

ax2 = axes('position', [0.7 0.7 0.25 0.25  ]);
% yyaxis right
bar(nitrogen_in_nonStorm_percent, 'stacked')
set(gca,'xticklabel',name)
ylabel('%')
ylim([ 0 1 ])
xlim([0.5 2.5]);
text(0.01,1.05, '(b)','units','normalized');

%outflow
ax3 = axes('position', [0.1 0.4 0.25 0.25  ]);
H = bar(nitrogen_out_nonStorm./1000, 'stacked'); % convert g to kg
set(gca,'xticklabel',name)
ylabel('kg')
xlim([0.5 2.5]);

AX=legend(H, {'Outflow of NO_{3}', 'Outflow of NH_{4}', 'Outflow of DON', 'Outflow of PON'}, ...
  'FontSize',8, ...
    'Position',[0.40 0.55 0.192777212614446 0.159774436090225]);

% annotation(figure1,'textbox',...
%     [0.387571719226857 0.613533834586466 0.257392675483215 0.0556390977443608],...
%     'String',{'Outflow of nitrogen'},...
%     'FitBoxToText','off');
text(0.01,1.05, '(c)','units','normalized');

ax4 = axes('position', [0.7 0.4 0.25 0.25  ]);
% yyaxis right
bar(nitrogen_out_nonStorm_percent, 'stacked')
set(gca,'xticklabel',name)
ylabel('%')
ylim([ 0 1 ]);
xlim([0.5 2.5]);
text(0.01,1.05, '(d)','units','normalized');
  %removal
ax5 = axes('position', [0.1 0.1 0.25 0.25  ]);
H= bar(removal_nonStorm./1000, 'stacked')% convert g to kg
set(gca,'xticklabel',name)
ylabel('kg');
xlim([0.5 2.5]);
AX=legend(H, {'Sedimentation of PON', 'Denitrification', 'Benthic net uptake'}, ...
    'FontSize',8, ...
    'Position',[0.40 0.28 0.24059003051882 0.106015037593985]);
text(0.15,1.0, '52.4%','units','normalized');
text(0.65,0.5, '10.4%','units','normalized');
% annotation(figure1,'textbox',...
%     [0.406900305188199 0.314285714285714 0.204493387589013 0.0421052631578948],...
%     'String',{'Removal of nitrogen'},...
%     'FitBoxToText','off');
text(0.01,1.05, '(e)','units','normalized');

ax6 = axes('position', [0.7 0.1 0.25 0.25  ]);
% yyaxis right
bar(removal_nonStorm_percent, 'stacked')
set(gca,'xticklabel',name)
ylabel('%')
ylim([ 0 1 ]);
xlim([0.5 2.5]);
text(0.01,1.05, '(f)','units','normalized');

 set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 15; ySize = 25;
xLeft = 0; yTop = 0;

set(gcf,'paperposition',[xLeft yTop xSize ySize])
% saveas(gcf, [file   'EffectFlowrateOnSOD'],'jpg');
% saveas(gcf, [file   'EffectFlowrateOnSOD'],'fig');

print(gcf,[ file 'Nitrogen_bar.tiff'],'-dtiff','-r300');
print(gcf,[file 'Nitrogen_bar.png'],'-dpng','-r300');



outputs_nitrogen = [3419.37	4367.51	13856.67	2828.00	1.11E+03	2.25E+04	1.04E+04
29595.00	14616.71	46180.00	12429.28	4.02E+02	8.97E+03	3.86E+03];

figure1 = figure
ax1 = axes('position', [0.1 0.1 0.5 0.9  ]);
H1 = bar(nitrogen_in_nonStorm./1000, 'stacked') ;% convert g to kg
hold on
H2 = bar(outputs_nitrogen./1000 * (-1), 'stacked'); % convert g to kg

set(gca,'xticklabel',name);
ylabel('kg')
% text('inflow and sediment flux of nitrogen')
% AX=legend(H1, {'Inflow of NO_{3}','Inflow of NH_{4}', 'Inflow of DON', 'Inflow of PON',  ...
%     'Sediment flux of NO_{3}', 'Sediment flux of NH_{4}', 'Sedimetn flux of DON'}, 'FontSize',8, ...
%     'Position',[0.3850 0.755142857142857 0.235503560528993 0.278947368421052]);
% hold on 
label_1 = {'Inflow of NO_{3}','Inflow of NH_{4}', 'Inflow of DON', 'Inflow of PON',  ...
    'Sediment flux of NO_{3}', 'Sediment flux of NH_{4}', 'Sedimetn flux of DON'};
label_2 ={ 'Outflow of NO_{3}','Outflow of NH_{4}', 'Outflow of DON', 'Outflow of PON',  ...
    'Sedimentation of PON', 'Denitrification', 'Benthic net uptake'};
xlim([0.5 2.5]);
% AX=legend(H2, {'Outflow of NO_{3}','Outflow of NH_{4}', 'Outflow of DON', 'Outflow of PON',  ...
%     'Sedimentation of PON', 'Denitrification', 'Benthic net uptake'}, 'FontSize',8, ...
%     'Position',[0.0850 0.755142857142857 0.235503560528993 0.278947368421052]);
leg1 = legend([H1 H2],[label_1 label_2 ]);
set(leg1,...
    'Position',[ 0.628424759533329 0.23609022556391 0.260935910478128 0.60577839123943]);
 set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 15; ySize = 15;
xLeft = 0; yTop = 0;

set(gcf,'paperposition',[xLeft yTop xSize ySize])
% saveas(gcf, [file   'EffectFlowrateOnSOD'],'jpg');
% saveas(gcf, [file   'EffectFlowrateOnSOD'],'fig');
print(gcf,[file 'Nitrogen_bar_together.png'],'-dpng','-r300');