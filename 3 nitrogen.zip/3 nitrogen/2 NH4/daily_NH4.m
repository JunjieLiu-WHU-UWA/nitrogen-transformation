
% 
% addpath('E:\Simulation_UWA_WD\2 For model variables\Function');
% addpath('E:\Simulation_UWA_WD\2 For model variables\Supporting information');
% BasicRead
file =  [dicmodel currentFolder '\Output\3 nitrogen\' ];
figure
subplot(2,1,1);
fileSed = [ file '\2 NH4\Sediment flux of NH4 _wholeWetland.csv'];
fid = fopen(fileSed,'rt');
data = textscan(fid,'%s %f %f','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
SedFluxNH4.Date = dateTime ;
SedFluxNH4.Data = data{1,3};

SedFluxNH4Daily = dailySum(SedFluxNH4);
fileSedNH4DailyOut = [ file '\2 NH4\Sediment flux of NH4 _daily_rate_wholeWetland.csv'];
writeDaily(SedFluxNH4Daily,  fileSedNH4DailyOut  ,  'Sediment Flux NH4 Daily(g N /m2 /d)'  );
% divide them into two groups
[ SedFluxNH4DailynonStorm,  SedFluxNH4DailyStorm ]   = divide2period( SedFluxNH4Daily);


pp = plot(SedFluxNH4.Date, SedFluxNH4.Data);
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel','','TickLength',[0.005 0.015]);
set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);
ylabel({'Sediment', 'Flux',' (g N /m^{2} /d)'});
%  text( sTime + 8,800,'(a)');
 text(0.08,1.1,'(a)','units','normalized');
 grid on 
 %------------------------------
  subplot(2,1,2);
 fileNitri = [ file '\2 NH4\Nitrification of NH4 _wholeWetland.csv'];
 fid = fopen(fileNitri,'rt');
data = textscan(fid,'%s %f %f','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
NitriNH4.Date = dateTime ;
NitriNH4.Data = data{1,3};

NitriNH4Daily = dailySum(NitriNH4);
fileNitriNH4DailyOut = [ file '\2 NH4\Nitrification of NH4 _daily_rate_wholeWetland.csv'];
writeDaily(NitriNH4Daily,  fileNitriNH4DailyOut  ,  'Nitrification NH4 Daily(g N /m2 /d)'  );
[ NitriNH4DailynonStorm,  NitriNH4DailyStorm ]   = divide2period( NitriNH4Daily);


pp = plot(NitriNH4.Date, NitriNH4.Data);
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel','','TickLength',[0.005 0.015]);
set(pp, 'Color',[0 0 0]); % black
title([ 'scenario' currentFolder  ])
box(gca,'on');
clear ss
xlim([sTime  eTime]);
ylabel({'Nitrification', 'NH_{4}',' (g N /m^{2} /d)'});
%  text( sTime + 8,800,'(a)');
 text(0.08,1.1,'(b)','units','normalized');
 grid on 
  
 set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 20;
xLeft = 0;   yTop = 0;
set(gcf,'paperposition',[xLeft yTop xSize ySize])
saveas(gcf, [file '\2 NH4\NH4  sediment  nitrification rate'],'png');
 


Statis_NH4 = zeros(4, 4);
Statis_NH4(:,1) =  Varstatistical(SedFluxNH4DailynonStorm.Data ); % non storm inflow
Statis_NH4(:, 2)=  Varstatistical(SedFluxNH4DailyStorm.Data );

Statis_NH4(:,3) =  Varstatistical(NitriNH4DailynonStorm.Data ); 
Statis_NH4(:, 4)=  Varstatistical(NitriNH4DailyStorm.Data );






FlowIn = ['E:\Simulation_UWA_WD\' currentFolder  '\Output\2. Flow\FlowInDaily_wholeWetland.csv'];
fid = fopen(FlowIn,'rt');
data = textscan(fid,'%s %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'yyyy/mm/dd');
FlowIN.Date = dateTime;
FlowIN.Data = data{1,2}; % the unit is m3/s

[ FlowINnonStorm,  FlowINStorm ]   = divide2period( FlowIN);
color_nonStorm = [0 0 1];
color_Storm = [1 0 0];
 gcf = figure
h(1) = semilogx(FlowINnonStorm.Data  ,  NitriNH4DailynonStorm.Data, '*');
hold on
h(2) = semilogx( FlowINStorm.Data  ,  NitriNH4DailyStorm.Data, 'o');
hold on
title([ 'scenario'  currentFolder  ]);

PositionEq =  [0.221002596440751 0.783640134061756 0.351510460251046 0.122040072859745];
plotTrendLine(  FlowINnonStorm.Data ,  NitriNH4DailynonStorm.Data, 'poly1', ... 
color_nonStorm, PositionEq) ; 
PositionEq =   [0.504475399788031 0.72308967534616 0.351510460251046 0.122040072859745];
plotTrendLine(  FlowINStorm.Data ,  NitriNH4DailyStorm.Data, 'poly1', ... 
color_Storm, PositionEq) ; 


leg1 = legend(h(1:2), 'Non storm period','Storm event');
set(leg1,'Position',[0.161104650601206 0.151439775405978 0.392166836215666 0.03809218950064],...
    'Orientation','horizontal', ...
    'box', 'off');
ylabel({'Nitrification', 'NH_{4}',' (g N /m^{2} /d)'});
xlabel('Inflow rate (m^{3}/s)');
% set(pp, 'XScale','log');

 set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 10;
xLeft = 0; yTop = 0;

set(gcf,'paperposition',[xLeft yTop xSize ySize])
saveas(gcf, [file   '\2 NH4\RelationshipTwoPeriodNitrification_Flow'],'png');
saveas(gcf, [file   '\2 NH4\RelationshipTwoPeriodNitrification_Flow'],'fig');




