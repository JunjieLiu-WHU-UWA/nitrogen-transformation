%this script is to analyze the budget of oxygen
clc
% clearvars -except anvil 
close all
addpath('E:\Simulation_UWA_WD\2 For model variables\Function');
addpath('E:\Simulation_UWA_WD\2 For model variables\Supporting information');
BasicRead
file =  [dicmodel currentFolder '\Output\3 nitrogen\' ];

% source_NH4 = zeros( 6 ,1   );
labels = {'Influent','Outfluent','sediment flux', ...
                 'nitrification', 'mineralisation from DON'}';
             
num_fig = 7;
gcf_com = figure
% the layout of all the fiugre accoring to sourcre and sink of NH4.
% first source, then sink.
% Transport in
fileTran = [file '2 NH4\NH4 transport_in.csv' ];
fid = fopen(fileTran,'rt');
data = textscan(fid,'%s %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
transIn_NH4.Date = dateTime;
transIn_NH4.Data = data{1,2}; % the unit is g/d
source_NH4(1,1) = trapz(transIn_NH4.Date, transIn_NH4.Data  );

[ transIn_NH4nonStorm,  transIn_NH4Storm, sumtransIn_NH4period ]    = sum_10min_six_period( transIn_NH4,  period_10min );
subplot(num_fig,1,1)
pp = plot(transIn_NH4.Date, transIn_NH4.Data./1000); % the unit is kg/d
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel','','TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);
ylim([0 6 ]);
AddShade([0  0] , [6 6] , period );
ylabel({'NH_{4}',' Input', '(kg/d)'});
%  text( sTime + 8,800,'(a)');
 text(0.08,1.1,'(a)','units','normalized');
 title(['Scenario   '  currentFolder])
 grid on 


% sedment flux of NH4
 fileAtm = [ file '2 NH4\Sediment flux of NH4 _wholeWetland.csv'];
 fid = fopen(fileAtm,'rt');
data = textscan(fid,'%s %f %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
SedNH4.Date = dateTime ;
SedNH4.Data = data{1,2};% the unit is g/d
source_NH4(2,1) = trapz(SedNH4.Date, SedNH4.Data  );

[ SedNH4nonStorm,  SedNH4Storm, sumSedNH4period ]    = sum_10min_six_period(SedNH4,  period_10min );
subplot(num_fig,1,2)
pp = plot( SedNH4.Date , SedNH4.Data);

set(gca,'XTick',[ datenum(timeTick )],'XTickLabel','','TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);
% ylim([0 1000 ]);
AddShade([0  0] , [200 200] , period );
ylabel({'Sediment flux','NH_{4}', '(g/d)'});
%  text( sTime + 8,800,'(a)');
 text(0.08,1.1,'(c)','units','normalized');
%  title(['Scenario   '  currentFolder])
 grid on 
 
 % mineralisation of DON to NH4
fileSed = [ file '4 DON\Mineralisation of DON _wholeWetland.csv'];
fid = fopen(fileSed,'rt');
data = textscan(fid,'%s %f %f','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
mineraDON.Date = dateTime;
mineraDON.Data = data{1,2};% the unit is g/d
source_NH4(3,1) = trapz(mineraDON.Date, mineraDON.Data  );

[ mineraDONnonStorm,  mineraDONStorm, summineraDONperiod ]    = sum_10min_six_period(mineraDON,  period_10min );
  subplot(num_fig,1,3)
pp = plot(mineraDON.Date, mineraDON.Data  );% the unit is kg/d
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel','','TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);

AddShade([0  0] , [100 100] , period );
ylabel({'Mineraliation','DON', '(g/d)'});
 text(0.08,1.1,'(b)','units','normalized');
 grid on 






 % -----------------sink ------------------------
% transport out
fileTran = [ file '2 NH4\NH4 transport_out.csv'];
fid = fopen(fileTran,'rt');
data = textscan(fid,'%s %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
transOut_NH4.Date = dateTime;
transOut_NH4.Data = data{1,2}; % the unit is g/d
sink_NH4(1,1) = trapz(transOut_NH4.Date, transOut_NH4.Data  );% the unit is kg/d

[ transOut_NH4nonStorm,  transOut_NH4Storm, sumtransOut_NH4period ]    = sum_10min_six_period(transOut_NH4,  period_10min );


subplot(num_fig,1,4)
pp = plot(transOut_NH4.Date, transOut_NH4.Data./1000   );% the unit is kg/d
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel','','TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);

AddShade([0  0] , [15 15] , period );
ylabel({'NH_{4}',' Output', '(kg/d)'});
 text(0.08,1.1,'(b)','units','normalized');
 grid on 

 % nitrification of NH4
 fileAtm = [ file '2 NH4\Nitrification of NH4 _wholeWetland.csv'];
 fid = fopen(fileAtm,'rt');
data = textscan(fid,'%s %f %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
NitriNH4.Date = dateTime ;
NitriNH4.Data = data{1,2};% the unit is g/d
sink_NH4(2,1) = trapz(NitriNH4.Date, NitriNH4.Data  );

[ NitriNH4nonStorm,  NitriNH4Storm, sumNitriNH4period ]    = sum_10min_six_period(NitriNH4,  period_10min );


subplot(num_fig,1,5)
pp = plot( NitriNH4.Date , NitriNH4.Data);
 
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel',timeLable,'TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);
% ylim([0 1000 ]);
AddShade([0  0] , [400 400] , period );
ylabel({'NH_{4}',' Nitrification', '(g/d)'});
%  text( sTime + 8,800,'(a)');
 text(0.08,1.1,'(d)','units','normalized');
%  title(['Scenario   '  currentFolder])
 grid on 

 % plant uptake of NH4
 
 fileuptake = [ file '2 NH4\NH4 uptake by phytoplankton _wholeWetland.csv'];
 fid = fopen(fileuptake,'rt');
data = textscan(fid,'%s %f %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
PHY_NH4.Date = dateTime ;
PHY_NH4.Data = data{1,2};% the unit is g/d
sink_NH4(3,1) = trapz(PHY_NH4.Date, PHY_NH4.Data  );
[ PHY_NH4nonStorm,  PHY_NH4Storm, sumPHY_NH4period ]    = sum_10min_six_period(PHY_NH4,  period_10min );


subplot(num_fig,1,6)
pp = plot( PHY_NH4.Date , PHY_NH4.Data);
 
 set(gca,'XTick',[ datenum(timeTick )],'XTickLabel',timeLable,'TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);
% ylim([0 1000 ]);
AddShade([0  0] , [60 60] , period );
ylabel({'NH_{4}uptake by','  pelagic phyto', '(g/d)'});
%  text( sTime + 8,800,'(a)');
 text(0.08,1.1,'(e)','units','normalized');
%  title(['Scenario   '  currentFolder])
 grid on 

% benthic uptake of NH4
fileNH4 = [ file '3 NO3\Benthic  nitrogen uptake_wholeWetland.csv'];
 fid = fopen(fileNH4,'rt');
data = textscan(fid,'%s %f %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
BCP_uptake_NH4.Date = dateTime ;
BCP_uptake_NH4.Data = data{1,2} * 0.5 ;% the unit is g/d. the ratio between NO3 and NH4 is 1:1
sink_NH4(4,1) = trapz(BCP_uptake_NH4.Date, BCP_uptake_NH4.Data  );
  [BCP_uptake_NH4nonStorm,  BCP_uptake_NH4Storm, sumBCP_uptake_NH4period ]    = sum_10min_six_period(BCP_uptake_NH4,  period_10min );

 
subplot(num_fig,1,7)
pp = plot( BCP_uptake_NH4.Date , BCP_uptake_NH4.Data);
AddShade([0  0] , [30 30] , period );
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel',timeLable,'TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);
% ylim([0 1000 ]);
AddShade([-2000  -2000] , [4000 4000] , period );
ylabel({'Benthic uptake', 'NH_{4}', '(g/d)'});
%  text( sTime + 8,800,'(a)');
 text(0.08,1.1,'(g)','units','normalized');
%  title(['Scenario   '  currentFolder])
 grid on 
  
 set(gcf_com, 'PaperPositionMode', 'manual');
set(gcf_com, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 29;
xLeft = 0;   yTop = 0;
set(gcf_com,'paperposition',[xLeft yTop xSize ySize])
saveas(gcf_com, [file '\2 NH4\NH4 budget mass'],'png');


%  pie figure
gcf_pie = figure
f.Renderer = 'painters';
fig_p = subplot(2,1,1)
p= pie(source_NH4);
colormap(fig_p, [ 0.5 0.5 0.5;      %grey
         1 0 0  ; % red   
          0 1 1 ])  %cyan
pText = findobj(p,'Type','text');
%  title([' NH4  '  currentFolder])
p(2).Position = [ 0.4  0.5 0 ] .*p(2).Position;
p(4).Position =  [0.6 0.5 0  ].*p(4).Position;
%  p(6).Position =  [0.8 0.6 0  ].*p(6).Position;
% leg1 = legend('Influent','Sediment flux', ...
%                  'mineralisation' );
%  set(leg1,  'Location','eastoutside');
% figure
fig_p= subplot(2,1,2)
p = pie2(sink_NH4);
colormap(fig_p , [ 0.5  0.5  0.5;      %grey
       0, 0.4470, 0.7410  ; % blue      
          0 1 0;  % green     
          1 1 0]) % yellow
pText = findobj(p,'Type','text');
p(2).Position = [ 0.25  0.5 0 ] .*p(2).Position;
p(4).Position =  [0.3 0.5 0  ].*p(4).Position;
%  p(6).Position =  [0.8 0.6 0  ].*p(6).Position;
p(8).Position =  [0.3 1.1 0  ].*p(8).Position;
%  title(['Scenario   '  currentFolder])
% leg1 = legend('Outfluent',   'Nitrification', 'Pelagic uptake' , 'Benthic uptake');
% set(leg1, 'Location','eastoutside');

set(gcf_pie, 'PaperPositionMode', 'manual');
set(gcf_pie, 'PaperUnits', 'centimeters');
xSize = 8; ySize = 8;
xLeft = 0;   yTop = 0;
set(gcf_pie,'paperposition',[xLeft yTop xSize ySize])
% saveas(gcf_pie, [file '\2 NH4\Pie NH4 budget percent'],'png');
print(gcf,[file '\2 NH4\Pie NH4 budget percent_wholePeriod.png'],'-dpng','-r300');
%----------------------

% 
%------------------------------- non storm period----  in 
NH4_in_nonStorm(1,1)  =  transIn_NH4nonStorm;
NH4_in_nonStorm(2,1)  = SedNH4nonStorm;
NH4_in_nonStorm(3,1)  = mineraDONnonStorm;


% out
NH4_out_nonStorm(1,1)  =  transOut_NH4nonStorm;
NH4_out_nonStorm(2,1)  = NitriNH4nonStorm;
NH4_out_nonStorm(3,1)  =  PHY_NH4nonStorm;
NH4_out_nonStorm(4,1)  =  BCP_uptake_NH4nonStorm ;
% ------------------storm period
% in
NH4_in_Storm(1,1)  =  transIn_NH4Storm;
NH4_in_Storm(2,1)  = SedNH4Storm;
NH4_in_Storm(3,1)  = mineraDONStorm;

% out
NH4_out_Storm(1,1)  =  transOut_NH4Storm;
NH4_out_Storm(2,1)  =   NitriNH4Storm;
NH4_out_Storm(3,1)  =  PHY_NH4Storm;
NH4_out_Storm(4,1)  =  BCP_uptake_NH4Storm;
gcf_nonstorm = figure
fig_p = subplot(2,1,1)
p = pie(NH4_in_nonStorm);
colormap(fig_p, [ 0.5 0.5 0.5;      %grey
         1 0 0  ; % red   
          0 1 1 ]) ; %cyan
      p(2).Position = [ 0.5  0.5 0 ] .*p(2).Position;
p(4).Position =  [0.5 0.6 0  ].*p(4).Position;
 p(6).Position =  [0.5 1.0 0  ].*p(6).Position;
pText = findobj(p,'Type','text');

% leg1 = legend('Influent','Sediment flux', ...
%                  'mineralisation' );
%  set(leg1,...
%     'Location','eastoutside');
% title([currentFolder '     ' 'NH4 budget non storm period' ] );
fig_p  = subplot(2,1,2)
p = pie(NH4_out_nonStorm);
pText = findobj(p,'Type','text');

colormap(fig_p , [ 0.5  0.5  0.5;      %grey
       0, 0.4470, 0.7410  ; % blue      
          0 1 0;  % green     
          1 1 0]) % yellow

p(2).Position = [ 0.4  0.6 0 ] .*p(2).Position;
p(4).Position =  [0.3 0.4 0  ].*p(4).Position;
%  p(6).Position =  [0.8 0.6 0  ].*p(6).Position;
 p(8).Position =  [0.5 1.0 0  ].*p(8).Position;
% leg1 = legend('Outfluent',   'Nitrification', 'Pelagic uptake ' , 'Benthic uptake');
%  set(leg1,...
%     'Location','eastoutside');
% title([currentFolder ] );
set(gcf_nonstorm, 'PaperPositionMode', 'manual');
set(gcf_nonstorm, 'PaperUnits', 'centimeters');
xSize = 8; ySize = 8;
xLeft = 0;   yTop = 0;
set(gcf_nonstorm,'paperposition',[xLeft yTop xSize ySize])
% saveas(gcf_nonstorm, [file '2 NH4\Pie NH4 nonStorm in out budget percent'],'png');
print(gcf,[file '2 NH4\Pie NH4 nonStorm in out budget percent.png'],'-dpng','-r300');

gcf_storm = figure
fig_p = subplot(2,1,1)
p = pie2(NH4_in_Storm);
colormap(fig_p, [ 0.5 0.5 0.5;      %grey
         1 0 0  ; % red   
          0 1 1 ]) ; %cyan
      p(2).Position = [ 0.3  0.5 0 ] .*p(2).Position;
p(4).Position =  [0.3 0.5 0  ].*p(4).Position;
%  p(6).Position =  [0.5 0.5 0  ].*p(6).Position;



pText = findobj(p,'Type','text');
% leg1 = legend('Inflow','Sediment flux', ...
%                  'Mineralisation' );
%  set(leg1,...
%     'Location','eastoutside',  'box', 'off', 'FontSize', 6);
% title([currentFolder '  ' ' NH4 budget Storm event' ] );
% figure
fig_p = subplot(2,1,2)

p = pie2(NH4_out_Storm);

colormap(fig_p , [ 0.5  0.5  0.5;      %grey
       0, 0.4470, 0.7410  ; % blue      
          0 1 0;  % green     
          1 1 0]) % yellow

p(2).Position = [ 0.3  0.5 0 ] .*p(2).Position;
p(4).Position =  [0.3 0.5 0  ].*p(4).Position;
%  p(6).Position =  [0.8 0.6 0  ].*p(6).Position;
     p(8).Position = [ 0.2  1.2 0 ] .*p(8 ).Position;
pText = findobj(p,'Type','text');

% leg1 = legend('Outflow',   'Nitrification', 'Pelagic net uptake ' , 'Benthic net uptake');
%  set(leg1,...
%     'Location','eastoutside',  'box', 'off', 'FontSize', 6);

% title([currentFolder ] );
set(gcf_storm, 'PaperPositionMode', 'manual');
set(gcf_storm, 'PaperUnits', 'centimeters');
xSize = 8; ySize = 8;
xLeft = 0;   yTop = 0;
set(gcf_storm,'paperposition',[xLeft yTop xSize ySize])
% saveas(gcf_storm, [file '2 NH4\Pie NH4 Storm in out budget percent'],'png');
print(gcf,[file '2 NH4\Pie NH4 Storm in out budget percent.png'],'-dpng','-r300');

%%for legend
gcf_storm = figure
fig_p = subplot(2,1,1)
p = pie2(NH4_in_Storm);
colormap(fig_p, [ 0.5 0.5 0.5;      %grey
         1 0 0  ; % red   
          0 1 1 ]) ; %cyan
      p(2).Position = [ 0.3  0.5 0 ] .*p(2).Position;
p(4).Position =  [0.3 0.5 0  ].*p(4).Position;
%  p(6).Position =  [0.5 0.5 0  ].*p(6).Position;



pText = findobj(p,'Type','text');
leg1 = legend('Inflow','Sediment flux', ...
                 'Mineralization' );
 set(leg1,...
    'Location','eastoutside',  'box', 'off', 'FontSize', 6);
% title([currentFolder '  ' ' NH4 budget Storm event' ] );
% figure
fig_p = subplot(2,1,2)

p = pie2(NH4_out_Storm);

colormap(fig_p , [ 0.5  0.5  0.5;      %grey
       0, 0.4470, 0.7410  ; % blue      
          0 1 0;  % green     
          1 1 0]) % yellow

p(2).Position = [ 0.3  0.5 0 ] .*p(2).Position;
p(4).Position =  [0.3 0.5 0  ].*p(4).Position;
%  p(6).Position =  [0.8 0.6 0  ].*p(6).Position;
     p(8).Position = [ 0.2  1.2 0 ] .*p(8 ).Position;
pText = findobj(p,'Type','text');

leg1 = legend('Outflow',   'Nitrification', 'Pelagic uptake ' , 'Benthic net uptake');
 set(leg1,...
    'Location','eastoutside',  'box', 'off', 'FontSize', 6);

% title([currentFolder ] );
set(gcf_storm, 'PaperPositionMode', 'manual');
set(gcf_storm, 'PaperUnits', 'centimeters');
xSize = 8; ySize = 8;
xLeft = 0;   yTop = 0;
set(gcf_storm,'paperposition',[xLeft yTop xSize ySize])
% saveas(gcf_storm, [file '2 NH4\Pie NH4 Storm in out budget percent'],'png');
print(gcf,[file '2 NH4\Pie NH4 Storm in out budget percent_legend.png'],'-dpng','-r300');


% 
% percentValues = get(pText,'String'); 
% txt = {'Influent : ','Outfluent :','Atmospheric flux :', ...
%                 'SOD :', 'PGPP :', 'NEP :' }'; 
% combinedtxt = strcat(txt,percentValues);
% 
% pText(1).String = combinedtxt(1);
% pText(2).String = combinedtxt(2);
% pText(3).String = combinedtxt(3);
% pText(4).String = combinedtxt(4);
% pText(5).String = combinedtxt(5);
% pText(6).String = combinedtxt(6);


% 
% figure
% p = pie(source_NH4);
% pText = findobj(p,'Type','text');
%  title(['Scenario   '  currentFolder])
% leg1 = legend('Influent','Outfluent','Sediment flux', ...
%                 'Nitrification', 'mineralisation' );
%  set(leg1,...
%     'Location','eastoutside');
% 
% set(gcf, 'PaperPositionMode', 'manual');
% set(gcf, 'PaperUnits', 'centimeters');
% xSize = 10; ySize = 10;
% xLeft = 0;   yTop = 0;
% set(gcf,'paperposition',[xLeft yTop xSize ySize])
% saveas(gcf, [file '\2 NH4\Pie NH4 budget percent'],'png');
