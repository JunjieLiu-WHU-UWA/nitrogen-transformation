
% load('D:\Research in UWA\overview of data available in anvil\all_togehter_plotting\anvil.mat');
addpath('E:\Simulation_UWA_WD\2 For model variables\Function');
addpath('E:\Simulation_UWA_WD\2 For model variables\Supporting information');
BasicRead
currentOutput = '3 nitrogen\2 NH4\'; 
fileOutput =  [dicmodel currentFolder '\Output\' currentOutput ];
if ~exist(fileOutput,'dir')      % check  whether the outdir  exists in the file of 'dir';
    mkdir(fileOutput);           % if not exists, create the file of 'outdir'
end

varid = netcdf.inqVarID(ncid,'WQ_DIAG_NIT_SED_AMM');
NIT_SED_AMM = netcdf.getVar(ncid,varid) /1000*14  ;  %mmol/m2/d to g/m2/d; 

fileBasicmat = [dicmodel currentFolder '\Output\Basic.mat'];
load(fileBasicmat);

[SDF_FSED_AMM_SumSpace, SDF_FSED_AMM_CVMean ] =  bottomLayer( NIT_SED_AMM, Basic, Cell_whole_channel);

%the unit of SDF_FSED_AMM_SumSpace is g N /d,
% the unit of SDF_FSED_AMM_CVMean is g N/m2/d

figure
subplot(2,1,1)
plot(ResTime, SDF_FSED_AMM_SumSpace)

set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([  currentFolder   '    ' 'Sediment flux of NH_{4} across the wetland ']);
xlim([sTime  eTime]);
ylabel({ ' (g N /d)'}) 
xlabel('Date (2015)');
grid on 


hold on

subplot(2,1,2)
plot(ResTime, SDF_FSED_AMM_CVMean)

 set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([  currentFolder   '    ' 'rate of Sediment flux of NH_{4} across the wetland ']);
xlim([sTime  eTime]);
ylabel({ ' (g N /m2  /d)'}) 
xlabel('Date (2015)');
grid on 


set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 15;
xLeft = 0;  yTop = 0;

set(gcf,'paperposition',[xLeft yTop xSize ySize])

saveas(gcf,[fileOutput  'Sediment flux of NH4 across wetland'],'png');
saveas(gcf,[fileOutput  'Sediment flux of NH4 across  wetland'],'fig');


 filecsv=  [ fileOutput  'Sediment flux of NH4 _wholeWetland.csv' ];
 fid = fopen(filecsv,'wt');
fprintf(fid,'ISOTime, SDF_FSED_AMM_SumSpace (g N/d),SDF_FSED_AMM_CVMean (g N/m2/d) \n');
for i = 1:length(ResTime)
    fprintf(fid,'%s,',datestr(ResTime(i),'dd/mm/yyyy HH:MM:SS'));
    fprintf(fid,'%4.8f,%4.8f \n', SDF_FSED_AMM_SumSpace(1,i) ,SDF_FSED_AMM_CVMean(1,i));
                       
end
fclose(fid);