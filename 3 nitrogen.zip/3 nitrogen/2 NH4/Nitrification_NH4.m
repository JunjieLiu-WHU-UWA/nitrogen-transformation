


% load('D:\Research in UWA\overview of data available in anvil\all_togehter_plotting\anvil.mat');
% addpath('E:\Simulation_UWA_WD\2 For model variables\Function');
% addpath('E:\Simulation_UWA_WD\2 For model variables\Supporting information');
% BasicRead
currentOutput = '3 nitrogen\2 NH4\'; 
fileOutput =  [dicmodel currentFolder '\Output\' currentOutput ];
if ~exist(fileOutput,'dir')      % check  whether the outdir  exists in the file of 'dir';
    mkdir(fileOutput);           % if not exists, create the file of 'outdir'
end

varid = netcdf.inqVarID(ncid,'WQ_DIAG_NIT_NITRIF');
NIT_NITRIF = netcdf.getVar(ncid,varid) /1000*14  ;  %mmol/m3/d to g/m3/d; 

fileBasicmat = [dicmodel currentFolder '\Output\Basic.mat'];
load(fileBasicmat);

[ NIT_NITRIFSumSpace ,NIT_NITRIFCVMean ]  = ThreeVolume2twoarea(NIT_NITRIF, Basic, Cell_whole_channel);

%the unit of first variable  is g N /d,
% the unit of second variable is g N/m2/d.

figure
subplot(2,1,1)
plot(ResTime, NIT_NITRIFSumSpace)

set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([  currentFolder   '    ' 'Nitrification of NH_{4} across the wetland ']);
xlim([sTime  eTime]);
ylabel({ ' (g N /d)'}) 
xlabel('Date (2015)');
grid on 


hold on

subplot(2,1,2)
plot(ResTime, NIT_NITRIFCVMean)

 set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([  currentFolder   '    ' 'Nitrification of NH_{4} across the wetland ']);
xlim([sTime  eTime]);
ylabel({ ' (g N /m2  /d)'}) 
xlabel('Date (2015)');
grid on 


set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 15;
xLeft = 0;  yTop = 0;
set(gcf,'paperposition',[xLeft yTop xSize ySize])
saveas(gcf,[fileOutput  'Nitrification of NH4 across wetland'],'png');
saveas(gcf,[fileOutput  'Nitrification of NH4 across  wetland'],'fig');


 filecsv=  [ fileOutput  'Nitrification of NH4 _wholeWetland.csv' ];
 fid = fopen(filecsv,'wt');
fprintf(fid,'ISOTime, NIT_NITRIFSumSpace (g N/d),NIT_NITRIFCVMean (g N/m2/d) \n');
for i = 1:length(ResTime)
    fprintf(fid,'%s,',datestr(ResTime(i),'dd/mm/yyyy HH:MM:SS'));
    fprintf(fid,'%4.8f,%4.8f \n', NIT_NITRIFSumSpace(1,i) ,NIT_NITRIFCVMean(1,i));
                       
end
fclose(fid);
 