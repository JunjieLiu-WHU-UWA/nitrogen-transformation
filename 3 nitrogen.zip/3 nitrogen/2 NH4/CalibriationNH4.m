


% load('D:\Research in UWA\overview of data available in anvil\all_togehter_plotting\anvil.mat');
addpath('E:\Simulation_UWA_WD\2 For model variables\Function');
addpath('E:\Simulation_UWA_WD\2 For model variables\Supporting information');
BasicRead
currentOutput = '3 nitrogen\2 NH4\'; 
fileOutput =  [dicmodel currentFolder '\Output\' currentOutput ];
if ~exist(fileOutput,'dir')      % check  whether the outdir  exists in the file of 'dir';
    mkdir(fileOutput);           % if not exists, create the file of 'outdir'
end

varid = netcdf.inqVarID(ncid,'WQ_NIT_AMM');
NIT_AMM = netcdf.getVar(ncid,varid) /1000*14  ;  %mmol/m3/d to g/m3/d; 
weirNIT_AMM_mean.Date = ResTime;
weirNIT_AMM_mean.Data = mean(NIT_AMM(idx2weirCell,: ));

file_inflow =  [ dicmodel currentFolder   '\BCs\'   BC_inflow ];
fid = fopen(file_inflow ,'rt');
str = repmat('%f ', [1 24] );
data_inlet = textscan(fid,['%s' str],'Headerlines',1,'Delimiter',',');
ISOTime_in = datenum(data_inlet{1,1},'dd/mm/yyyy HH:MM:SS');
inletNIT_AMM.Date  = ISOTime_in;
inletNIT_AMM.Data  = data_inlet{1,9}  *N_mmol_g   ;  %  the unit is  mmol /m3  to mg/L





% 
% inletNIT_AMM = NIT_AMM(idx2InletCell,: );
% figure
%  te = NIT_AMM(80,: );
%  plot(ResTime,te  )

figure
plot(weirNIT_AMM_mean.Date,weirNIT_AMM_mean.Data  )
hold on
AMM_UWA_04 =  anvil.SWQ.MSANVCBOUT.HRD.Storm_04.FNH3;
ss = find(sTime <= AMM_UWA_04.Date & AMM_UWA_04.Date <= eTime);
plot(AMM_UWA_04.Date(ss,1),AMM_UWA_04.Data(ss,1),'bs'); clear ss
hold on 

AMM_UWA_05 =  anvil.SWQ.MSANVCBOUT.HRD.Storm_05.FNH3;
ss = find(sTime <= AMM_UWA_05.Date & AMM_UWA_05.Date <= eTime);
plot(AMM_UWA_05.Date(ss,1),AMM_UWA_05.Data(ss,1),'rs'); clear ss
hold on 

leg1 = legend( 'modelled NH_{4}', 'Storm 04' , 'Storm 05');
set(leg1,'Location','best');
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([  currentFolder ' NH_{4} at outlet  ']);
xlim([sTime  eTime]);
ylabel('mg/L'); 
xlabel('Date (2015)');
grid on 

saveas(gcf,[fileOutput  'NH4 modellde and observed at outlet'],'png');
saveas(gcf,[fileOutput  'NH4 modellde and observed at outlet'],'fig');
%---------------------------------

filecsv =  [ fileOutput 'NH4_weir_10min.csv' ];
fid = fopen(filecsv,'wt');
fprintf(fid,'ISOTime, NH4 concentration (mg/L) \n');
for i = 1:length(weirNIT_AMM_mean.Date)
    fprintf(fid,'%s,',datestr(weirNIT_AMM_mean.Date(i),'dd/mm/yyyy HH:MM:SS'));
    fprintf(fid,'%4.4f \n',  weirNIT_AMM_mean.Data(1,i)  );
end
fclose(fid);

% filecsv =  [ fileOutput 'NH4_inlet.csv' ];
% fid = fopen(filecsv,'wt');
% fprintf(fid,'ISOTime, NH4 concentration (mg/L) \n');
% for i = 1:length(ResTime)
%     fprintf(fid,'%s,',datestr(ResTime(i),'dd/mm/yyyy HH:MM:SS'));
%     fprintf(fid,'%4.4f \n',  inletNIT_AMM(1,i)  );
% end
% fclose(fid);



% comparison NH4 at inlet and outlet


figure
h(1) = plot(inletNIT_AMM.Date,  inletNIT_AMM.Data );
hold on

AMM_UWA_04 =  anvil.SWQ.MSANVCBIN.HRD.Storm_04.FNH3;
ss = find(sTime <= AMM_UWA_04.Date & AMM_UWA_04.Date <= eTime);
h(2) = plot(AMM_UWA_04.Date(ss,1),AMM_UWA_04.Data(ss,1),'b*'); clear ss
hold on 

AMM_UWA_05 =  anvil.SWQ.MSANVCBIN.HRD.Storm_05.FNH3;
ss = find(sTime <= AMM_UWA_05.Date & AMM_UWA_05.Date <= eTime);
h(3) = plot(AMM_UWA_05.Date(ss,1),AMM_UWA_05.Data(ss,1),'b*'); clear ss
hold on 
%%%%%%%% outlet
h(4) = plot(weirNIT_AMM_mean.Date,weirNIT_AMM_mean.Data  );
hold on
AMM_UWA_04 =  anvil.SWQ.MSANVCBOUT.HRD.Storm_04.FNH3;
ss = find(sTime <= AMM_UWA_04.Date & AMM_UWA_04.Date <= eTime);
h(5) = plot(AMM_UWA_04.Date(ss,1),AMM_UWA_04.Data(ss,1),'rs'); clear ss
hold on 

AMM_UWA_05 =  anvil.SWQ.MSANVCBOUT.HRD.Storm_05.FNH3;
ss = find(sTime <= AMM_UWA_05.Date & AMM_UWA_05.Date <= eTime);
h(6) = plot(AMM_UWA_05.Date(ss,1),AMM_UWA_05.Data(ss,1),'rs'); clear ss
hold on 
AddShade([0  0] , [0.5 0.5] , period );
leg1 = legend(h([1 2 4 5]),  'Inlet ', '', 'Outlet', '');
set(leg1,'Location','best');
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([  currentFolder ' NH_{4} at inlet and outlet  ']);
xlim([sTime  eTime]);
ylabel('mg/L'); 
xlabel('Date (2015)');
grid on 

set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 10;
xLeft = 0;   yTop = 0;
set(gcf,'paperposition',[xLeft yTop xSize ySize])
saveas(gcf, [fileOutput  'NH4 at outlet and inlet '],'png');
