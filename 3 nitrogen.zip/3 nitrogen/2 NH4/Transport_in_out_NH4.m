% load('D:\Research in UWA\overview of data available in anvil\all_togehter_plotting\anvil.mat');
% addpath('E:\Simulation_UWA_WD\2 For model variables\Function');
% addpath('E:\Simulation_UWA_WD\2 For model variables\Supporting information');
% BasicRead
currentOutput = '3 nitrogen\2 NH4\'; 
fileOutput =  [dicmodel currentFolder '\Output\' currentOutput ];
if ~exist(fileOutput,'dir')      % check  whether the outdir  exists in the file of 'dir';
    mkdir(fileOutput);           % if not exists, create the file of 'outdir'
end

var = 'NH4';

file_inflow =  [ dicmodel currentFolder   '\BCs\'   BC_inflow ];
fid = fopen(file_inflow ,'rt');
str = repmat('%f ', [1 24] );
data_inlet = textscan(fid,['%s' str],'Headerlines',1,'Delimiter',',');
ISOTime_in = datenum(data_inlet{1,1},'dd/mm/yyyy HH:MM:SS');
Inflow.Date = ISOTime_in;
Inflow.Data = data_inlet{1,2};

InflowNH4.Date  = ISOTime_in;
InflowNH4.Data  = data_inlet{1,9} ;  %  the unit is  mmol /m3

transInflowNit = calculationFlux(Inflow.Date,   Inflow.Data, InflowNH4.Data); % mmol/s

file_inflow =  [ dicmodel currentFolder   '\BCs\'    BC_Mars ];
fid = fopen(file_inflow ,'rt');
str = repmat('%f ', [1 24] );
data_inlet = textscan(fid,['%s' str],'Headerlines',1,'Delimiter',',');
ISOTime_in = datenum(data_inlet{1,1},'dd/mm/yyyy HH:MM:SS');
Mars.Date = ISOTime_in;
Mars.Data = data_inlet{1,2};

MarsNH4.Date  = ISOTime_in;
MarsNH4.Data  = data_inlet{1,9} ;  %  the unit is  mmol /m3
transMarNit = calculationFlux(Mars.Date,   Mars.Data, MarsNH4.Data) ;  % mmol/s
NH4_IN.Date = MarsNH4.Date;
NH4_IN.Data   = transInflowNit.Data + transMarNit.Data;    % mmol/s
NH4_IN.Data = NH4_IN.Data  *N_mmol_g   * day_second  ; % the unit is g/d

file_outflow =  [ dicmodel currentFolder   '\Output\'  '2. Flow\Outflow_weir_10min.csv'];
fid = fopen(file_outflow ,'rt');
data_outlet = textscan(fid,'%s %f %f ', 'Headerlines',1,'Delimiter',',');
ISOTime_out = datenum(data_outlet{1,1},'dd/mm/yyyy HH:MM:SS');
Outflow.Date = ISOTime_out;
Outflow.Data = data_outlet{1,2};%  m3/s

fileweir = [  dicmodel currentFolder  '\Output\3 nitrogen\2 NH4\'  'NH4_weir_10min.csv'];
 fid = fopen(fileweir,'rt');
data = textscan(fid,'%s %f','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
Weir_NH4_10min.Date = dateTime ;
Weir_NH4_10min.Data = data{1,2} / N_mmol_g; %convert mg/L to mmol/m3

NH4_OUT.Date = Weir_NH4_10min.Date;

NH4_OUT   = calculationFlux(Outflow.Date, Outflow.Data, Weir_NH4_10min.Data ); % mmol/s
NH4_OUT.Data = NH4_OUT.Data  *N_mmol_g   * day_second  ; % the unit is g/d


figure

plot( NH4_IN.Date, NH4_IN.Data/1000  ) % kg/d  
hold on
plot( NH4_OUT.Date, NH4_OUT.Data./1000 )% kg/d  
hold on

leg1 = legend('Tansport in NH_{4}',  'Tansport out NH_{4}');
set(leg1,'Location','best');

set(gca,'XTick', [ datenum(timeTick )],'XTickLabel','','TickLength',[0.005 0.015]);
% set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);
ylabel({'kg/d'});
%  text( sTime + 8,800,'(a)');
%  text(0.08,1.1,'(a)','units','normalized');
 title([  currentFolder '       NH_{4} input and output'])
 grid on 
 
 %---------------------------------------
 set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 10;
xLeft = 0; yTop = 0;

set(gcf,'paperposition',[xLeft yTop xSize ySize])
saveas(gcf, [fileOutput   ' Transport in out'  var 'flux'],'png');
%---------------------

filecsv = [fileOutput   var  ' transport_in.csv'];
VarTitle = [ var ' transport_in (g/d) '];
ModelWriteVariable(NH4_IN.Date , NH4_IN.Data', filecsv, VarTitle )

filecsv = [fileOutput     var ' transport_out.csv'];
VarTitle = [ var ' transport_out (g/d) '];
ModelWriteVariable(NH4_OUT.Date  , NH4_OUT.Data', filecsv, VarTitle )


% --------calculate flux as g//m2/d

NH4_IN_area.Date = NH4_IN.Date(inlet_odd);
NH4_IN_area.Data =  NH4_IN.Data(inlet_odd) ./ wetArea.Data; 

NH4_OUT_area.Date = NH4_OUT.Date;
NH4_OUT_area.Data =  NH4_OUT.Data ./ wetArea.Data; 

filecsv = [fileOutput   var  ' transport_in_perArea.csv'];
VarTitle = [ var '_in (g/m2/d) '];
ModelWriteVariable(NH4_IN_area.Date  , NH4_IN_area.Data, filecsv, VarTitle );

filecsv = [fileOutput   var  ' transport_out_perArea.csv'];
VarTitle = [ var '_out (g/m2/d) '];
ModelWriteVariable(NH4_OUT_area.Date  , NH4_OUT_area.Data, filecsv, VarTitle );

