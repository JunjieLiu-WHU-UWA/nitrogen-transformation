

clc
close all
% addpath('E:\Simulation_UWA_WD\2 For model variables\Function');
% addpath('E:\Simulation_UWA_WD\2 For model variables\Supporting information');
% BasicRead
currentOutput = '3 nitrogen\'; 
fileOutput =  [dicmodel currentFolder '\Output\' currentOutput ];
if ~exist(fileOutput,'dir')      % check  whether the outdir  exists in the file of 'dir';
    mkdir(fileOutput);           % if not exists, create the file of 'outdir'
end
figure
subplot(5, 1,1) 
fileNH4 =  [dicmodel currentFolder '\Output\3 nitrogen\2 NH4\NH4_weir.csv'];
fid = fopen(fileNH4 ,'rt');
data = textscan(fid,'%s %f','Headerlines',1,'Delimiter',',');
NH4_weir.Date = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
NH4_weir.Data = data{1,2};
plot(NH4_weir.Date , NH4_weir.Data)
hold on 
AMM_UWA_04 =  anvil.SWQ.MSANVCBOUT.HRD.Storm_04.FNH3;
ss = find(sTime <= AMM_UWA_04.Date & AMM_UWA_04.Date <= eTime);
plot(AMM_UWA_04.Date(ss,1),AMM_UWA_04.Data(ss,1),'bs'); clear ss
hold on 

AMM_UWA_05 =  anvil.SWQ.MSANVCBOUT.HRD.Storm_05.FNH3;
ss = find(sTime <= AMM_UWA_05.Date & AMM_UWA_05.Date <= eTime);
plot(AMM_UWA_05.Date(ss,1),AMM_UWA_05.Data(ss,1),'rs'); clear ss
hold on 

leg1 = legend( 'modelled NH_{4}', 'Storm 04' , 'Storm 05');
set(leg1,'Location','best');
leg1 = legend( 'modelled', 'Storm 04' , 'Storm 05');
set(leg1,'Location','best');
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([  currentFolder ' Modelled nitrogen at outlet  ']);
xlim([sTime  eTime]);
ylim([0  2]);
ylabel(' NH_{4} (mg/L)'); 
xlabel('Date (2015)');
grid on 

subplot(5, 1,2)
fileNO3 =  [dicmodel currentFolder '\Output\3 nitrogen\3 NO3\NO3_weir.csv'];
fid = fopen(fileNO3 ,'rt');
data = textscan(fid,'%s %f','Headerlines',1,'Delimiter',',');
NO3_weir.Date = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
NO3_weir.Data = data{1,2};
plot(NO3_weir.Date , NO3_weir.Data)
hold on
NIT_UWA_04 =  anvil.SWQ.MSANVCBOUT.HRD.Storm_04.FNOx;
ss = find(sTime <= NIT_UWA_04.Date & NIT_UWA_04.Date <= eTime);
plot(NIT_UWA_04.Date(ss,1),NIT_UWA_04.Data(ss,1),'bs'); clear ss
hold on 

NIT_UWA_05 =  anvil.SWQ.MSANVCBOUT.HRD.Storm_05.FNOx;
ss = find(sTime <= NIT_UWA_05.Date & NIT_UWA_05.Date <= eTime);
plot(NIT_UWA_05.Date(ss,1),NIT_UWA_05.Data(ss,1),'rs'); clear ss
hold on 
% leg1 = legend( 'modelled NO_{3} ');
% set(leg1,'Location','best');
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
% title([  currentFolder ' NH_{4} at outlet  ']);
xlim([sTime  eTime]);
ylim([0  2]);
ylabel('  NO_{3} (mg/L)'); 
xlabel('Date (2015)');
grid on 

subplot(5, 1,3)
fileDON =  [dicmodel currentFolder '\Output\3 nitrogen\4 DON\DON_weir.csv'];
fid = fopen(fileDON ,'rt');
data = textscan(fid,'%s %f','Headerlines',1,'Delimiter',',');
DON_weir.Date = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
DON_weir.Data = data{1,2};
plot(DON_weir.Date , DON_weir.Data)
hold on
DON_UWA_04 =  anvil.SWQ.MSANVCBOUT.HRD.Storm_04.DON;
ss = find(sTime <= DON_UWA_04.Date & DON_UWA_04.Date <= eTime);
plot(DON_UWA_04.Date(ss,1),DON_UWA_04.Data(ss,1),'bs'); clear ss
hold on 

DON_UWA_05 =  anvil.SWQ.MSANVCBOUT.HRD.Storm_05.DON;
ss = find(sTime <= DON_UWA_05.Date & DON_UWA_05.Date <= eTime);
plot(DON_UWA_05.Date(ss,1),DON_UWA_05.Data(ss,1),'rs'); clear ss
hold on 

% leg1 = legend( 'modelled DON');
% set(leg1,'Location','best');
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
% title([  currentFolder ' NH_{4} at outlet  ']);
xlim([sTime  eTime]);
ylim([0 2]);
ylabel(' DON (mg/L)'); 
xlabel('Date (2015)');
grid on 

subplot(5, 1,4)
filePON =  [dicmodel currentFolder '\Output\3 nitrogen\5 PON\PON_weir.csv'];
fid = fopen(filePON ,'rt');
data = textscan(fid,'%s %f','Headerlines',1,'Delimiter',',');
PON_weir.Date = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
PON_weir.Data = data{1,2};
plot(PON_weir.Date , PON_weir.Data)
hold on
PON_UWA_04 =  anvil.SWQ.MSANVCBIN.HRD.Storm_04.PN;
ss = find(sTime <= PON_UWA_04.Date & PON_UWA_04.Date <= eTime);
plot(PON_UWA_04.Date(ss,1),PON_UWA_04.Data(ss,1),'bs'); clear ss
hold on 

PON_UWA_05 =  anvil.SWQ.MSANVCBIN.HRD.Storm_05.PN;
ss = find(sTime <= PON_UWA_05.Date & PON_UWA_05.Date <= eTime);
plot(PON_UWA_05.Date(ss,1),PON_UWA_05.Data(ss,1),'rs'); clear ss
hold on 
% leg1 = legend( 'modelled PON} ');
% set(leg1,'Location','best');
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
% title([  currentFolder ' NH_{4} at outlet  ']);
xlim([sTime  eTime]);
ylim([0  2]);
ylabel('PON (mg/L)'); 
xlabel('Date (2015)');
grid on 

subplot(5, 1,5)
fileTN =  [dicmodel currentFolder '\Output\3 nitrogen\6 TN\TN_weir.csv'];
fid = fopen(fileTN ,'rt');
data = textscan(fid,'%s %f','Headerlines',1,'Delimiter',',');
TN_weir.Date = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
TN_weir.Data = data{1,2};
plot(TN_weir.Date , TN_weir.Data)
hold on 
TN_DoW =  anvil.SWQ.MSANVCBOUT.LRD.DoW.WQ_DIAG_TOT_TN;
ss = find(sTime <= TN_DoW.Date & TN_DoW.Date <= eTime);
plot(TN_DoW.Date(ss,1),TN_DoW.Data(ss,1)./1000*14,'o'); clear ss
hold on 


TN_UWA_04 =  anvil.SWQ.MSANVCBOUT.HRD.Storm_04.UTN;
ss = find(sTime <= TN_UWA_04.Date & TN_UWA_04.Date <= eTime);
plot(TN_UWA_04.Date(ss,1),TN_UWA_04.Data(ss,1),'bs'); clear ss
hold on 

TN_UWA_05 =  anvil.SWQ.MSANVCBOUT.HRD.Storm_05.UTN;
ss = find(sTime <= TN_UWA_05.Date & TN_UWA_05.Date <= eTime);
plot(TN_UWA_05.Date(ss,1),TN_UWA_05.Data(ss,1),'rs'); clear ss
hold on 


leg1 = legend( 'modelled TN', 'DoW', 'Storm 04', 'Storm 05');
set(leg1,'Location','best');
% leg1 = legend( 'modelled TN ');
% set(leg1,'Location','best');
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
% title([  currentFolder ' NH_{4} at outlet  ']);
xlim([sTime  eTime]);
ylim([0  2]);
ylabel(' TN (mg/L)'); 
xlabel('Date (2015)');
grid on 

set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 29;
xLeft = 0; yTop = 0;
set(gcf,'paperposition',[xLeft yTop xSize ySize])
saveas(gcf,[fileOutput 'Composition of TN_calibriation'],'png');