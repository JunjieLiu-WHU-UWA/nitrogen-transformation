
clc
close all
addpath('E:\Simulation_UWA_WD\2 For model variables\Function');
addpath('E:\Simulation_UWA_WD\2 For model variables\Supporting information');
BasicRead
currentOutput = '3 nitrogen\'; 
fileOutput =  [dicmodel currentFolder '\Output\' currentOutput ];
if ~exist(fileOutput,'dir')      % check  whether the outdir  exists in the file of 'dir';
    mkdir(fileOutput);           % if not exists, create the file of 'outdir'
end

a_merge = figure;
num_fig = 7;
subplot( num_fig, 1, 1)
fileNH4 = [ fileOutput '2 NH4\Nitrification of NH4 _wholeWetland.csv'];
fid = fopen(fileNH4,'rt');
data = textscan(fid,'%s %f %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
Nitri_NH4.Date = dateTime;
Nitri_NH4.Data = data{1,3};

Nitri_NH4Daily = dailySum(Nitri_NH4);
fileNitri_NH4DailyOut = [ fileOutput '2 NH4\Nitri_NH4Daily_rate_wholeWetland.csv'];
writeDaily(Nitri_NH4Daily,  fileNitri_NH4DailyOut  ,  'Nitri_NH4Daily(g N/m2 /d)'  );
[Nitri_NH4DailynonStorm,  Nitri_NH4DailyStorm ]   = divide2period( Nitri_NH4Daily);
[h_Nitri_NH4Daily,p_Nitri_NH4Daily, ci, stats] = ttest2(Nitri_NH4DailynonStorm.Data,   Nitri_NH4DailyStorm.Data);

statis_comparison = zeros(6, 1);
statis_comparison(1, 1)  = p_Nitri_NH4Daily; % nitrification.
pp = plot(Nitri_NH4.Date  , Nitri_NH4.Data  );
hold on 
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel','','TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);
ylabel({'Nitrification',' NH_{4}', '(g N/m2 /d)'});
%  text( sTime + 8,800,'(a)');
text(0.08,1.1,'(a)','units','normalized');
title([ currentFolder '    rate'])
grid on 
AddShade([0  0] , [0.2  0.2] , period );

subplot( num_fig, 1, 2)
fileDenitri = [ fileOutput '3 NO3\Denitrification of NO3 _wholeWetland.csv'];
fid = fopen(fileDenitri,'rt');
data = textscan(fid,'%s %f %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
Denitri_NO3.Date =  dateTime ;
Denitri_NO3.Data = data{1,3};

Denitri_NO3Daily = dailySum(Denitri_NO3);
fileDenitri_NO3DailyOut = [ fileOutput '3 NO3\Denitri_NO3Daily_rate_wholeWetland.csv'];
writeDaily(Denitri_NO3Daily,  fileDenitri_NO3DailyOut  ,  'Denitri_NO3Daily(g N/m2 /d)'  );
[Denitri_NO3DailynonStorm,  Denitri_NO3DailyStorm ]   = divide2period( Denitri_NO3Daily);
[h_Denitri_NO3Daily, p_Denitri_NO3Daily, ci, stats] = ttest2(Denitri_NO3DailynonStorm.Data,   Denitri_NO3DailyStorm.Data);
statis_comparison(2, 1)  = p_Denitri_NO3Daily; % denitrification.
pp = plot(Denitri_NO3.Date  , Denitri_NO3.Data, 'r' );
hold on 
AddShade([0  0] , [0.2  0.2] , period );
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel','','TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);
ylabel({'Denitrification',' NO_{3}', '(g N/m2 /d)'});
%  text( sTime + 8,800,'(a)');
 text(0.08,1.1,'(b)','units','normalized');
%  title([ currentFolder])
 grid on 
 
 
subplot( num_fig, 1, 3)
fileMiner_DON = [ fileOutput '4 DON\Mineralisation of DON _wholeWetland.csv'];
fid = fopen(fileMiner_DON,'rt');
data = textscan(fid,'%s %f %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
Miner_DON.Date = dateTime;
Miner_DON.Data = data{1,3};
Miner_DONDaily = dailySum(Miner_DON);
fileMiner_DONDailyOut = [ fileOutput '4 DON\Miner_DONDaily_rate_wholeWetland.csv'];
writeDaily(Miner_DONDaily,  fileMiner_DONDailyOut  ,  'Miner_DONDaily(g N/m2 /d)'  );
[Miner_DONDailynonStorm,  Miner_DONDailyStorm ]   = divide2period( Miner_DONDaily);
[h_Miner_DONDaily,p_Miner_DONDaily, ci, stats] = ttest2(Miner_DONDailynonStorm.Data,   Miner_DONDailyStorm.Data);
statis_comparison(3, 1)  = p_Miner_DONDaily; % mineralisation
pp =  plot(Miner_DON.Date , Miner_DON.Data);
hold on 

set(gca,'XTick',[ datenum(timeTick )],'XTickLabel','','TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);
ylabel({'Mineralisation ',' DON', '(g N/m2 /d)'});
%  text( sTime + 8,800,'(a)');
 text(0.08,1.1,'(c)','units','normalized');
%  title([ currentFolder])
 grid on 
 AddShade([0  0] , [0.2  0.2] , period );
 
subplot( num_fig, 1, 4)
filePON_decom = [ fileOutput '5 PON\PON decomposition _wholeWetland.csv'];
fid = fopen(filePON_decom,'rt');
data = textscan(fid,'%s %f %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
Decom_PON.Date = dateTime ;
Decom_PON.Data = data{1,3};

Decom_PONDaily = dailySum(Decom_PON);
fileDecom_PONDailyOut = [ fileOutput '5 PON\Decom_PONDaily_rate_wholeWetland.csv'];
writeDaily(Decom_PONDaily,  fileDecom_PONDailyOut  ,  'Decom_PONDaily(g N/m2 /d)'  );
[Decom_PONDailynonStorm,  Decom_PONDailyStorm ]   = divide2period( Decom_PONDaily);

pp = plot(Decom_PON.Date  ,Decom_PON.Data   );
hold on 

set(gca,'XTick',[ datenum(timeTick )],'XTickLabel','','TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);
ylabel({'Decomposition ','PON', '(g N/m2 /d)'});
%  text( sTime + 8,800,'(a)');
 text(0.08,1.1,'(d)','units','normalized');
%  title([ currentFolder])
 grid on 
AddShade([0  0] , [0.2  0.2] , period );

subplot( num_fig, 1, 5)
fileNH4_plagic_uptake = [ fileOutput '2 NH4\NH4 uptake by phytoplankton _wholeWetland.csv'];
fid = fopen(fileNH4_plagic_uptake,'rt');
data = textscan(fid,'%s %f %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
NH4_plagic_uptake.Date = dateTime;
NH4_plagic_uptake.Data =  data{1,3};
NH4_plagic_uptakeDaily = dailySum(NH4_plagic_uptake);
fileNH4_plagic_uptakeDailyOut = [ fileOutput '2 NH4\NH4_plagic_uptakeDaily_rate_wholeWetland.csv'];
writeDaily(NH4_plagic_uptakeDaily,  fileNH4_plagic_uptakeDailyOut  ,  'NH4_plagic_uptakeDaily(g N/m2 /d)'  );
[NH4_plagic_uptakeDailynonStorm,  NH4_plagic_uptakeDailyStorm ]   = divide2period( NH4_plagic_uptakeDaily);
[h_NH4_plagic_uptakeDaily,p_NH4_plagic_uptakeDaily, ci, stats] = ttest2(NH4_plagic_uptakeDailynonStorm.Data,   NH4_plagic_uptakeDailyStorm.Data);
statis_comparison(4, 1)  = p_NH4_plagic_uptakeDaily; % pelagic net uptake of NH4
pp = plot(NH4_plagic_uptake.Date, NH4_plagic_uptake.Data   );
hold on 
AddShade([0  0] , [0.2  0.2] , period );

set(gca,'XTick',[ datenum(timeTick )],'XTickLabel','','TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);
ylabel({'NH_{4} ',' uptake by phytoplankton', '(g N/m2 /d)'});
%  text( sTime + 8,800,'(a)');
 text(0.08,1.1,'(e)','units','normalized');
%  title([ currentFolder])
 grid on 

 % uptake of NO3 phytoplankton
 subplot( num_fig, 1, 6)
fileNO3_plagic_uptake = [ fileOutput '3 NO3\NO3 uptake by phytoplankton _wholeWetland.csv'];
fid = fopen(fileNO3_plagic_uptake,'rt');
data = textscan(fid,'%s %f %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
NO3_plagic_uptake.Date = dateTime;
NO3_plagic_uptake.Data =  data{1,3};
NO3_plagic_uptakeDaily = dailySum(NO3_plagic_uptake);
fileNO3_plagic_uptakeDailyOut = [ fileOutput '3 NO3\NO3_plagic_uptakeDaily_rate_wholeWetland.csv'];
writeDaily(NO3_plagic_uptakeDaily,  fileNO3_plagic_uptakeDailyOut  ,  'NO3_plagic_uptakeDaily(g N/m2 /d)'  );
[NO3_plagic_uptakeDailynonStorm,  NO3_plagic_uptakeDailyStorm ]   = divide2period( NO3_plagic_uptakeDaily);
[h_NO3_plagic_uptakeDaily,p_NO3_plagic_uptakeDaily, ci, stats] = ttest2(NO3_plagic_uptakeDailynonStorm.Data,   NO3_plagic_uptakeDailyStorm.Data);
statis_comparison(5, 1)  = p_NO3_plagic_uptakeDaily; % pelagic net uptake of NO3
pp = plot(NO3_plagic_uptake.Date, NO3_plagic_uptake.Data   );
hold on 
 AddShade([0  0] , [0.2  0.2] , period );
 
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel','','TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);
ylabel({'NO_{3} ',' uptake by phytoplankton', '(g N/m2 /d)'});
%  text( sTime + 8,800,'(a)');
 text(0.08,1.1,'(e)','units','normalized');
%  title([ currentFolder])
 grid on 
 
 
 
 
% benthic uptake of NH4 or NO3
subplot( num_fig, 1, 7)
fileNH4 = [ fileOutput '3 NO3\Benthic  nitrogen uptake_wholeWetland.csv'];
 fid = fopen(fileNH4,'rt');
data = textscan(fid,'%s %f %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
BCP_uptake_NH4_NO3.Date = dateTime ;
BCP_uptake_NH4_NO3.Data = data{1,3} * 0.5 ;% the unit is g/d. the ratio between NO3 and NH4 is 1:1
BCP_uptake_NH4_NO3Daily = dailySum(BCP_uptake_NH4_NO3);
fileBCP_uptake_NH4_NO3DailyOut = [ fileOutput '3 NO3\BCP_uptake_NH4_NO3Daily_rate_wholeWetland.csv'];
writeDaily(BCP_uptake_NH4_NO3Daily,  fileBCP_uptake_NH4_NO3DailyOut  ,  'BCP_uptake_NH4_NO3Daily(g N/m2 /d)'  );
[BCP_uptake_NH4_NO3DailynonStorm,  BCP_uptake_NH4_NO3DailyStorm ]   = divide2period( BCP_uptake_NH4_NO3Daily);

[h_BCP_uptake_NH4_NO3Daily,p_BCP_uptake_NH4_NO3Daily, ci, stats] = ttest2(BCP_uptake_NH4_NO3DailynonStorm.Data,   BCP_uptake_NH4_NO3DailyStorm.Data);
statis_comparison(6, 1)  = p_BCP_uptake_NH4_NO3Daily; % bethic net uptake of NO3
pp = plot(BCP_uptake_NH4_NO3.Date, BCP_uptake_NH4_NO3.Data   );
hold on 
AddShade([-0.2  -0.2] , [0.2  0.2] , period );
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel','','TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);
ylabel({'NO_{3} or NH_{4} ',' uptake benthic ', '(g N/m2 /d)'});
%  text( sTime + 8,800,'(a)');
 text(0.08,1.1,'(e)','units','normalized');
%  title([ currentFolder])
 grid on 
 
 
 set(a_merge, 'PaperPositionMode', 'manual');
set(a_merge, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 29;
xLeft = 0;   yTop = 0;
set(a_merge,'paperposition',[xLeft yTop xSize ySize])
saveas(a_merge, [fileOutput 'Process_rate_internal'],'png');

%comparison between non-strom and storm event

lenNonStorm  = length( Nitri_NH4DailynonStorm.Data  );
lenStorm = length(Nitri_NH4DailyStorm.Data);

all_box = [Nitri_NH4DailynonStorm.Data; Nitri_NH4DailyStorm.Data; ...
 Denitri_NO3DailynonStorm.Data; Denitri_NO3DailyStorm.Data; ...
  Miner_DONDailynonStorm.Data; Miner_DONDailyStorm.Data; ...
NH4_plagic_uptakeDailynonStorm.Data; NH4_plagic_uptakeDailyStorm.Data; ...
NO3_plagic_uptakeDailynonStorm.Data; NO3_plagic_uptakeDailyStorm.Data; ...
BCP_uptake_NH4_NO3DailynonStorm.Data; BCP_uptake_NH4_NO3DailyStorm.Data] * 1000;

% all_box_ben = [BCP_uptake_NH4_NO3DailynonStorm.Data; BCP_uptake_NH4_NO3DailyStorm.Data ];
% all_grp_ben =  [ones( lenNonStorm, 1) *11; ones( lenStorm, 1) * 12];
%  
all_grp = [  ones( lenNonStorm, 1) *1; ones( lenStorm, 1) * 2; ...
                  ones( lenNonStorm, 1) *3; ones( lenStorm, 1) * 4; ...
                  ones( lenNonStorm, 1) *5; ones( lenStorm, 1) * 6; ...
                  ones( lenNonStorm, 1) *7; ones( lenStorm, 1) * 8; ...
                   ones( lenNonStorm, 1) *9; ones( lenStorm, 1) * 10 ;...
                   ones( lenNonStorm, 1) *11; ones( lenStorm, 1) * 12 ];
abb = figure;
% yyaxis left
% title([ currentFolder ]);
 boxplot(all_box, all_grp);
 hold on
%  yyaxis right
%   boxplot(all_box_ben, all_grp_ben);
set(gca,'XTick',[1.5  3.5 5.5 7.5 9.5 11.5 13.5 ], 'XTickLabel',{'Nitrification', ...
                                                          'Denitrification', ...
                                                          'Minerlization', ...
                                                          'Pelagic net uptake of NH4', ...
                                                          'Pelagic net uptake of NO3', ...
                                                         'Benthic net uptake of NH4 or NO3' },'TickLength',[0.005 0.015], ...
                                                          'XTickLabelRotation',15);
%   grid on 
% set(fig, 'XTickLabel','');
ylabel({'mg N /m^{2}/d'});
x2 = [1.5  2.5];
y4 = [-20 -20 ];
y5= [120  120 ];
patch('YData',[y4 fliplr(y5)],'XData',[x2 fliplr(x2)],...
    'FaceColor',[0.5 0.5 0.5], ...
    'EdgeColor','none');
alpha(0.5)

x2 = [3.5  4.5];
y4 = [-20 -20 ];
y5= [120  120 ];
patch('YData',[y4 fliplr(y5)],'XData',[x2 fliplr(x2)],...
    'FaceColor',[0.5 0.5 0.5], ...
    'EdgeColor','none');
alpha(0.5)

x2 = [5.5  6.5];
y4 = [-20 -20 ];
y5= [120  120 ];
patch('YData',[y4 fliplr(y5)],'XData',[x2 fliplr(x2)],...
    'FaceColor',[0.5 0.5 0.5], ...
    'EdgeColor','none');
alpha(0.5)

x2 = [7.5  8.5];
y4 = [-20 -20 ];
y5= [120  120 ];
patch('YData',[y4 fliplr(y5)],'XData',[x2 fliplr(x2)],...
    'FaceColor',[0.5 0.5 0.5], ...
    'EdgeColor','none');
alpha(0.5)



x2 = [9.5  10.5];
y4 = [-20 -20 ];
y5= [120  120 ];
patch('YData',[y4 fliplr(y5)],'XData',[x2 fliplr(x2)],...
    'FaceColor',[0.5 0.5 0.5], ...
    'EdgeColor','none');
alpha(0.5)

x2 = [11.5  12.5];
y4 = [-20 -20 ];
y5= [120  120 ];
patch('YData',[y4 fliplr(y5)],'XData',[x2 fliplr(x2)],...
    'FaceColor',[0.5 0.5 0.5], ...
    'EdgeColor','none');
alpha(0.5)
% title([ currentFolder ]);


set(abb, 'PaperPositionMode', 'manual');
set(abb, 'PaperUnits', 'centimeters');
xSize = 15; ySize = 8;
xLeft = 0; yTop = 0;

set(abb, 'paperposition',[xLeft yTop xSize ySize])
% saveas(abb, [fileOutput   'Comparison of process nitrorgen non storm'],'png');
% saveas(gcf, [fileOutput    'Comparison of process nitrorgen non storm'],'fig');
print(abb,[fileOutput  'fig Comparison of process nitrorgen non storm_label.png'],'-dpng','-r300');

%%%%%
% double line x ticks
abb = figure;
% yyaxis left
% title([ currentFolder ]);
 axes('Position',[0.13 0.16969696969697 0.775 0.75530303030303]);
 boxplot(all_box, all_grp);
 hold on
 set(gca, 'xticklabel', []) %Remove tick labels
%  yyaxis right
%   boxplot(all_box_ben, all_grp_ben);
yTicks = get(gca,'ytick');
xTicks = get(gca, 'xtick');

minY = min(yTicks);
% You will have to adjust the offset based on the size of figure
VerticalOffset = 40;
HorizontalOffset = 1.8;
set(gca,'XTick',[1.5  3.5 5.5 7.5 9.5 11.5 ], 'XTickLabel',{'', ...
                                                          '', ...
                                                          '', ...
                                                          '', ...
                                                          '', ...
                                                         '' },'TickLength',[0.005 0.015]);

text(1.5 - HorizontalOffset, minY - 30, ['Nitrification'], 'Rotation',15);
text(3.5 - HorizontalOffset-0.2, minY - 30, ['Denitrification'], 'Rotation',15);
text(5.5 - HorizontalOffset-0.2, minY - 30, ['Mineralization'], 'Rotation',15);
text(7.5 - HorizontalOffset-1, minY - VerticalOffset, {'Pelagic net uptake',  ' of NH4'}, 'Rotation',15);
text(9.5 - HorizontalOffset-1, minY - VerticalOffset, {'Pelagic net uptake',  ' of NO3'}, 'Rotation',15);
text(11.5 - HorizontalOffset-1, minY - VerticalOffset, {'Benthic net uptake',  ' of NH4 or NO3'},  'Rotation',15);

% % text(7.5 - HorizontalOffset, minY - VerticalOffset, ['$$\begin{array}{c}', 'Pelagic net uptake', '\\' , ' of NH4', '\end{array}$$'], 'Interpreter', 'latex');
% text(9.5 - HorizontalOffset, minY - VerticalOffset, ['$$\begin{array}{c}', 'Pelagic  net uptake', '\\' , ' of NO3', '\end{array}$$'], 'Interpreter', 'latex');
% text(11.5 - HorizontalOffset, minY - VerticalOffset, ['$$\begin{array}{c}', 'Benthic net uptake', '\\' , ' of NH4 or NO3', '\end{array}$$'], 'Interpreter', 'latex');


% for xx = 1:length(xTicks)
% % Create a text box at every Tick label position
% % String is specified as LaTeX string and other appropriate properties are set
% text(xTicks(xx) - HorizontalOffset, minY - VerticalOffset, ['$$\begin{array}{c}', num2str( xTicks(xx)),'\\',num2str( 2*xTicks(xx)),'\end{array}$$'], 'Interpreter', 'latex')
% % {c} specifies that the elements of the different lines will be center
% % aligned. It may be replaced by {l} or {r} for left or right alignment
% end
%       set(gca,   'XTickLabelRotation',15);
% set(gca,'XTick',[1.5  3.5 5.5 7.5 9.5 11.5 13.5 ], 'XTickLabel',{'Nitrification', ...
%                                                           'Denitrification', ...
%                                                           'Minerlization', ...
%                                                           'Pelagic net uptake of NH4', ...
%                                                           'Pelagic net uptake of NO3', ...
%                                                          'Benthic net uptake of NH4 or NO3' },'TickLength',[0.005 0.015], ...
%                                                           'XTickLabelRotation',15);
%   grid on 
% set(fig, 'XTickLabel','');
ylabel({'mg N /m^{2}/d'});
x2 = [1.5  2.5];
y4 = [-20 -20 ];
y5= [120  120 ];
patch('YData',[y4 fliplr(y5)],'XData',[x2 fliplr(x2)],...
    'FaceColor',[0.5 0.5 0.5], ...
    'EdgeColor','none');
alpha(0.5)

x2 = [3.5  4.5];
y4 = [-20 -20 ];
y5= [120  120 ];
patch('YData',[y4 fliplr(y5)],'XData',[x2 fliplr(x2)],...
    'FaceColor',[0.5 0.5 0.5], ...
    'EdgeColor','none');
alpha(0.5)

x2 = [5.5  6.5];
y4 = [-20 -20 ];
y5= [120  120 ];
patch('YData',[y4 fliplr(y5)],'XData',[x2 fliplr(x2)],...
    'FaceColor',[0.5 0.5 0.5], ...
    'EdgeColor','none');
alpha(0.5)

x2 = [7.5  8.5];
y4 = [-20 -20 ];
y5= [120  120 ];
patch('YData',[y4 fliplr(y5)],'XData',[x2 fliplr(x2)],...
    'FaceColor',[0.5 0.5 0.5], ...
    'EdgeColor','none');
alpha(0.5)



x2 = [9.5  10.5];
y4 = [-20 -20 ];
y5= [120  120 ];
patch('YData',[y4 fliplr(y5)],'XData',[x2 fliplr(x2)],...
    'FaceColor',[0.5 0.5 0.5], ...
    'EdgeColor','none');
alpha(0.5)

x2 = [11.5  12.5];
y4 = [-20 -20 ];
y5= [120  120 ];
patch('YData',[y4 fliplr(y5)],'XData',[x2 fliplr(x2)],...
    'FaceColor',[0.5 0.5 0.5], ...
    'EdgeColor','none');
alpha(0.5)
% title([ currentFolder ]);


set(abb, 'PaperPositionMode', 'manual');
set(abb, 'PaperUnits', 'centimeters');
xSize = 15; ySize = 8;
xLeft = 0; yTop = 0;

set(abb, 'paperposition',[xLeft yTop xSize ySize])
% saveas(abb, [fileOutput   'Comparison of process nitrorgen non storm'],'png');
% saveas(gcf, [fileOutput    'Comparison of process nitrorgen non storm'],'fig');
print(abb,[fileOutput  'fig Comparison of process nitrorgen non storm_label_double.png'],'-dpng','-r300');

%   double y axes

all_box_combine = [Nitri_NH4DailynonStorm.Data; Nitri_NH4DailyStorm.Data; ...
 Denitri_NO3DailynonStorm.Data; Denitri_NO3DailyStorm.Data; ...
  Miner_DONDailynonStorm.Data; Miner_DONDailyStorm.Data; ...
NH4_plagic_uptakeDailynonStorm.Data; NH4_plagic_uptakeDailyStorm.Data; ...
NO3_plagic_uptakeDailynonStorm.Data; NO3_plagic_uptakeDailyStorm.Data; ...
    zeros(lenNonStorm, 1); zeros(lenStorm, 1)] * 1000;

% all_box_ben = [BCP_uptake_NH4_NO3DailynonStorm.Data; BCP_uptake_NH4_NO3DailyStorm.Data ];
all_box_ben = [ zeros(lenNonStorm, 1); zeros(lenStorm, 1); ...
 zeros(lenNonStorm, 1); zeros(lenStorm, 1); ...
   zeros(lenNonStorm, 1); zeros(lenStorm, 1); ...
 zeros(lenNonStorm, 1); zeros(lenStorm, 1); ...
 zeros(lenNonStorm, 1); zeros(lenStorm, 1); ...
    BCP_uptake_NH4_NO3DailynonStorm.Data; BCP_uptake_NH4_NO3DailyStorm.Data] *1000 ;
% all_grp_ben =  [ones( lenNonStorm, 1) *11; ones( lenStorm, 1) * 12];
 
all_grp = [  ones( lenNonStorm, 1) *1; ones( lenStorm, 1) * 2; ...
                  ones( lenNonStorm, 1) *3; ones( lenStorm, 1) * 4; ...
                  ones( lenNonStorm, 1) *5; ones( lenStorm, 1) * 6; ...
                  ones( lenNonStorm, 1) *7; ones( lenStorm, 1) * 8; ...
                   ones( lenNonStorm, 1) *9; ones( lenStorm, 1) * 10;...
                  ones( lenNonStorm, 1) *11; ones( lenStorm, 1) * 12;  ];
              
aaa = figure;
 yyaxis left
 title([ currentFolder '    rate']);
  gcf = boxplot(all_box_combine, all_grp);
 hold on
 % For calibriation
% ylim( [0 50 ]) 
%  % measured nitrification
%  location_nitri = [ 1 1  1 1]'; 
%  mea_nitri = [33.6  30 45 50]';
% plot( location_nitri , mea_nitri, '*' )
% hold on 
% % measured denitrification
%  location_denitri = [ 3 3  3 3]; 
%  mea_denitri = [33.6  40 45 50];
% plot( location_denitri , mea_denitri, '*' )
% hold on 
% 

h = findobj(gcf,'tag','Median');
for j=11:length(h)
    set(h(j), 'Color', [ 1 1 1 ]);
%    line(get(h(j),'Tag','Median','Color',[0 0 0]);
end

for j=1 : 10
    set(h(j), 'Color', [ 0, 0.4470, 0.7410]);
%    line(get(h(j),'Tag','Median','Color',[0 0 0]);
end



h = findobj(gcf,'tag','Outliers');
for iH = 1:10
    h(iH).MarkerEdgeColor =  [0, 0.4470, 0.7410 ];
end

h = findobj(gcf,'tag','Upper Whisker');
for iH =1:10
    h(iH).Color =  [0, 0.4470, 0.7410 ];
end

h = findobj(gcf,'tag','Lower Whisker');
for iH = 1:10
    h(iH).Color =  [0, 0.4470, 0.7410 ];
end

h = findobj(gcf,'tag','Upper Adjacent Value');
for iH = 1:10
    h(iH).Color =  [0, 0.4470, 0.7410 ];
end

h = findobj(gcf,'tag','Lower Adjacent Value');
for iH = 1:10
    h(iH).Color =  [0, 0.4470, 0.7410 ];
end

h = findobj(gcf,'tag','Box');
for iH = 1:10
     set(h(iH), 'Color', [0, 0.4470, 0.7410  ]);
end


 ylabel({'mg N /m^{2}/d'});

% set(findobj(gcf,'tag','Box'), 'Color', [ 0 0 0 ]);

%----------------------------
 yyaxis right
  gcf = boxplot(all_box_ben, all_grp);
   ylabel({'mg N /m^{2}/d'});
  h = findobj(gcf,'tag','Median');
for j=1:10

    set(h(j), 'Color', [ 1 1 1]);
    
%    line(get(h(j),'Tag','Median','Color',[0 0 0]);
end

  h = findobj(gcf,'tag','Median');
for j=11:length(h)
  set(h(j), 'Color', [ 1 0 0]);
%    line(get(h(j),'Tag','Median','Color',[0 0 0]);
end

h = findobj(gcf,'tag','Box');
for j=11:length(h)
    set(h(j), 'Color', [  1 0 0]);
%    line(get(h(j),'Tag','Median','Color',[0 0 0]);
end
h = findobj(gcf,'tag','Outliers');
for iH = 1:length(h)
    h(iH).MarkerEdgeColor =  [ 1 0 0];
end



h = findobj(gcf,'tag','Upper Whisker');
for iH = 1:length(h)
    h(iH).Color =  [ 1 0 0];
end

h = findobj(gcf,'tag','Lower Whisker');
for iH = 1:length(h)
    h(iH).Color =  [ 1 0 0 ];
end
h = findobj(gcf,'tag','Upper Adjacent Value');
for iH = 1:length(h)
    h(iH).Color =  [ 1 0 0];
end

h = findobj(gcf,'tag','Lower Adjacent Value');
for iH = 1:length(h)
    h(iH).Color =  [ 1 0 0];
end

set(gca,'XTick',[1.5  3.5 5.5 7.5 9.5 11.5 13.5 ], 'XTickLabel',{'Nitri_NH4', ...
                                                          'Denitri_NO3', ...
                                                          'Miner_DON', ...
                                                          'plagic_NH4', ...
                                                          'pelagic_NO3', ...
                                                         'BEN_NH4_NO3' },'TickLength',[0.005 0.015]);
    set(gca, 'Ycolor', [1 0 0 ]);                                               
% set(fig, 'XTickLabel','');

x2 = [1.5  2.5];
y4 = [-50  -50 ];
y5= [50 50];
patch('YData',[y4 fliplr(y5)],'XData',[x2 fliplr(x2)],...
    'FaceColor',[0.5 0.5 0.5], ...
    'EdgeColor','none');
alpha(0.5)

x2 = [3.5  4.5];
y4 = [-50  -50 ];
y5= [50 50];
patch('YData',[y4 fliplr(y5)],'XData',[x2 fliplr(x2)],...
    'FaceColor',[0.5 0.5 0.5], ...
    'EdgeColor','none');
alpha(0.5)

x2 = [5.5  6.5];
y4 = [-50  -50 ];
y5= [50 50];
patch('YData',[y4 fliplr(y5)],'XData',[x2 fliplr(x2)],...
    'FaceColor',[0.5 0.5 0.5], ...
    'EdgeColor','none');
alpha(0.5)

x2 = [7.5  8.5];
y4 = [-50  -50 ];
y5= [50 50];
patch('YData',[y4 fliplr(y5)],'XData',[x2 fliplr(x2)],...
    'FaceColor',[0.5 0.5 0.5], ...
    'EdgeColor','none');
alpha(0.5)



x2 = [9.5  10.5];
y4 = [-50  -50 ];
y5= [50 50];
patch('YData',[y4 fliplr(y5)],'XData',[x2 fliplr(x2)],...
    'FaceColor',[0.5 0.5 0.5], ...
    'EdgeColor','none');
alpha(0.5)

x2 = [11.5  12.5];
y4 = [-50  -50 ];
y5= [50 50];
patch('YData',[y4 fliplr(y5)],'XData',[x2 fliplr(x2)],...
    'FaceColor',[0.5 0.5 0.5], ...
    'EdgeColor','none');
alpha(0.5)

set(aaa, 'PaperPositionMode', 'manual');
set(aaa, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 10;
xLeft = 0; yTop = 0;

set(aaa, 'paperposition',[xLeft yTop xSize ySize])
% saveas(aaa, [fileOutput   'Comparison of process double axes nitrorgen non storm'],'png');
% saveas(gcf, [fileOutput    'Comparison of process nitrorgen non storm'],'fig');
print(aaa,[fileOutput  'Comparison of process double axes nitrorgen non storm.png'],'-dpng','-r300');


% calculate the median  during non storm period % g N/m2/d
% nitrification
internalProcessMedian_nonStorm(1 , 1 ) =  median(Nitri_NH4DailynonStorm.Data  );
% denitrification
internalProcessMedian_nonStorm(2 , 1 ) =  median(Denitri_NO3DailynonStorm.Data  );
% mineralisation
internalProcessMedian_nonStorm(3 , 1 ) =  median(Miner_DONDailynonStorm.Data );
% pelagica uptake of NH4
internalProcessMedian_nonStorm(4 , 1 ) =  median(NH4_plagic_uptakeDailynonStorm.Data  );
% pelagica uptake of NO3
internalProcessMedian_nonStorm(5 , 1 ) =  median(NO3_plagic_uptakeDailynonStorm.Data );
% pelagic uptake of NO3  and NH4
internalProcessMedian_nonStorm(6 , 1 ) =  median(BCP_uptake_NH4_NO3DailynonStorm.Data  );

  internalProcessMedian_nonStorm = internalProcessMedian_nonStorm * 1000;                    % g N/m2/d
% calculate the median  during storm period % g N/m2/d
% nitrification
internalProcessMedian_Storm(1 , 1 ) =  median(Nitri_NH4DailyStorm.Data  );
% denitrification
internalProcessMedian_Storm(2 , 1 ) =  median(Denitri_NO3DailyStorm.Data  );
% mineralisation
internalProcessMedian_Storm(3 , 1 ) =  median(Miner_DONDailyStorm.Data );
% pelagica uptake of NH4
internalProcessMedian_Storm(4 , 1 ) =  median(NH4_plagic_uptakeDailyStorm.Data  );
% pelagica uptake of NO3
internalProcessMedian_Storm(5 , 1 ) =  median(NO3_plagic_uptakeDailyStorm.Data );
% pelagic uptake of NO3  and NH4
internalProcessMedian_Storm(6 , 1 ) =  median(BCP_uptake_NH4_NO3DailyStorm.Data  );

  internalProcessMedian_Storm = internalProcessMedian_Storm * 1000;                    % mg N/m2/d
  
  % calculate the median  during whole period % g N/m2/d
% nitrification
internalProcessMedian_whole(1 , 1 ) =  median(Nitri_NH4Daily.Data  );
% denitrification
internalProcessMedian_whole(2 , 1 ) =  median(Denitri_NO3Daily.Data  );
% mineralisation
internalProcessMedian_whole(3 , 1 ) =  median(Miner_DONDaily.Data );
% pelagica uptake of NH4
internalProcessMedian_whole(4 , 1 ) =  median(NH4_plagic_uptakeDaily.Data  );
% pelagica uptake of NO3
internalProcessMedian_whole(5 , 1 ) =  median(NO3_plagic_uptakeDaily.Data );
% pelagic uptake of NO3  and NH4
internalProcessMedian_whole(6 , 1 ) =  median(BCP_uptake_NH4_NO3Daily.Data  );

  internalProcessMedian_whole = internalProcessMedian_whole * 1000;                    % mg N/m2/d
  
  
%---------------Write  internalProcess  at inlet  into file ---------------------------------------------------------
 filename = [ fileOutput 'internalProcess_nitrogen_non_storm.csv'];
fid = fopen(filename,'wt');
fprintf(fid, ...
  'species (mg N /m2/d), nitrification, denitrification, mineralisation,NH4_pelagic_uptake, NO3_pelagic_uptake, NO3_NH4_benthic_uptake\n');
fprintf(fid,'internalProcessMedian_nonStorm,');
for ii = 1 : length(internalProcessMedian_nonStorm)
     if  ii == length(internalProcessMedian_nonStorm)
         
          fprintf(fid,'%4.4f\n ',    internalProcessMedian_nonStorm(ii));
     else
 fprintf(fid,'%4.4f, ',    internalProcessMedian_nonStorm(ii));
     end

 
end
fprintf(fid,'internalProcessMedian_Storm,');
for ii = 1 : length(internalProcessMedian_Storm)
     if  ii == length(internalProcessMedian_Storm)
         
          fprintf(fid,'%4.4f\n ',    internalProcessMedian_Storm(ii));
     else
 fprintf(fid,'%4.4f, ',    internalProcessMedian_Storm(ii));
     end

 
end

fprintf(fid,'internalProcessMedian_whole,');
for ii = 1 : length(internalProcessMedian_whole)
     if  ii == length(internalProcessMedian_whole)
         
          fprintf(fid,'%4.4f\n ',    internalProcessMedian_whole(ii));
     else
 fprintf(fid,'%4.4f, ',    internalProcessMedian_whole(ii));
     end

 
end

fprintf(fid,'Value of p,');
for ii = 1 : length(statis_comparison)
     if  ii == length(statis_comparison)
         
          fprintf(fid,'%4.4f\n ',    statis_comparison(ii));
     else
 fprintf(fid,'%4.4f, ',    statis_comparison(ii));
     end

 
end
fclose(fid);
%------------------------
% read  value from litratrue

file_denitirf =  [ dicmodel  '3 nitrogen\' 'Alldred and Baines (2015)_Data_Export_Final.csv'];
fid = fopen(file_denitirf ,'rt');
str_s = repmat( '%s '  , [1 8]);
str_f = repmat('%f ', [1 12] );
data_denitirf = textscan(fid,[str_s  str_f],'Headerlines',1,'Delimiter',',');
literature_denitirf_Veg  = data_denitirf{1,10}  *1000 *24   ;  %  the original unit is  g N/m2/h  after conversion, 
  literature_denitirf_nonVeg = data_denitirf{1,15}  *1000 *24   ; 
  literature_denitirf_all  = [literature_denitirf_Veg ;  literature_denitirf_nonVeg(~isnan(  literature_denitirf_nonVeg)) ];
  
                                                                                            % the unit is mg N/m2/d
% figure
%      histogram(data_denitirf{1,10} *1000 , nbins  )                                                                               
%                    Denitri_NO3DailynonStorm.Data 


     xtickle_log = [0.01  0.1  1 10 100 1000 10000];
     xtickleLable_log = {'10^{-2}'  '10^{-1}' '10^{0}'  '10^{1}'  '10^{2}' '10^{3}'  '10^{4}'  };
  gcf_hist = figure
% nbins = 1700;
subplot(1, 2, 1)

rate_denitrif = [Denitri_NO3DailynonStorm.Data * 1000; ... % first is the modelled results
                  27.74 ; 130.57 ; 43.89;  36.69 ]; % second is the meausred resulsts
                    % third is vluae from literature  % mg N/m2/d
               
 location_denitrif =  [ones( lenNonStorm, 1) *1;   ...
                ones(4,1) * 2] ;
            
   boxplot(rate_denitrif, location_denitrif) ;        
 set(gca,'XTick',[1  2   3 ], 'XTickLabel',{'Modelled', ...
                                                          'Measured' },'TickLength',[0.005 0.015]);  
ylabel('mg N /m^{2}/d');  
text(0.01,1.05,['(a)' currentFolder ' denitrification'  ],'units','normalized');
gca_hist = subplot(1, 2, 2)
% title([ currentFolder 'denitrification'  ])
 edges = [ 0.01  0.05 0.1  0.5  1  5   10  50   100  500  1000 5000 10000];
     histogram(literature_denitirf_all, edges  )   
     hold on 
     histogram(Denitri_NO3Daily.Data*1000)
     hold on 
     xlabel('mg N /m^{2}/d');
     ylabel('Count');
       set(gca_hist,'XScale','log', 'TickDir','out', 'color','none', 'box','off');    
        set(gca_hist, 'FontSize',7.5 , 'XTick', ...
            xtickle_log,'XTickLabel', xtickleLable_log ,'TickLength',[0.005 0.015]);
                 legend('Value from literature', 'Modelled');
        text(0.01,1.05,'(b)','units','normalized');
        b = axes('Position',get(gca_hist,'Position'),'box','on','xtick',[],'ytick',[], 'color','none');
% set original axes as active
   axes(gca_hist)
          linkaxes([gca_hist  b])
set(gcf_hist, 'PaperPositionMode', 'manual');
set(gcf_hist, 'PaperUnits', 'centimeters');
xSize = 15; ySize = 10;
xLeft = 0; yTop = 0;
set(gcf_hist,'paperposition',[xLeft yTop xSize ySize])
print(gcf_hist,[fileOutput  'histogram_denitrificaion_model_measure_literature.tiff'],'-dtiff','-r300');
print(gcf_hist,[fileOutput  'histogram_denitrificaion_model_measure_literature.png'],'-dpng','-r300');
%


 edges = [ 0.01  0.05 0.1  0.5  1  5   10  50   100  500  1000 5000 10000];

figure
hh = histogram(Denitri_NO3Daily.Data*1000, edges)



gcf_hist = figure
% nbins = 1700;
subplot(1, 2, 1)

rate_denitrif = [Denitri_NO3DailynonStorm.Data * 1000; ... % first is the modelled results
              ]; % second is the meausred resulsts
                    % third is vluae from literature  % mg N/m2/d
               
 location_denitrif =  [ones( lenNonStorm, 1) *1] ;
            
   boxplot(rate_denitrif, location_denitrif) ;     
   hold on
   measure_location  = [2 2 2 2 ];
    measure_denitrif_winter =     [27.74 ; 130.57 ; 43.89;  36.69];
    scatter(   measure_location , measure_denitrif_winter, '*' );
    hold on
      measure_denitrif_summer =     [0.08 ; 9.77 ; 139.10;  38.06];
    scatter(   measure_location , measure_denitrif_summer, 's');
    hold on
    xlim([ 0.5 2.5]);
    ylim([0 150 ]);
    
 set(gca,'XTick',[1  2    ], 'XTickLabel',{'Modelled', ...
                                                          'Measured' },'TickLength',[0.005 0.015]);  
ylabel('mg N /m^{2}/d');  
text(0.01,1.05,['(a)' currentFolder ' denitrification'  ],'units','normalized');
%   breakInfo = breakyaxis([-450  -50 ], 0.04);
  
gca_hist = subplot(1, 2, 2)
% title([ currentFolder 'denitrification'  ])
 edges = [ 0.01  0.05 0.1  0.5  1  5   10  50   100  500  1000 5000 10000];
     histogram(literature_denitirf_all, edges, 'Normalization','probability'  )  
%      histogram(S,)
     hold on 
     num_model = [ 1 43 16 1];

% histogram(Denitri_NO3Daily.Data*1000, edges, 'Normalization','probability' )
%      hold on 
     xlabel('mg N /m^{2}/d');
%      ylabel('Count');

       set(gca_hist,'XScale','log', 'TickDir','out', 'color','none', 'box','off');    
        set(gca_hist, 'FontSize',7.5 , 'XTick', ...
            xtickle_log,'XTickLabel', xtickleLable_log ,'TickLength',[0.005 0.015]);
                 legend('Value from literature', 'Modelled');
        text(0.01,1.05,'(b)','units','normalized');
%              text( [ 6 7 8 9], num_model , num2str(num_model'), 'vert', 'bottom', 'horiz', 'center');
          text(0.45,0.36,'1','units','normalized');
            text(0.515197568389058,  0.61686591276252,'43','units','normalized');
            text(0.595592705167173, 0.343844911147011,'16','units','normalized');
               text(0.712462006079027, 0.521550888529887,'1','units','normalized');
        b = axes('Position',get(gca_hist,'Position'),'box','on','xtick',[],'ytick',[], 'color','none');
% set original axes as active
   axes(gca_hist)
          linkaxes([gca_hist  b])
          ylim([0 0.4 ])
set(gcf_hist, 'PaperPositionMode', 'manual');
set(gcf_hist, 'PaperUnits', 'centimeters');
xSize = 15; ySize = 10;
xLeft = 0; yTop = 0;
set(gcf_hist,'paperposition',[xLeft yTop xSize ySize])
% print(gcf_hist,[fileOutput  'histogram_denitrificaion_model_measure_literature.tiff'],'-dtiff','-r300');
print(gcf_hist,[fileOutput  'histogram_denitrificaion_model_measure_literature_WinSum.png'],'-dpng','-r300');




% double axes for denitrification
gcf_hist = figure
% nbins = 1700;
subplot(1, 2, 1)

rate_denitrif = [Denitri_NO3DailynonStorm.Data * 1000; ... % first is the modelled results
              ]; % second is the meausred resulsts
                    % third is vluae from literature  % mg N/m2/d
               
 location_denitrif =  [ones( lenNonStorm, 1) *1] ;
            
   boxplot(rate_denitrif, location_denitrif) ;     
   hold on
   measure_location  = [2 2 2 2 ];
    measure_denitrif_winter =     [27.74 ; 130.57 ; 43.89;  36.69];
    scatter(   measure_location , measure_denitrif_winter, '*' );
    hold on
      measure_denitrif_summer =     [0.08 ; 9.77 ; 139.10;  38.06];
    scatter(   measure_location , measure_denitrif_summer, 's');
    hold on
    xlim([ 0.5 2.5]);
    ylim([0 150 ]);
    
 set(gca,'XTick',[1  2    ], 'XTickLabel',{'Modelled', ...
                                                          'Measured' },'TickLength',[0.005 0.015]);  
ylabel('mg N /m^{2}/d');  
% text(0.01,1.05,['(a)' currentFolder ' denitrification'  ],'units','normalized');
%   breakInfo = breakyaxis([-450  -50 ], 0.04);
  
gca_hist = subplot(1, 2, 2)
yyaxis left
% title([ currentFolder 'denitrification'  ])
 edges = [ 0.01  0.05 0.1  0.5  1  5   10  50   100  500  1000 5000 10000];
     histogram(literature_denitirf_all, edges, 'Normalization','probability'  )  
%      histogram(S,)
     hold on 
     num_model = [ 1 43 16 1];
     ylim([ 0  0.5]);
     ylabel('Probability');
yyaxis right
 histogram(Denitri_NO3Daily.Data*1000, edges,'FaceColor', [ 1 0 0] )
set(gca_hist,'YColor',[1 0 0 ],'YDir','reverse');
ylabel('Count');
% set(yy_right, 'YDir', 'reverse')
% ylim( [  0  50 ])
% max(Denitri_NO3Daily.Data*1000)
%      hold on 
     xlabel('mg N /m^{2}/d');
%      ylabel('Count');

       set(gca_hist,'XScale','log', 'TickDir','out', 'color','none', 'box','off');    
       set(gca_hist, 'FontSize',7.5 , 'XTick', ...
       xtickle_log,'XTickLabel', xtickleLable_log ,'TickLength',[0.005 0.015]);
       leg1 = legend('Value from literature', 'Modelled');
       set(leg1,...
    'Position',[0.638598326359833 0.614564007421149 0.207635983263598 0.0756029684601112]);
%         text(0.01,1.05,'(b)','units','normalized');
% %              text( [ 6 7 8 9], num_model , num2str(num_model'), 'vert', 'bottom', 'horiz', 'center');
%           text(0.45,0.36,'1','units','normalized');
%             text(0.515197568389058,  0.61686591276252,'43','units','normalized');
%             text(0.595592705167173, 0.343844911147011,'16','units','normalized');
%                text(0.712462006079027, 0.521550888529887,'1','units','normalized');
        b = axes('Position',get(gca_hist,'Position'),'box','on','xtick',[],'ytick',[], 'color','none');
% set original axes as active
   axes(gca_hist)
          linkaxes([gca_hist  b])
          ylim([0 100 ])
set(gcf_hist, 'PaperPositionMode', 'manual');
set(gcf_hist, 'PaperUnits', 'centimeters');
xSize = 15; ySize = 10;
xLeft = 0; yTop = 0;
set(gcf_hist,'paperposition',[xLeft yTop xSize ySize])
% print(gcf_hist,[fileOutput  'histogram_denitrificaion_model_measure_literature.tiff'],'-dtiff','-r300');
print(gcf_hist,[fileOutput  'fig histogram_denitrificaion_model_measure_literature_WinSum_double.png'],'-dpng','-r300');

% calibriation for nitrification
gcf_hist = figure
% nbins = 1700;
% subplot(1, 2, 1)
% title([ currentFolder  'nitrication'  ])
rate_nitrif = [Nitri_NH4DailynonStorm.Data * 1000; ... % first is the modelled results
                   ]; % second is the meausred resulsts
                    % third is vluae from literature  % mg N/m2/d
               
 location_nitrif =  [ones( lenNonStorm, 1) *1] ;
            
   boxplot(rate_nitrif, location_nitrif) ;    
   hold on
      measure_location  = [2 2 2 2 ];
      measure_nitrif_winter = [18.76 ; 72.95 ; 29.32; 19.76];
      
          scatter(   measure_location , measure_nitrif_winter, '*' );
    hold on
      measure_nitrif_summer =     [0.05 ; 5.46 ; 92.90;  20.66];
    scatter(   measure_location , measure_nitrif_summer, 's');
      xlim([ 0.5 2.5])
      ylim([0  100 ])
 set(gca,'XTick',[1  2    ], 'XTickLabel',{'Modelled', ...
                                                          'Measured' },'TickLength',[0.005 0.015]);  
ylabel('mg N /m^{2}/d');  
% text(0.01,1.05,['(a)' currentFolder  ' nitrication'],'units','normalized');

% gca_hist = subplot(1, 2, 2)
% 
%    
% 
%      edges = [ 0.01  0.05 0.1  0.5  1  5   10  50   100  500  1000 5000 10000];
%      histogram(literature_denitirf_all,   edges   )    % temperally, it is denitrification
%      hold on 
%      histogram(Nitri_NH4Daily.Data*1000)
%      hold on 
%      xlabel('mg N /m^{2}/d');
%      ylabel('Count');
%      xlim([ 0.01  10000]);
% 
% 
%         set(gca_hist,'XScale','log', 'TickDir','out', 'color','none', 'box','off');    
%         set(gca_hist, 'FontSize',7.5 , 'XTick', ...
%             xtickle_log,'XTickLabel', xtickleLable_log ,'TickLength',[0.005 0.015]);
%                  legend('Value from literature', 'Modelled');
%         text(0.01,1.05,'(b)','units','normalized');
%         b = axes('Position',get(gca_hist,'Position'),'box','on','xtick',[],'ytick',[], 'color','none');
% % set original axes as active
%    axes(gca_hist)
%           linkaxes([gca_hist  b])
%     % 
set(gcf_hist, 'PaperPositionMode', 'manual');
set(gcf_hist, 'PaperUnits', 'centimeters');
xSize =7.5; ySize = 10;
xLeft = 0; yTop = 0;
set(gcf_hist,'paperposition',[xLeft yTop xSize ySize])
% print(gcf_hist,[fileOutput  'histogram_nitrification_model_measure_literature.tiff'],'-dtiff','-r300');
print(gcf_hist,[fileOutput  'fig histogram_nitrification_model_measure_WinSum.png'],'-dpng','-r300');

   