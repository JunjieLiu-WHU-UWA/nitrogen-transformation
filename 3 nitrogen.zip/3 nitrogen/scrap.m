figure
ax1 = axes('position', [0.1 0.77 0.6 0.15  ]);
h(1) = plot(InflowNit.Date,  InflowNit.Data  );
hold on
set(ax1,'xticklabel',[]);
ax2 = axes('position', [0.75  0.77 0.15 0.15  ]);
group = [ ones( length(NIT_inlet_histo_nonstorm.Data), 1) *1 ;  ...
ones(length(weirNIT_nonStorm.Data), 1)*2 ];
boxplot(ax2, [NIT_inlet_histo_nonstorm.Data ;  weirNIT_nonStorm.Data], group,'labels',[]);
%set(ax2,'xticklabel',[]);
ax3 = axes('position', [0.1  0.59  0.6 0.15  ]);
ax4 = axes('position', [0.75  0.59 0.15 0.15  ]);
ax5 = axes('position', [0.1  0.41 0.6 0.15  ]);
ax6 = axes('position', [0.75  0.41 0.15 0.15  ]);
