

 clearvars -except anvil
 close all
 clc
% load('E:\Simulation_UWA_WD\2 For model variables\Supporting information\anvil.mat');
 addpath('E:\Simulation_UWA_WD\2 For model variables\Function');
 addpath('E:\Simulation_UWA_WD\2 For model variables\Supporting information');
yysTime_12_17  = datenum('2012/01/01 00:00:00');
 yyeTime_12_17  = datenum('2017/12/31 23:55:00');
 yyTick_12_17 = {   '2012/01/01 '...
                      '2013/01/01 '...
                      '2014/01/01 '...
                      '2015/01/01 '...
                      '2016/01/01 '...
                      '2017/01/01 ' }';
yyLable_12_17 = { '12' '13' '14' '15' '16' '17'    }';  


DON_DoW_inlet =  anvil.SWQ.MSANVCBIN.LRD.DoW.WQ_OGM_DON;
DON_DoW_inlet.Data =  DON_DoW_inlet.Data / 1000 *14;
DON_UWA_inlet_storm3 = anvil.SWQ.MSANVCBIN.HRD.daily.dailyStorm_03.DON;
DON_UWA_inlet_storm4 = anvil.SWQ.MSANVCBIN.HRD.daily.dailyStorm_04.DON;
DON_UWA_inlet_storm5 = anvil.SWQ.MSANVCBIN.HRD.daily.dailyStorm_05.DON;
DON_UWA_inlet_Opportunistic = anvil.SWQ.MSANVCBIN.HRD.Opportunistic.DON;

ss = isnan(DON_UWA_inlet_Opportunistic.Data); 
DON_UWA_inlet_Opportunistic.Date = DON_UWA_inlet_Opportunistic.Date(~ss);
DON_UWA_inlet_Opportunistic.Data = DON_UWA_inlet_Opportunistic.Data(~ss);

 finalVar =   addStructVar(DON_DoW_inlet  ,DON_UWA_inlet_storm3 );
 finalVar =   addStructVar( finalVar   ,DON_UWA_inlet_storm4 );
  finalVar =   addStructVar( finalVar   ,DON_UWA_inlet_storm5 );
   finalVar =   addStructVar( finalVar   ,DON_UWA_inlet_Opportunistic  );
   
   
fileInletFlow = 'E:\Simulation_UWA_WD\1 For model\0 boundaryPlot\longTermtrendNutrient\Inlet_LongDischarge2012_2017 daily.csv';
fid = fopen(fileInletFlow,'rt');
dataFlow = textscan(fid,'%s %f','Headerlines',1,'Delimiter',',');
LongDis.Date = datenum(dataFlow{1,1},'yyyy/mm/dd');
LongDis.Data = dataFlow{1,2};
%-----------------
fileAirTemp = 'E:\Simulation_UWA_WD\1 For model\0 boundaryPlot\longTermtrendNutrient\dailyAverageAirTemp2005to201806.csv';
fid = fopen(fileAirTemp,'rt');
dataAirTemp = textscan(fid,'%s %f','Headerlines',1,'Delimiter',',');
LongAirTemp.Date = datenum(dataAirTemp{1,1},'dd/mm/yyyy');
LongAirTemp.Data = dataAirTemp{1,2};





zero_Var = zeros( length(finalVar.Date)  , 1) ;
 ss_1 = find(   datenum(2012, 7, 19)  <=  finalVar.Date   & finalVar.Date <= datenum(2017, 2, 1)    ) ;
 ss_2 = find(  datenum(2017, 4, 13)  <=  finalVar.Date   & finalVar.Date <= datenum(2017, 7, 18) );
 zero_Var(ss_1) = 1;
 zero_Var(ss_2) = 1;
  
 finalVarPeriod.Date = finalVar.Date(logical(zero_Var));
  finalVarPeriod.Data = finalVar.Data(logical(zero_Var));
  flow_target    =  findFlowDateNutrients(  finalVarPeriod.Date, LongDis );
  AirTemp_target    =  findFlowDateNutrients(  finalVarPeriod.Date, LongAirTemp );
min(AirTemp_target.Data)
max( AirTemp_target.Data)
figure
subplot(2,1, 1)
plot(AirTemp_target.Date   , AirTemp_target.Data, '*' )
 hold on
  set(gca,'XTick',[datenum(yyTick_12_17 )],'XTickLabel',yyLable_12_17,'TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
title('The value of air temperature and flow corresponding to sample date of DON')
box(gca,'on');
xlabel('Year')
xlim([yysTime_12_17  yyeTime_12_17]);
ylabel({'Air temperature', '(^{o}C)'});
grid on 
 subplot(2, 1, 2)
 plot( flow_target.Date  ,flow_target.Data, '*' )
 set(gca,'XTick',[datenum(yyTick_12_17 )],'XTickLabel',yyLable_12_17,'TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
% title('The model temp and flow')
box(gca,'on');
xlabel('Year')
xlim([yysTime_12_17  yyeTime_12_17]);
ylabel({'flow', '(m^{3}/s)'});
grid on 
set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 10;
xLeft = 0; yTop = 0;

set(gcf,'paperposition',[xLeft yTop xSize ySize])
saveas(gcf, [   'Target period temp flow for DON'],'png');
saveas(gcf, [ 'Target period temp flow for DON'],'fig');
 
 x1 = log(AirTemp_target.Data);
x2 =  log(flow_target.Data);    % Contains NaN data
y = log(finalVarPeriod.Data);
X = [ones(size(x1)) x1 x2  ];
[b_temp_Q,  ~, ~, ~,  stats_temp_Q] = regress(y,X)  ;


for ii = 1 : length(flow_target.Data)
       model_temp_DON(ii, 1) = exp( b_temp_Q(1) + b_temp_Q(2)* log(AirTemp_target.Data(ii)) + b_temp_Q(3) * log(flow_target.Data(ii)) ) ;
end



figure
plot( finalVarPeriod.Date,  finalVarPeriod.Data, '*')
 hold on 
 plot( finalVarPeriod.Date,  model_temp_DON , 'o')
 hold on 
 hline = refline([0 mean(finalVarPeriod.Data )]);
 hline.Color = 'r';
 leg1 = legend('Measured', 'Modelled', 'Measured average');
 set(leg1, 'location', 'best');
set(gca,'XTick',[datenum(yyTick_12_17 )],'XTickLabel',yyLable_12_17,'TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
title('The model temp and flow')
box(gca,'on');
xlabel('Year')
xlim([yysTime_12_17  yyeTime_12_17]);
ylabel({'DON', '(mg/L)'});
grid on 
set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 10;
xLeft = 0; yTop = 0;

set(gcf,'paperposition',[xLeft yTop xSize ySize])
saveas(gcf, [   'Measured and modelled DON temp flow'],'png');
saveas(gcf, [ 'Measured and modelled DON temp flow'],'fig');
[mae_temp_Q, rmse_temp_Q, ns_temp_Q]    = modelPerformance( log(finalVarPeriod.Data),  log( model_temp_DON) );

% datestr('x', 19)
figure
plot(finalVarPeriod.Data  ,model_temp_DON , '*'  )
xlim( [0.1  0.8   ])
hline = refline(1,0);
hline.Color = 'r';
title('The model temp and flow')
xlabel('Measured DON (mg/L)');
ylabel('Modelled DON (mg/L)');

set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 10; ySize = 10;
xLeft = 0; yTop = 0;

set(gcf,'paperposition',[xLeft yTop xSize ySize])
saveas(gcf, [   'Performance_Measured and modelled DON temp flow'],'png');
saveas(gcf, [ 'Performance_Measured and modelled DON temp flow'],'fig');




% generation of NOx duirng the April and May 2015
sTime  = datenum('2015/04/01 00:00:00');
 eTime  = datenum('2015/05/31 23:55:00');
 timeTick = {'2015/04/01 00:00:00'...
                  '2015/04/10 00:00:00'...
                  '2015/04/20 00:00:00'...
                  '2015/05/01 00:00:00'...
                  '2015/05/10 00:00:00'...
                  '2015/05/20 00:00:00'...
                  '2015/05/31 00:00:00'}';
timeLable = {' Apr 01' ' Apr 10'  ' Apr 20'   ' May 01' ' May 10'   ' May 20'  ' May 31'   }';  
period = { '01/04/2015', '06/04/2015' , ...
                 '07/04/2015',   '14/04/2015', ...
                   '15/04/2015',   '30/04/2015', ...
                   '01/05/2015',  '5/05/2015', ...
                   '6/05/2015',    '15/05/2015', ...
                   '16/05/2015',    '21/05/2015', ...
                   '22/05/2015', '31/05/2015' };

ss_temp = find( sTime  <=    LongAirTemp.Date  &   LongAirTemp.Date <= eTime );
AirTemp_period.Date =  LongAirTemp.Date(ss_temp);
AirTemp_period.Data =  LongAirTemp.Data(ss_temp);

ss_flow = find( sTime  <=    LongDis.Date  &   LongDis.Date <= eTime );
Flow_period.Date =  LongDis.Date(ss_flow);
Flow_period.Data =  LongDis.Data(ss_flow); % the unit is m3/s

generate_temp_DON.Date = AirTemp_period.Date;
for ii = 1 : length(AirTemp_period.Data)
    
   generate_temp_DON.Data(ii, 1) = exp( b_temp_Q(1) + b_temp_Q(2)* log(AirTemp_period.Data(ii)) + b_temp_Q(3) * log(Flow_period.Data(ii)) ) ;
    
end
figure
plot(generate_temp_DON.Date  ,generate_temp_DON.Data, '*' )


figure
subplot(2,1,1)
plot(AirTemp_period.Date, AirTemp_period.Data, '*')
hold on
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
ylabel({'Air temperature', '(^{o}C)'});
grid on 
subplot(2,1,2)
plot(Flow_period.Date, Flow_period.Data, '*')
hold on
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
ylabel({'flow', '(m^{3}/s)'});
grid on 
set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 20;
xLeft = 0; yTop = 0;

set(gcf,'paperposition',[xLeft yTop xSize ySize])
saveas(gcf, [   'Temp flow for predict'],'png');
saveas(gcf, [ 'Temp flow for predict'],'fig');



figure
plot( generate_temp_DON.Date  , generate_temp_DON.Data, '*')
hold on 

DON_UWA_inlet_storm4 = anvil.SWQ.MSANVCBIN.HRD.daily.dailyStorm_04.DON;
plot(DON_UWA_inlet_storm4.Date, DON_UWA_inlet_storm4.Data, 'sk' );
hold on 
DON_UWA_inlet_storm5 = anvil.SWQ.MSANVCBIN.HRD.daily.dailyStorm_05.DON;
plot(DON_UWA_inlet_storm5.Date, DON_UWA_inlet_storm5.Data, '+k' );
hold on 

AddShade([0 0], [1.0  1.0 ], period  )
leg1 = legend('Generated DON', 'Obserbed DON in April' , 'Obserbed DON in May');
set(leg1,'Position',[0.294456066945607 0.803539019963702 0.228556485355648 0.0957350272232304]);
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([   ' Generated DON ']);
xlim([sTime  eTime]);
ylim([ 0   1.0]);
ylabel('DON (mg/L)'); 
xlabel('Date (2015)');
grid on

 set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 10;
xLeft = 0;   yTop = 0;
set(gcf,'paperposition',[xLeft yTop xSize ySize])
saveas(gcf,[  'Generated DON '],'png');
saveas(gcf,[ 'Generated DON '],'fig');

writeDaily(generate_temp_DON, 'daily_generated_DON.csv', 'DON (mg/L)')
 generate_temp_DON_5min =  interpolate5min( generate_temp_DON);
 writeMinute(generate_temp_DON_5min, '5min_generated_DON.csv', 'DON (mg/L)');