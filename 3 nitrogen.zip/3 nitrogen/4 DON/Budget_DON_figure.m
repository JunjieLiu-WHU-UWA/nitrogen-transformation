%this script is to analyze the budget of oxygen
clc
close all
% clearvars -except anvil 

% addpath('E:\Simulation_UWA_WD\2 For model variables\Function');
% addpath('E:\Simulation_UWA_WD\2 For model variables\Supporting information');
% BasicRead
currentOutput = '3 nitrogen\4 DON\'; 
fileOutput =  [dicmodel currentFolder '\Output\' currentOutput ];
if ~exist(fileOutput,'dir')      % check  whether the outdir  exists in the file of 'dir';
    mkdir(fileOutput);           % if not exists, create the file of 'outdir'
end

% budget_DON = zeros( 5 ,1   );
labels = {'Influent','Outfluent','sediment flux', ...
                 'mineralisation', 'decomposition'}';
 Source_DON = zeros(2, 1);
figure
% Transport in
fileTran = [file '4 DON\DON transport_in.csv' ];
fid = fopen(fileTran,'rt');
data = textscan(fid,'%s %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
transIN.Date = dateTime;
transIN.Data = data{1,2}; % the unit is g/d
Source_DON(1,1) = trapz(transIN.Date, transIN.Data  );
[ transINnonStorm,  transINStorm, sumtransINperiod ]    =  ...
    sum_10min_six_period(transIN,  period_10min );

 

subplot(4,1,1)
pp = plot(transIN.Date, transIN.Data);
AddShade([0  0] , [25000 25000] , period );
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel','','TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);
% ylim([0 1000 ]);
ylabel({'DON',' Input', '(g/d)'});
%  text( sTime + 8,800,'(a)');
 text(0.08,1.1,'(a)','units','normalized');
 title(['Scenario   '  currentFolder])
 grid on 


% sedment flux of DON
 fileAtm = [ file '4 DON\Sediment flux of DON _wholeWetland.csv'];
 fid = fopen(fileAtm,'rt');
data = textscan(fid,'%s %f %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
SedDON.Date = dateTime ;
SedDON.Data = data{1,2} ;% the unit is g/d
Source_DON(2,1) = trapz(SedDON.Date, SedDON.Data  );
[ SedDONnonStorm,  SedDONStorm, sumSedDONperiod ]    =  ...
    sum_10min_six_period(SedDON,  period_10min );
subplot(4,1,2)
pp = plot( SedDON.Date , SedDON.Data);
AddShade([0  0] , [150 150] , period );
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel','','TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);
% ylim([0 1000 ]);
ylabel({'Sediment flux','DON', '(g/d)'});
%  text( sTime + 8,800,'(a)');
 text(0.08,1.1,'(c)','units','normalized');
%  title(['Scenario   '  currentFolder])
 grid on 
 
% transport out
fileTran = [ file '4 DON\DON transport_out.csv'];
fid = fopen(fileTran,'rt');
data = textscan(fid,'%s %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
transOut.Date = dateTime;
transOut.Data = data{1,2}; % the unit is g/d
Sink_DON(1,1) = trapz(transOut.Date, transOut.Data  );
[ transOutnonStorm,  transOutStorm, sumtransOutperiod ]    =  ...
    sum_10min_six_period(transOut,  period_10min );
subplot(4,1,3)
pp = plot(transOut.Date, transOut.Data   );
AddShade([0  0] , [25000 25000] , period );
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel','','TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);
% ylim([0 1000 ]);
ylabel({'DON',' Output', '(g/d)'});
%  text( sTime + 8,800,'(a)');
 text(0.08,1.1,'(b)','units','normalized');
%  title(['Scenario   '  currentFolder])
 grid on 


 % mineralisation of DON
 fileAtm = [ file '4 DON\Mineralisation of DON _wholeWetland.csv'];
 fid = fopen(fileAtm,'rt');
data = textscan(fid,'%s %f %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
MineraDON.Date = dateTime ;
MineraDON.Data = data{1,2} ;% the unit is g/d
Sink_DON(2,1) = trapz(MineraDON.Date, MineraDON.Data  );
 [ MineraDONnonStorm,  MineraDONStorm, sumMineraDONperiod ]    =  ...
    sum_10min_six_period(MineraDON,  period_10min );
 
subplot(4,1,4)
pp = plot( MineraDON.Date , MineraDON.Data);
AddShade([0  0] , [50 50] , period );
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel', timeLable,'TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);
% ylim([0 1000 ]);
ylabel({'DON',' Mineralisation', '(g/d)'});
%  text( sTime + 8,800,'(a)');
 text(0.08,1.1,'(d)','units','normalized');
%  title(['Scenario   '  currentFolder])
 grid on 

 
 
 set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 29;
xLeft = 0;   yTop = 0;
set(gcf,'paperposition',[xLeft yTop xSize ySize])
saveas(gcf, [file '\4 DON\DON budget mass'],'png');


% decomposition of PON
 fileAtm = [ file '5 PON\PON decomposition _wholeWetland.csv'];
 fid = fopen(fileAtm,'rt');
data = textscan(fid,'%s %f %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
DecomPON.Date = dateTime ;
DecomPON.Data = data{1,2};% the unit is g/d
% Sink_DON(3,1) = trapz(DecomPON.Date, DecomPON.Data  );


% subplot(4,1,5)
figure
pp = plot( DecomPON.Date , DecomPON.Data);
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel','','TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);
% ylim([0 1000 ]);
ylabel({'PON',' Decomposition', '(g/d)'});
%  text( sTime + 8,800,'(a)');
 text(0.08,1.1,'(d)','units','normalized');
%  title(['Scenario   '  currentFolder])
 grid on 




% 
% figure
% p = pie(budget_DON);
% pText = findobj(p,'Type','text');
% 
% leg1 = legend('Influent','Outfluent','Sediment flux', 'MIneralisastion', 'decomposition' );
%  set(leg1,...
%     'Location','eastoutside');
% 
% set(gcf, 'PaperPositionMode', 'manual');
% set(gcf, 'PaperUnits', 'centimeters');
% xSize = 10; ySize = 10;
% xLeft = 0;   yTop = 0;
% set(gcf,'paperposition',[xLeft yTop xSize ySize])
% saveas(gcf, [file '\4 DON\Pie DON budget percent'],'png');


figure
fig_p = subplot(2,1,1)
p = pie(Source_DON);
pText = findobj(p,'Type','text');
colormap(fig_p, [ 0.5 0.5 0.5;      %grey
         1 0 0 ]) ; % red   
%           0 1 1 ])  %cyan
pText = findobj(p,'Type','text');
 title(['DON'  currentFolder])
p(2).Position = [ 0.3  0.5 0 ] .*p(2).Position;
% p(4).Position =  [0.7 0.5 0  ].*p(4).Position;
 title(['Scenario  whole '  currentFolder])
% leg1 = legend('Influent','Sediment flux');
%  set(leg1,  'Location','eastoutside');

fig_p = subplot(2,1,2);
p = pie(Sink_DON);
colormap(fig_p , [ 0.5  0.5  0.5;      %grey
       0, 0.4470, 0.7410])  ; % blue      
%           0 1 0;  % green     
%           1 1 0]) % yellow
pText = findobj(p,'Type','text');
p(2).Position = [ 0.3  0.5 0 ] .*p(2).Position;
% p(4).Position =  [0.7 0.5 0  ].*p(4).Position;
%  p(6).Position =  [0.8 0.6 0  ].*p(6).Position;
% p(8).Position =  [0.5 0.6 0  ].*p(8).Position;
pText = findobj(p,'Type','text');
%  title(['Scenario   '  currentFolder])
% leg1 = legend('effluent',   'Mineralisation' );
%  set(leg1, 'Location','eastoutside');

set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 10; ySize = 10;
xLeft = 0;   yTop = 0;
set(gcf,'paperposition',[xLeft yTop xSize ySize])
saveas(gcf, [fileOutput 'Pie DON budget percent'],'png');

% 
%------------------------------- non storm period----  in 
DON_in_nonStorm(1,1)  =  transINnonStorm;
DON_in_nonStorm(2,1)  = SedDONnonStorm;



% out
DON_out_nonStorm(1,1)  =  transOutnonStorm;
DON_out_nonStorm(2,1)  =  MineraDONnonStorm;

% ------------------storm period
% in
DON_in_Storm(1,1)  =  transINStorm;
DON_in_Storm(2,1)  = SedDONStorm;


% out
DON_out_Storm(1,1)  =  transOutStorm;
DON_out_Storm(2,1)  =   MineraDONStorm;

figure
fig_p = subplot(2,1,1)
p = pie(DON_in_nonStorm);
colormap(fig_p, [ 0.5 0.5 0.5;      %grey
         1 0 0 ]) ; % red  
pText = findobj(p,'Type','text');
p(2).Position = [ 0.3  0.5 0 ] .*p(2).Position;
p(4).Position =  [0.7 0.7 0  ].*p(4).Position;
% leg1 = legend('Influent' , 'Sediment flux', ...
%               'Nitrification');
%  set(leg1,...
%     'Location','eastoutside');
title([currentFolder '     ' 'DON budget non storm period' ] );
fig_p  = subplot(2,1,2)
p = pie(DON_out_nonStorm);
colormap(fig_p , [ 0.5  0.5  0.5;      %grey
       0, 0.4470, 0.7410])  ; % blue      
%           0 1 0;  % green    
pText = findobj(p,'Type','text');
p(2).Position = [ 0.3  0.5 0 ] .*p(2).Position;
p(4).Position =  [0.7 0.7 0  ].*p(4).Position;

% leg1 = legend('effluent',  'Denitrification', 'Pelagic uptake', 'Benthic uptake');
%  set(leg1,...
%     'Location','eastoutside');
% title([currentFolder ] );
set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 15; ySize = 10;
xLeft = 0;   yTop = 0;
set(gcf,'paperposition',[xLeft yTop xSize ySize])
saveas(gcf, [fileOutput 'Pie DON nonStorm in out budget percent'],'png');


figure
fig_p = subplot(2,1,1)
p = pie(DON_in_Storm);
colormap(fig_p, [ 0.5 0.5 0.5;      %grey
         1 0 0 ]) ; % red  
pText = findobj(p,'Type','text');
p(2).Position = [ 0.3  0.5 0 ] .*p(2).Position;
% p(4).Position =  [0.7 0.5 0  ].*p(4).Position;
leg1 = legend('Influent' , 'Sediment flux');
 set(leg1,...
    'Location','eastoutside');
title([currentFolder '  ' ' DON budget Storm event' ] );
fig_p = subplot(2,1,2)
p = pie(DON_out_Storm);
colormap(fig_p , [ 0.5  0.5  0.5;      %grey
       0, 0.4470, 0.7410])  ; % blue      
%           0 1 0;  % green    
pText = findobj(p,'Type','text');
p(2).Position = [ 0.3  0.5 0 ] .*p(2).Position;
% p(4).Position =  [0.7 0.5 0  ].*p(4).Position;
leg1 = legend('effluent',  'Mineralisation');
 set(leg1,...
    'Location','eastoutside');

% title([currentFolder ] );
set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 15; ySize = 10;
xLeft = 0;   yTop = 0;
set(gcf,'paperposition',[xLeft yTop xSize ySize])
saveas(gcf, [fileOutput 'Pie DON Storm in out budget percent'],'png');


% 
% percentValues = get(pText,'String'); 
% txt = {'Influent : ','Outfluent :','Atmospheric flux :', ...
%                 'SOD :', 'PGPP :', 'NEP :' }'; 
% combinedtxt = strcat(txt,percentValues);
% 
% pText(1).String = combinedtxt(1);
% pText(2).String = combinedtxt(2);
% pText(3).String = combinedtxt(3);
% pText(4).String = combinedtxt(4);
% pText(5).String = combinedtxt(5);
% pText(6).String = combinedtxt(6);